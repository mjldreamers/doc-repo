-- *********************Create Databases*********************
Use master
GO


-- CARDS
CREATE DATABASE CARDS
ON   
( NAME = CARDS,  
    FILENAME = '/var/opt/mssql/data/CARDS.mdf',  
    SIZE = 100MB,  
    MAXSIZE = UNLIMITED,  
    FILEGROWTH = 100MB )  
LOG ON  
( NAME = CARDS_log,  
    FILENAME = '/var/opt/mssql/data/CARDS_log.ldf',  
    SIZE = 100MB,  
    MAXSIZE = 2097152MB,  
    FILEGROWTH = 10MB) ;  
GO  


-- *********************Database Settings*********************


USE [master] ;  
ALTER DATABASE [CARDS] SET RECOVERY SIMPLE; 


-- *********************Create Schema*********************


-- CARDS SCHEMA
USE [CARDS]
GO

CREATE SCHEMA [cms]
GO

CREATE SCHEMA [cdm]
GO

CREATE SCHEMA [pbf]
GO

-- *********************Create Logins*********************

/****** Use Master ******/
USE [master]
GO

-- User [CDG567JNH]
CREATE LOGIN [CDG567JNH] WITH PASSWORD=N'';
GO


/****** Allow users access to CARDS Database ******/
/****** Create Roles roles ******/
Use [CARDS]
GO

-- User [CDG567JNH]
CREATE USER [CDG567JNH] FOR LOGIN [CDG567JNH] WITH DEFAULT_SCHEMA=[cms]
GO

CREATE ROLE [cmsrole] AUTHORIZATION [dbo];
GO

CREATE ROLE [cdmrole] AUTHORIZATION [dbo];
GO

CREATE ROLE [pbfrole] AUTHORIZATION [dbo];
GO

/****** Configure Roles ******/
-- cmsrole
GRANT EXECUTE ON SCHEMA::[cms] TO [cmsrole]
GO
GRANT INSERT ON SCHEMA::[cms] TO [cmsrole]
GO
GRANT SELECT ON SCHEMA::[cms] TO [cmsrole]
GO
GRANT UPDATE ON SCHEMA::[cms] TO [cmsrole]
GO

-- cdmrole
GRANT EXECUTE ON SCHEMA::[cdm] TO [cdmrole]
GO
GRANT INSERT ON SCHEMA::[cdm] TO [cdmrole]
GO
GRANT SELECT ON SCHEMA::[cdm] TO [cdmrole]
GO
GRANT UPDATE ON SCHEMA::[cdm] TO [cdmrole]
GO


-- pbfrole
GRANT EXECUTE ON SCHEMA::[pbf] TO [pbfrole]
GO
GRANT INSERT ON SCHEMA::[pbf] TO [pbfrole]
GO
GRANT SELECT ON SCHEMA::[pbf] TO [pbfrole]
GO
GRANT UPDATE ON SCHEMA::[pbf] TO [pbfrole]
GO

/****** Configure user roles ******/
-- CDG567JNH Role
ALTER ROLE [cmsrole] ADD MEMBER [CDG567JNH]
GO

ALTER ROLE [cdmrole] ADD MEMBER [CDG567JNH]
GO

ALTER ROLE [pbfrole] ADD MEMBER [CDG567JNH]
GO


-- *********************Query Store Setup*********************
USE [Master]
GO


ALTER DATABASE CARDS
SET QUERY_STORE (
    OPERATION_MODE = READ_WRITE,
    CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30),
    DATA_FLUSH_INTERVAL_SECONDS = 3000,
    MAX_STORAGE_SIZE_MB = 1000,
    INTERVAL_LENGTH_MINUTES = 10,
    SIZE_BASED_CLEANUP_MODE = AUTO,
    QUERY_CAPTURE_MODE = AUTO,
    MAX_PLANS_PER_QUERY = 1000
); 