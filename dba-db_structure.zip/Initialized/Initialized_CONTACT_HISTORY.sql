-- *********************Create Databases*********************
Use master
GO

-- CONTACT_HISTORY
CREATE DATABASE CONTACT_HISTORY
ON   
( NAME = CONTACT_HISTORY,  
    FILENAME = '/var/opt/mssql/data/CONTACT_HISTORY.mdf',  
    SIZE = 100MB,  
    MAXSIZE = UNLIMITED,  
    FILEGROWTH = 100MB )  
LOG ON  
( NAME = CONTACT_HISTORY_log,  
    FILENAME = '/var/opt/mssql/data/CONTACT_HISTORY_log.ldf',  
    SIZE = 100MB,  
    MAXSIZE = 2097152MB,  
    FILEGROWTH = 10MB) ;  
GO  


-- *********************Database Settings*********************

USE [master] ;  
ALTER DATABASE [CONTACT_HISTORY] SET RECOVERY SIMPLE; 


-- *********************Create Schema*********************

-- CONTACT_HISTORY SCHEMA
USE [CONTACT_HISTORY]
GO

CREATE SCHEMA [chst]
GO


-- *********************Create Logins*********************

/****** Use Master ******/
USE [master]
GO

-- User [CHT342DYU] for Contact History
CREATE LOGIN [CHT342DYU] WITH PASSWORD=N'';
GO


/****** Allow users access to CONTACT_HISTORY Database ******/
/****** Create Roles roles ******/
Use [CONTACT_HISTORY]
GO

-- User [CHT342DYU]
CREATE USER [CHT342DYU] FOR LOGIN [CHT342DYU] WITH DEFAULT_SCHEMA=[chst]
GO

CREATE ROLE [chstrole] AUTHORIZATION [dbo];
GO

/****** Configure Roles ******/
-- chstrole
GRANT EXECUTE ON SCHEMA::[chst] TO [chstrole]
GO
GRANT INSERT ON SCHEMA::[chst] TO [chstrole]
GO
GRANT SELECT ON SCHEMA::[chst] TO [chstrole]
GO
GRANT UPDATE ON SCHEMA::[chst] TO [chstrole]
GO

/****** Configure user roles ******/
-- CHT342DYU Role
ALTER ROLE [chstrole] ADD MEMBER [CHT342DYU]
GO


-- *********************Query Store Setup*********************
USE [Master]
GO

ALTER DATABASE CONTACT_HISTORY
SET QUERY_STORE (
    OPERATION_MODE = READ_WRITE,
    CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30),
    DATA_FLUSH_INTERVAL_SECONDS = 3000,
    MAX_STORAGE_SIZE_MB = 1000,
    INTERVAL_LENGTH_MINUTES = 10,
    SIZE_BASED_CLEANUP_MODE = AUTO,
    QUERY_CAPTURE_MODE = AUTO,
    MAX_PLANS_PER_QUERY = 1000
); 