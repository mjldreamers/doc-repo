-- *********************Create Databases*********************
Use master
GO

-- BI
CREATE DATABASE BI
ON   
( NAME = BI,  
    FILENAME = '/var/opt/mssql/data/BI.mdf',  
    SIZE = 100MB,  
    MAXSIZE = UNLIMITED,  
    FILEGROWTH = 100MB )  
LOG ON  
( NAME = BI_log,  
    FILENAME = '/var/opt/mssql/data/BI_log.ldf',  
    SIZE = 100MB,  
    MAXSIZE = 2097152MB,  
    FILEGROWTH = 10MB) ;  
GO  


-- *********************Database Settings*********************

USE [master] ;  
ALTER DATABASE [BI] SET RECOVERY SIMPLE; 


-- *********************Create Schema*********************


-- BI SCHEMA
USE [BI]
GO

CREATE SCHEMA [birpt]
GO


-- *********************Create Logins*********************

/****** Use Master ******/
USE [master]
GO

-- User [BSD765HGF] for BI Team
CREATE LOGIN [BSD765HGF] WITH PASSWORD=N'';
GO

/****** Allow users access to BI Database ******/

/****** Create Roles roles ******/
Use [BI]
GO

-- User [BSD765HGF]
CREATE USER [BSD765HGF] FOR LOGIN [BSD765HGF] WITH DEFAULT_SCHEMA=[birpt]
GO

CREATE ROLE [birole] AUTHORIZATION [dbo];
GO

/****** Configure Roles ******/
-- birole
GRANT EXECUTE ON SCHEMA::[birpt] TO [birole]
GO
GRANT INSERT ON SCHEMA::[birpt] TO [birole]
GO
GRANT SELECT ON SCHEMA::[birpt] TO [birole]
GO
GRANT UPDATE ON SCHEMA::[birpt] TO [birole]
GO

/****** Configure user roles ******/
-- BSD765HGF Role
ALTER ROLE [birole] ADD MEMBER [BSD765HGF]
GO



-- *********************Query Store Setup*********************
USE [Master]
GO


ALTER DATABASE BI
SET QUERY_STORE (
    OPERATION_MODE = READ_WRITE,
    CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30),
    DATA_FLUSH_INTERVAL_SECONDS = 3000,
    MAX_STORAGE_SIZE_MB = 1000,
    INTERVAL_LENGTH_MINUTES = 10,
    SIZE_BASED_CLEANUP_MODE = AUTO,
    QUERY_CAPTURE_MODE = AUTO,
    MAX_PLANS_PER_QUERY = 1000
); 
