-- *********************Create Databases*********************
Use master
GO

-- FACE_RECOGNITION
CREATE DATABASE FACE_RECOGNITION
ON   
( NAME = FACE_RECOGNITION,  
    FILENAME = '/var/opt/mssql/data/FACE_RECOGNITION.mdf',  
    SIZE = 100MB,  
    MAXSIZE = UNLIMITED,  
    FILEGROWTH = 100MB )  
LOG ON  
( NAME = FACE_RECOGNITION_log,  
    FILENAME = '/var/opt/mssql/data/FACE_RECOGNITION_log.ldf',  
    SIZE = 100MB,  
    MAXSIZE = 2097152MB,  
    FILEGROWTH = 10MB) ;  
GO  



-- *********************Database Settings*********************

USE [master] ;  
ALTER DATABASE [FACE_RECOGNITION] SET RECOVERY SIMPLE; 


-- *********************Create Schema*********************


-- FACE_RECOGNITION SCHEMA
USE [FACE_RECOGNITION]
GO

CREATE SCHEMA [face]
GO


-- *********************Create Logins*********************

/****** Use Master ******/
USE [master]
GO


-- User [FYV934TFH] for Face Recognition
CREATE LOGIN [FYV934TFH] WITH PASSWORD=N'';
GO


/****** Allow users access to FACE_RECOGNITION Database ******/
/****** Create Roles roles ******/
Use [FACE_RECOGNITION]
GO

-- User [FYV934TFH]
CREATE USER [FYV934TFH] FOR LOGIN [FYV934TFH] WITH DEFAULT_SCHEMA=[face]
GO

CREATE ROLE [facerole] AUTHORIZATION [dbo];
GO

/****** Configure Roles ******/
-- facerole
GRANT EXECUTE ON SCHEMA::[face] TO [facerole]
GO
GRANT INSERT ON SCHEMA::[face] TO [facerole]
GO
GRANT SELECT ON SCHEMA::[face] TO [facerole]
GO
GRANT UPDATE ON SCHEMA::[face] TO [facerole]
GO

/****** Configure user roles ******/
-- FYV934TFH Role
ALTER ROLE [facerole] ADD MEMBER [FYV934TFH]
GO


-- *********************Query Store Setup*********************
USE [Master]
GO

ALTER DATABASE FACE_RECOGNITION
SET QUERY_STORE (
    OPERATION_MODE = READ_WRITE,
    CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30),
    DATA_FLUSH_INTERVAL_SECONDS = 3000,
    MAX_STORAGE_SIZE_MB = 1000,
    INTERVAL_LENGTH_MINUTES = 10,
    SIZE_BASED_CLEANUP_MODE = AUTO,
    QUERY_CAPTURE_MODE = AUTO,
    MAX_PLANS_PER_QUERY = 1000
); 