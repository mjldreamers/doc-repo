-- *********************Create Databases*********************
Use master
GO

-- DOCUMENTS
CREATE DATABASE DOCUMENTS
ON   
( NAME = DOCUMENTS,  
    FILENAME = '/var/opt/mssql/data/DOCUMENTS.mdf',  
    SIZE = 100MB,  
    MAXSIZE = UNLIMITED,  
    FILEGROWTH = 100MB )  
LOG ON  
( NAME = DOCUMENTS_log,  
    FILENAME = '/var/opt/mssql/data/DOCUMENTS_log.ldf',  
    SIZE = 100MB,  
    MAXSIZE = 2097152MB,  
    FILEGROWTH = 10MB) ;  
GO  


-- *********************Database Settings*********************

USE [master] ;  
ALTER DATABASE [DOCUMENTS] SET RECOVERY SIMPLE; 


-- *********************Create Schema*********************


-- DOCUMENTS SCHEMA
USE [DOCUMENTS]
GO

CREATE SCHEMA [rtb]
GO
CREATE SCHEMA [doc]
GO


-- *********************Create Logins*********************

/****** Use Master ******/
USE [master]
GO

-- User [DKL832DFK] for Documents
CREATE LOGIN [DKL832DFK] WITH PASSWORD=N'';
GO


/****** Allow users access to Documents Database ******/
/****** Create Roles roles ******/
Use [DOCUMENTS]
GO

-- User [DKL832DFK]
CREATE USER [DKL832DFK] FOR LOGIN [DKL832DFK] WITH DEFAULT_SCHEMA=[doc]
GO

CREATE ROLE [rtbrole] AUTHORIZATION [dbo];
GO
CREATE ROLE [docrole] AUTHORIZATION [dbo];
GO

/****** Configure Roles ******/
-- chstrole
GRANT EXECUTE ON SCHEMA::[rtb] TO [rtbrole]
GO
GRANT INSERT ON SCHEMA::[rtb] TO [rtbrole]
GO
GRANT SELECT ON SCHEMA::[rtb] TO [rtbrole]
GO
GRANT UPDATE ON SCHEMA::[rtb] TO [rtbrole]
GO

/****** Configure Roles ******/
-- chstrole
GRANT EXECUTE ON SCHEMA::[doc] TO [docrole]
GO
GRANT INSERT ON SCHEMA::[doc] TO [docrole]
GO
GRANT SELECT ON SCHEMA::[doc] TO [docrole]
GO
GRANT UPDATE ON SCHEMA::[doc] TO [docrole]
GO

/****** Configure user roles ******/
-- DKL832DFK Role
ALTER ROLE [rtbrole] ADD MEMBER [DKL832DFK]
GO
ALTER ROLE [docrole] ADD MEMBER [DKL832DFK]
GO


-- *********************Query Store Setup*********************
USE [Master]
GO

ALTER DATABASE DOCUMENTS
SET QUERY_STORE (
    OPERATION_MODE = READ_WRITE,
    CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30),
    DATA_FLUSH_INTERVAL_SECONDS = 3000,
    MAX_STORAGE_SIZE_MB = 1000,
    INTERVAL_LENGTH_MINUTES = 10,
    SIZE_BASED_CLEANUP_MODE = AUTO,
    QUERY_CAPTURE_MODE = AUTO,
    MAX_PLANS_PER_QUERY = 1000
); 