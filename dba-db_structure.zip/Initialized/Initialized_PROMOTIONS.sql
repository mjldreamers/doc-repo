-- *********************Create Databases*********************
Use master
GO

-- PROMOTIONS
CREATE DATABASE PROMOTIONS
ON   
( NAME = PROMOTIONS,  
    FILENAME = '/var/opt/mssql/data/PROMOTIONS.mdf',  
    SIZE = 100MB,  
    MAXSIZE = UNLIMITED,  
    FILEGROWTH = 100MB )  
LOG ON  
( NAME = PROMOTIONS_log,  
    FILENAME = '/var/opt/mssql/data/PROMOTIONS_log.ldf',  
    SIZE = 100MB,  
    MAXSIZE = 2097152MB,  
    FILEGROWTH = 10MB) ;  
GO  


-- *********************Database Settings*********************
ALTER DATABASE PROMOTIONS
SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT = ON;
GO

USE [master] ;  
ALTER DATABASE [PROMOTIONS] SET RECOVERY SIMPLE; 


-- *********************Query Store Setup*********************
USE [Master]
GO

ALTER DATABASE PROMOTIONS
SET QUERY_STORE (
    OPERATION_MODE = READ_WRITE,
    CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30),
    DATA_FLUSH_INTERVAL_SECONDS = 3000,
    MAX_STORAGE_SIZE_MB = 1000,
    INTERVAL_LENGTH_MINUTES = 10,
    SIZE_BASED_CLEANUP_MODE = AUTO,
    QUERY_CAPTURE_MODE = AUTO,
    MAX_PLANS_PER_QUERY = 1000
); 