-- *********************Create Databases*********************
Use master
GO

-- Loans
CREATE DATABASE LOANS
ON   
( NAME = LOANS,  
    FILENAME = '/var/opt/mssql/data/LOANS.mdf',  
    SIZE = 100MB,  
    MAXSIZE = UNLIMITED,  
    FILEGROWTH = 100MB )  
LOG ON  
( NAME = LOANS_log,  
    FILENAME = '/var/opt/mssql/data/LOANS_log.ldf',  
    SIZE = 100MB,  
    MAXSIZE = 2097152MB,  
    FILEGROWTH = 10MB) ;  
GO  


-- *********************Database Settings*******************

USE [master] ;  
ALTER DATABASE [LOANS] SET RECOVERY SIMPLE; 


-- *********************Create Schema*********************

-- LOANS SCHEMA
USE [LOANS]
GO

CREATE SCHEMA [lns]
GO


-- *********************Create Logins*********************

/****** Use Master ******/
USE [master]
GO

-- User [LNS478XDM] for Loans
CREATE LOGIN [LNS478XDM] WITH PASSWORD=N'';
GO


/****** Allow users access to Loans Database ******/
/****** Create Roles roles ******/
Use [LOANS]
GO

-- User [LNS478XDM]
CREATE USER [LNS478XDM] FOR LOGIN [LNS478XDM] WITH DEFAULT_SCHEMA=[lns]
GO

CREATE ROLE [lnsrole] AUTHORIZATION [dbo];
GO

/****** Configure Roles ******/
-- lsnrole
GRANT EXECUTE ON SCHEMA::[lns] TO [lnsrole]
GO
GRANT INSERT ON SCHEMA::[lns] TO [lnsrole]
GO
GRANT SELECT ON SCHEMA::[lns] TO [lnsrole]
GO
GRANT UPDATE ON SCHEMA::[lns] TO [lnsrole]
GO

--GRANT DELETE ON [lns].[association_value_entry] TO [lnsrole]
--GO
--GRANT DELETE ON [lns].[saga_entry] TO [lnsrole]
--GO
--GRANT DELETE ON [lns].[CACHED_RESPONSE_ENTITY] TO [lnsrole]
--GO


/****** Configure user roles ******/
-- DKL832DFK Role
ALTER ROLE [lnsrole] ADD MEMBER [LNS478XDM]
GO


-- *********************Query Store Setup*********************
USE [Master]
GO

ALTER DATABASE LOANS
SET QUERY_STORE (
    OPERATION_MODE = READ_WRITE,
    CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30),
    DATA_FLUSH_INTERVAL_SECONDS = 3000,
    MAX_STORAGE_SIZE_MB = 1000,
    INTERVAL_LENGTH_MINUTES = 10,
    SIZE_BASED_CLEANUP_MODE = AUTO,
    QUERY_CAPTURE_MODE = AUTO,
    MAX_PLANS_PER_QUERY = 1000
); 