﻿USE [master]
GO
/****** Object:  Database [csd]    Script Date: 09/30/2020 18:40:40 ******/
CREATE DATABASE [csd]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'csd', FILENAME = N'J:\MSSQL\Default\csd.mdf' , SIZE = 256MB , MAXSIZE = UNLIMITED, FILEGROWTH = 100MB )
 LOG ON 
( NAME = N'csd_log', FILENAME = N'K:\MSSQL\Default\csd_log.ldf' , SIZE = 100MB , MAXSIZE = 2048GB , FILEGROWTH = 10MB )
GO

USE [csd]
GO
/****** Object:  User [csd_user]    Script Date: 09/30/2020 18:40:44 ******/
CREATE USER [csd_user] FOR LOGIN [csd_user] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [csd_owner]    Script Date: 09/30/2020 18:40:44 ******/
CREATE USER [csd_owner] FOR LOGIN [csd_owner] WITH DEFAULT_SCHEMA=[dbo]
GO
ALTER ROLE [db_owner] ADD MEMBER [csd_owner]
GO