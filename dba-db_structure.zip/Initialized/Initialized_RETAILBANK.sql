-- *********************Create Databases*********************
Use master
GO

-- RETAILBANK
CREATE DATABASE RETAILBANK
ON   
( NAME = RETAILBANK,  
    FILENAME = '/var/opt/mssql/data/RETAILBANK.mdf',  
    SIZE = 100MB,  
    MAXSIZE = UNLIMITED,  
    FILEGROWTH = 100MB )  
LOG ON  
( NAME = RETAILBANK_log,  
    FILENAME = '/var/opt/mssql/data/RETAILBANK_log.ldf',  
    SIZE = 100MB,  
    MAXSIZE = 2097152MB,  
    FILEGROWTH = 10MB) ;  
GO  

-- *********************Database Settings*********************

USE [master] ;  
ALTER DATABASE [RETAILBANK] SET RECOVERY SIMPLE; 


-- *********************Create Schema*********************

-- RETAILBANK SCHEMA
USE [RETAILBANK]
GO

CREATE SCHEMA [rtb]
GO


-- *********************Query Store Setup*********************
USE [Master]
GO

ALTER DATABASE RETAILBANK
SET QUERY_STORE (
    OPERATION_MODE = READ_WRITE,
    CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30),
    DATA_FLUSH_INTERVAL_SECONDS = 3000,
    MAX_STORAGE_SIZE_MB = 1000,
    INTERVAL_LENGTH_MINUTES = 10,
    SIZE_BASED_CLEANUP_MODE = AUTO,
    QUERY_CAPTURE_MODE = AUTO,
    MAX_PLANS_PER_QUERY = 1000
); 