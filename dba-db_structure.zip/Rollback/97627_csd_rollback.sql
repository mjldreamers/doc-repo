Use [master]
GO

DROP DATABASE csd
GO

DROP USER [csd_owner]
GO

DROP USER [csd_user]
GO