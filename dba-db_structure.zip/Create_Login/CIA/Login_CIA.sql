-- *********************Create Logins*********************

/****** Use Master ******/
USE [master]
GO

-- User [ACQ790UPS]  rewards user for Rewards DB
CREATE LOGIN [EXT170BAT] WITH PASSWORD=N''; -- Kindly create password example. ABC_123_bcd and send to DevSecOps
GO

-- Get SID on the Primary server
SELECT name, sid FROM sys.sql_logins WHERE name = 'EXT170BAT';
GO

-- Execute it on the other nodes with same SID since its in DAG
CREATE LOGIN [EXT170BAT]
WITH PASSWORD = '', SID = ; -- Type SID based on the SID of the Primary Server

--Provide screenshot that Check SID on all nodes
SELECT name, sid FROM sys.sql_logins WHERE name = 'EXT170BAT';
GO