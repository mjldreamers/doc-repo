USE [CIA]
GO

CREATE schema [cia]
GO

-- User [EXT170BAT]
CREATE USER [EXT170BAT] FOR LOGIN [EXT170BAT] WITH DEFAULT_SCHEMA=[cia]
GO

CREATE ROLE [ciarole] AUTHORIZATION [dbo];
GO

/****** Configure Roles ******/
-- ciarole
GRANT EXECUTE ON SCHEMA::[cia] TO [ciarole]
GO
GRANT INSERT ON SCHEMA::[cia] TO [ciarole]
GO
GRANT SELECT ON SCHEMA::[cia] TO [ciarole]
GO
GRANT UPDATE ON SCHEMA::[cia] TO [ciarole]
GO

/****** Configure user roles ******/
-- EXT170BAT Role
ALTER ROLE [ciarole] ADD MEMBER [EXT170BAT]
GO
