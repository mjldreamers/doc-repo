USE DATATOOLS_ML
GO

CREATE USER [DTM581BGR] FOR LOGIN [DTM581BGR] WITH DEFAULT_SCHEMA=[dbo]
GO
-- create role
CREATE ROLE [modelvisrole] AUTHORIZATION [dbo];
GO

-- Add new user to role
ALTER ROLE [modelvisrole] ADD MEMBER [DTM581BGR]
GO

-- grant permission to role
GRANT SELECT ON SCHEMA :: vis TO [modelvisrole];
GO
GRANT INSERT ON SCHEMA :: vis TO [modelvisrole];
GO
GRANT UPDATE ON SCHEMA :: vis TO [modelvisrole];
GO

GRANT SELECT ON SCHEMA :: reg TO [modelvisrole];
GO
GRANT INSERT ON SCHEMA :: reg TO [modelvisrole];
GO
GRANT UPDATE ON SCHEMA :: reg TO [modelvisrole];
GO

GRANT SELECT ON SCHEMA :: idc TO [modelvisrole];
GO
GRANT INSERT ON SCHEMA :: idc TO [modelvisrole];
GO
GRANT UPDATE ON SCHEMA :: idc TO [modelvisrole];
GO