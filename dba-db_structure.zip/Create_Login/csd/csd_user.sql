Use [master]
GO

-- User [DTS581NRE] - DataTools user in ONEPAM
CREATE LOGIN csd_owner WITH PASSWORD = '';-- Kindly create password example. ABC_123_bcd and send to DevSecOps
GO

CREATE LOGIN csd_user WITH PASSWORD = '';-- Kindly create password example. ABC_123_bcd and send to DevSecOps
GO

-- Get SID on the Primary server
SELECT name, sid FROM sys.sql_logins WHERE name = 'csd_owner';
GO

SELECT name, sid FROM sys.sql_logins WHERE name = 'csd_user';
GO

-- Execute it on the other nodes with same SID since its in DAG
CREATE LOGIN [csd_owner]
WITH PASSWORD = '', SID = ; -- Type SID based on the SID of the Primary Server

CREATE LOGIN [csd_user]
WITH PASSWORD = '', SID = ; -- Type SID based on the SID of the Primary Server

--Provide screenshot that Check SID on all nodes
SELECT name, sid FROM sys.sql_logins WHERE name = 'csd_owner';
GO

SELECT name, sid FROM sys.sql_logins WHERE name = 'csd_user';
GO