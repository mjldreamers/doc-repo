USE ONEPAM
GO

CREATE USER [DTS581NRE] FOR LOGIN [DTS581NRE] WITH DEFAULT_SCHEMA=[dbo]
GO
-- create role
CREATE ROLE [modelvisrole] AUTHORIZATION [dbo];
GO

-- Add new user to role
ALTER ROLE [modelvisrole] ADD MEMBER [DTS581NRE]
GO

-- grant permission to role
GRANT SELECT ON [rtb].[DOCUMENT_REPO] TO [modelvisrole]
GO

GRANT SELECT ON [rtb].[KYC_VERIFICATION] TO [modelvisrole]
GO

GRANT SELECT ON [rtb].[APPLICATION_TEMP_DATA] TO [modelvisrole]
GO
