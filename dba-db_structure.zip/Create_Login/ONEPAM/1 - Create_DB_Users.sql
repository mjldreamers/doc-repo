
-- *********************Create Logins*********************

/****** Use Master ******/
USE [master]
GO


/****** Create users ******/
-- User [JBR681DFG] for services
CREATE LOGIN [JBR681DFG] WITH PASSWORD=N'';
GO

-- User [AM325MDF] for batch
CREATE LOGIN [AM325MDF] WITH PASSWORD=N'';
GO

-- User [QWE432RST] for SRE
CREATE LOGIN [QWE432RST] WITH PASSWORD=N'';
GO

-- User [RPT512CNW] DB Reader
CREATE LOGIN [RPT512CNW] WITH PASSWORD=N'';
GO

-- User [MIG926BVA] for deployment
CREATE LOGIN [MIG926BVA] WITH PASSWORD=N'';
GO

-- User [QA245KH67] for ssrs
CREATE LOGIN [QA245KH67] WITH PASSWORD=N'';
GO

-- User [MLZTMQQ32] for AG
CREATE LOGIN [MLZTMQQ32] WITH PASSWORD=N'';
GO

-- for Vault
CREATE LOGIN [ingsecurityuser] WITH PASSWORD=N'';
GO
ALTER SERVER ROLE [securityadmin] ADD MEMBER [ingsecurityuser];
GO

-- create user for Log Extraction Batch
CREATE LOGIN [DYN312QUE] WITH PASSWORD=N'';
GO



/****** Allow Users to view server status for troubleshooting or performance tuning related activities ******/
GRANT VIEW ANY DEFINITION TO [QWE432RST];
GO
GRANT VIEW SERVER STATE TO [QWE432RST];
GO

GRANT VIEW ANY DEFINITION TO [MIG926BVA];
GO
GRANT VIEW SERVER STATE TO [MIG926BVA];
GO

/****** Allow User public role on master and execute on sys schema so they may access through SSMS ******/
-- User [QWE432RST]
CREATE USER [QWE432RST] FOR LOGIN [QWE432RST]
GO
GRANT EXECUTE ON SCHEMA::[sys] TO [QWE432RST]
GO

-- User [RPT512CNW]
CREATE USER [RPT512CNW] FOR LOGIN [RPT512CNW]
GO
GRANT EXECUTE ON SCHEMA::[sys] TO [RPT512CNW]
GO

-- User [MIG926BVA]
CREATE USER [MIG926BVA] FOR LOGIN [MIG926BVA]
GO
GRANT EXECUTE ON SCHEMA::[sys] TO [MIG926BVA]
GO

-- User [AM325MDF]
CREATE USER [AM325MDF] FOR LOGIN [AM325MDF]
GO
GRANT EXECUTE ON SCHEMA::[sys] TO [AM325MDF]
GO

-- Grant QWE432RST access to MSDB
USE [msdb]
GO

CREATE USER [QWE432RST] FOR LOGIN [QWE432RST]
GO
GRANT SELECT ON SCHEMA :: dbo TO QWE432RST;
GO
GRANT INSERT ON SCHEMA :: dbo TO QWE432RST;
GO
GRANT UPDATE ON SCHEMA :: dbo TO QWE432RST;
GO

-- create user cards
CREATE LOGIN [CRD546VML] WITH PASSWORD=N'';
GO

-- create user transaction History
CREATE LOGIN [THS235VJM] WITH PASSWORD=N'';
GO

-- create user Recon
-- create user
CREATE LOGIN [RCN293LFC] WITH PASSWORD=N'';
GO

-- create user Data&Tooling - Machine Learning
CREATE LOGIN [DTS581NRE] WITH PASSWORD=N'';
-- create user IAM/UAM
-- create user
CREATE LOGIN [IUM761LKH] WITH PASSWORD=N'';
GO

-- User [CHS267SRM] - ChatNotification user in ONEPAM
CREATE LOGIN [CHS267SRM] WITH PASSWORD=N''; -- Kindly create password example. ABC_123_bcd and send to DevSecOps
GO

-- Get SID on the Primary server
SELECT name, sid FROM sys.sql_logins WHERE name = 'CHS267SRM';
GO

-- Execute it on the other nodes with same SID since its in DAG
CREATE LOGIN [CHS267SRM]
WITH PASSWORD = '', SID = ; -- Type SID based on the SID of the Primary Server

--Provide screenshot that Check SID on all nodes
SELECT name, sid FROM sys.sql_logins WHERE name = 'CHS267SRM';
GO