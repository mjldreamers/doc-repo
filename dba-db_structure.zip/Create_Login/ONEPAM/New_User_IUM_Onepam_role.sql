Use [ONEPAM]
GO

-- add user to database
CREATE USER [IUM761LKH] FOR LOGIN [IUM761LKH] WITH DEFAULT_SCHEMA=[dbo]
GO

-- create role
CREATE ROLE [iumrole] AUTHORIZATION [dbo];
GO

-- Add new user to role
ALTER ROLE [iumrole] ADD MEMBER [IUM761LKH]
GO


-- grant permission to role
GRANT SELECT ON [opa].[policy_data_content] TO [iumrole]
GO
GRANT INSERT ON [opa].[policy_data_content] TO [iumrole]
GO


GRANT SELECT ON [opa].[service] TO [iumrole]
GO
GRANT UPDATE ON [opa].[service] TO [iumrole]
GO
GRANT INSERT ON [opa].[service] TO [iumrole]
GO


GRANT SELECT ON [opa].[policy_data] TO [iumrole]
GO
GRANT UPDATE ON [opa].[policy_data] TO [iumrole]
GO
GRANT INSERT ON [opa].[policy_data] TO [iumrole]
GO


GRANT SELECT ON [opa].[service_policy_data_map] TO [iumrole]
GO
GRANT UPDATE ON [opa].[service_policy_data_map] TO [iumrole]
GO
GRANT INSERT ON [opa].[service_policy_data_map] TO [iumrole]
GO


GRANT INSERT ON [opa].[audit_log]TO [iumrole]
GO


GRANT SELECT ON [iam].[user_record] TO [iumrole]
GO
GRANT UPDATE ON [iam].[user_record] TO [iumrole]
GO
GRANT INSERT ON [iam].[user_record] TO [iumrole]
GO


GRANT SELECT ON [iam].[user_profile] TO [iumrole]
GO
GRANT UPDATE ON [iam].[user_profile] TO [iumrole]
GO
GRANT INSERT ON [iam].[user_profile] TO [iumrole]
GO


GRANT SELECT ON [iam].[access_control] TO [iumrole]
GO
GRANT UPDATE ON [iam].[access_control] TO [iumrole]
GO
GRANT INSERT ON [iam].[access_control] TO [iumrole]
GO


GRANT SELECT ON [iam].[role_permission] TO [iumrole]
GO
GRANT UPDATE ON [iam].[role_permission] TO [iumrole]
GO
GRANT INSERT ON [iam].[role_permission] TO [iumrole]
GO


GRANT SELECT ON [iam].[function_definition] TO [iumrole]
GO

GRANT SELECT ON [iam].[ssrs_function_definition] TO [iumrole]
GO

GRANT SELECT ON [iam].[role_definition] TO [iumrole]
GO
GRANT UPDATE ON [iam].[role_definition] TO [iumrole]
GO
GRANT INSERT ON [iam].[role_definition] TO [iumrole]
GO

GRANT SELECT ON [iam].[assets_delegate] TO [iumrole]
GO
GRANT UPDATE ON [iam].[assets_delegate] TO [iumrole]
GO
GRANT INSERT ON [iam].[assets_delegate] TO [iumrole]
GO

GRANT SELECT ON [iam].[assets] TO [iumrole]
GO


GRANT SELECT ON [iam].[assets_role] TO [iumrole]
GO
GRANT UPDATE ON [iam].[assets_role] TO [iumrole]
GO
GRANT INSERT ON [iam].[assets_role] TO [iumrole]
GO

GRANT SELECT ON [sec].[access_requests] TO [iumrole]
GO
GRANT UPDATE ON [sec].[access_requests] TO [iumrole]
GO
GRANT INSERT ON [sec].[access_requests] TO [iumrole]
GO


GRANT SELECT ON [sec].[access_request_logs] TO [iumrole]
GO
GRANT INSERT ON [sec].[access_request_logs] TO [iumrole]
GO


GRANT SELECT ON [sec].[access_request_roles] TO [iumrole]
GO
GRANT INSERT ON [sec].[access_request_roles] TO [iumrole]
GO

GRANT SELECT ON [sec].[access_request_asset_approvals] TO [iumrole]
GO
GRANT UPDATE ON [sec].[access_request_asset_approvals] TO [iumrole]
GO
GRANT INSERT ON [sec].[access_request_asset_approvals] TO [iumrole]
GO
