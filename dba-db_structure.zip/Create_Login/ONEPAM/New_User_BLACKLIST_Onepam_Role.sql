USE ONEPAM;
GO

CREATE USER [BLK476NMD] FOR LOGIN [BLK476NMD] WITH DEFAULT_SCHEMA=[dbo]
GO
-- create role
CREATE ROLE [blacklistrole] AUTHORIZATION [dbo];
GO
-- Add new user to role
ALTER ROLE [blacklistrole] ADD MEMBER [BLK476NMD]
GO

-- grant permission to role
GRANT SELECT ON [rtb].[DOCUMENT_REPO] TO [blacklistrole]
GO
