-- *********************Create Logins*********************

/****** Use Master ******/
USE [master]
GO

-- User [PRS758DFE]  promo user for PROMO DB
CREATE LOGIN [PRS758DFE] WITH PASSWORD=N''; -- Kindly create password example. ABC_123_bcd and send to DevSecOps
GO

-- Get SID on the Primary server
SELECT name, sid FROM sys.sql_logins WHERE name = 'PRS758DFE';
GO

-- Execute it on the other nodes with same SID since its in DAG
CREATE LOGIN [PRS758DFE]
WITH PASSWORD = '', SID = ; -- Type SID based on the SID of the Primary Server

--Provide screenshot that Check SID on all nodes
SELECT name, sid FROM sys.sql_logins WHERE name = 'PRS758DFE';
GO

-- User [FND328PRM]  promo user for PROMO DB
CREATE LOGIN [FND328PRM] WITH PASSWORD=N''; -- Kindly create password example. ABC_123_bcd and send to DevSecOps
GO
 
-- Get SID on the Primary server
SELECT name, sid FROM sys.sql_logins WHERE name = 'FND328PRM';
GO
 
-- Execute it on the other nodes with same SID since its in DAG
CREATE LOGIN [FND328PRM]
WITH PASSWORD = '', SID = ; -- Type SID based on the SID of the Primary Server
 
--Provide screenshot that Check SID on all nodes
SELECT name, sid FROM sys.sql_logins WHERE name = 'FND328PRM';
GO







