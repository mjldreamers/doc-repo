/****** Allow users access to PROMOTIONS Database ******/
/****** Create Roles roles ******/
Use [PROMOTIONS]
GO

-- *********************Create Logins*********************

-- User [PRS758DFE]
CREATE USER [PRS758DFE] FOR LOGIN [PRS758DFE] WITH DEFAULT_SCHEMA=[dbo]
GO

CREATE ROLE [prmrole] AUTHORIZATION [dbo];
GO

CREATE ROLE [cbkrole] AUTHORIZATION [dbo];
GO

CREATE ROLE [crrole] AUTHORIZATION [dbo];
GO

-- User [FND328PRM]
CREATE USER [FND328PRM] FOR LOGIN [FND328PRM] WITH DEFAULT_SCHEMA=[dbo]
GO
 
CREATE ROLE [fndngrole] AUTHORIZATION [dbo];
GO
 
/****** Configure Roles ******/
-- prmrole
GRANT EXECUTE ON SCHEMA::[pmgt] TO [prmrole]
GO
GRANT INSERT ON SCHEMA::[pmgt] TO [prmrole]
GO
GRANT SELECT ON SCHEMA::[pmgt] TO [prmrole]
GO
GRANT UPDATE ON SCHEMA::[pmgt] TO [prmrole]
GO

-- cbkrole
GRANT EXECUTE ON SCHEMA::[cashbk] TO [cbkrole]
GO
GRANT INSERT ON SCHEMA::[cashbk] TO [cbkrole]
GO
GRANT SELECT ON SCHEMA::[cashbk] TO [cbkrole]
GO
GRANT UPDATE ON SCHEMA::[cashbk] TO [cbkrole]
GO
GRANT DELETE ON SCHEMA::[cashbk] TO [cbkrole]
GO
GRANT DELETE ON [cashbk].[CASHBACK_BATCH_JOB_EXECUTION_SEQ] TO [cbkrole]

-- crkrole
GRANT EXECUTE ON SCHEMA::[cashcr] TO [crrole]
GO
GRANT INSERT ON SCHEMA::[cashcr] TO [crrole]
GO
GRANT SELECT ON SCHEMA::[cashcr] TO [crrole]
GO
GRANT UPDATE ON SCHEMA::[cashcr] TO [crrole]
GO

GRANT DELETE ON  cashcr.BATCH_JOB_SEQ TO [crrole];
GO
GRANT DELETE ON  cashcr.BATCH_JOB_EXECUTION_SEQ TO [crrole];
GO
GRANT DELETE ON  cashcr.BATCH_STEP_EXECUTION_SEQ TO [crrole];
GO

-- fndngrole
GRANT INSERT ON SCHEMA::[fndng] TO [fndngrole]
GO
GRANT SELECT ON SCHEMA::[fndng] TO [fndngrole]
GO
GRANT UPDATE ON SCHEMA::[fndng] TO [fndngrole]
GO

/****** Configure user roles ******/
-- PRS758DFE Role
ALTER ROLE [prmrole] ADD MEMBER [PRS758DFE]
GO

ALTER ROLE [cbkrole] ADD MEMBER [PRS758DFE]
GO

ALTER ROLE [crrole] ADD MEMBER [PRS758DFE]
GO

-- FND328PRM Role
ALTER ROLE [fndngrole] ADD MEMBER [FND328PRM]
GO
 
ALTER ROLE [prmrole] ADD MEMBER [FND328PRM]
GO