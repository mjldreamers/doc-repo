
-- *********************Create Logins*********************

/****** Use Master ******/
USE [master]
GO

-- User [SEF556COL] coll user for LOANS DB
CREATE LOGIN SEF556COL WITH PASSWORD=N''; -- Kindly create password example. ABC_123_bcd and send to DevSecOps
GO

-- Get SID on the Primary server
SELECT name, sid FROM sys.sql_logins WHERE name = 'SEF556COL';
GO

-- Execute it on the other nodes with same SID since its in DAG
CREATE LOGIN SEF556COL
WITH PASSWORD = '', SID = ; -- Type SID based on the SID of the Primary Server

--Provide screenshot that Check SID on all nodes
SELECT name, sid FROM sys.sql_logins WHERE name = 'SEF556COL';
GO