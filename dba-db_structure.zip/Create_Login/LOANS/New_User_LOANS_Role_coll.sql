-- LOANS SCHEMA
USE [LOANS]
GO

CREATE SCHEMA coll
GO

-- User [SEF556COL]
CREATE USER SEF556COL FOR LOGIN SEF556COL WITH DEFAULT_SCHEMA=[coll]
GO

CREATE ROLE [collrole] AUTHORIZATION [dbo];
GO

/****** Configure user roles ******/
-- [lnsrole] Role
ALTER ROLE [collrole] ADD MEMBER [SEF556COL]
GO


/****** Configure Roles ******/
-- [collrole]
GRANT EXECUTE ON SCHEMA::[coll] TO [collrole]
GO
GRANT INSERT ON SCHEMA::[coll] TO [collrole]
GO
GRANT SELECT ON SCHEMA::[coll] TO [collrole]
GO
GRANT UPDATE ON SCHEMA::[coll] TO [collrole]
GO