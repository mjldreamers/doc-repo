Use [master]
GO

-- User [BLK089BPR] - Blacklist user in BLACLKLIST DB
CREATE LOGIN [BLK089BPR] WITH PASSWORD=N''; -- Kindly create password example. ABC_123_bcd and send to DevSecOps
GO

-- Get SID on the Primary server
SELECT name, sid FROM sys.sql_logins WHERE name = 'BLK089BPR';
GO

-- Execute it on the other nodes with same SID since its in DAG
CREATE LOGIN [BLK089BPR]
WITH PASSWORD = '', SID = ; -- Type SID based on the SID of the Primary Server

--Provide screenshot that Check SID on all nodes
SELECT name, sid FROM sys.sql_logins WHERE name = 'BLK089BPR';
GO


-- User [BLK476NMD] - Blacklist user in ONEPAM DB
CREATE LOGIN [BLK476NMD] WITH PASSWORD=N''; -- Kindly create password example. ABC_123_bcd and send to DevSecOps
GO

-- Get SID on the Primary server
SELECT name, sid FROM sys.sql_logins WHERE name = 'BLK476NMD';
GO

-- Execute it on the other nodes with same SID since its in DAG
CREATE LOGIN [BLK476NMD]
WITH PASSWORD = '', SID = ; -- Type SID based on the SID of the Primary Server

--Provide screenshot that Check SID on all nodes
SELECT name, sid FROM sys.sql_logins WHERE name = 'BLK476NMD';
GO
