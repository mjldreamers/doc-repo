USE [BLACKLIST]
GO

CREATE schema [blacklist]
GO

CREATE USER [BLK089BPR] FOR LOGIN [BLK089BPR] WITH DEFAULT_SCHEMA=[dbo]
GO
-- create role
CREATE ROLE [blacklistrole] AUTHORIZATION [dbo];
GO
-- Add new user to role
ALTER ROLE [blacklistrole] ADD MEMBER [BLK089BPR]
GO

GRANT EXECUTE ON SCHEMA::[blacklist] TO [blacklistrole]
GO
GRANT INSERT ON SCHEMA::[blacklist] TO [blacklistrole]
GO
GRANT SELECT ON SCHEMA::[blacklist] TO [blacklistrole]
GO
GRANT UPDATE ON SCHEMA::[blacklist] TO [blacklistrole]
GO