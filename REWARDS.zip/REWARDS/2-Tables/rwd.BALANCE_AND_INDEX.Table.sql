CREATE TABLE [rwd].[BALANCE_AND_INDEX] (
    [ID]                        [BIGINT] IDENTITY(1,1)            NOT NULL,
    [ACCOUNT_NUMBER]            [VARCHAR](12)                     NOT NULL,
    [PROFILE_ACCOUNT_NUMBER]    [VARCHAR](50)                     NOT NULL,
    [CIF]                       [VARCHAR](12)                     NOT NULL,
    [INVOLVED_PARTY_UUID]       [VARCHAR](36)                     NOT NULL,
    [PRODUCT_AGREEMENTS_UUID]   [VARCHAR](36)                     NOT NULL,
    [ACCOUNT_INDEX]             [VARCHAR](10)                     NULL,
    [EOD_BALANCE]               [NUMERIC](19,2)                   NULL,
    [HHAB]                      [NUMERIC](19,2)                   NULL,
    [ACCOUNT_OPENING_DATE]      [DATE]                            NOT NULL,
    [PRODUCT_TYPE]              [VARCHAR](8)                      NOT NULL,
    [ACCOUNT_STATUS]            [VARCHAR](50)                     NULL,
    [CREATED_DATETIME]          [DATETIME2](7)                    NOT NULL,
    [CREATED_BY]                [VARCHAR](150)                    NOT NULL,
    [UPDATED_DATETIME]          [DATETIME2](7)                    NULL,
    [UPDATED_BY]                [VARCHAR](150)                    NULL,
    [IS_RETURNING_CUSTOMER]     [CHAR](1)                         NULL,
    [CURRENT_ACTIVE_ACCOUNT_NBR][VARCHAR](50)                     NULL,
CONSTRAINT [PK_BALANCE_AND_INDEX] PRIMARY KEY CLUSTERED
(
    [ID] ASC
),
CONSTRAINT [AK_BALANCE_AND_INDEX_ACCOUNT] UNIQUE NONCLUSTERED
(
    [ACCOUNT_NUMBER] ASC
))
GO

ALTER TABLE [rwd].[BALANCE_AND_INDEX] ADD  CONSTRAINT [DF_BALANCE_AND_INDEX_UPDATED_DATETIME]  DEFAULT (getutcdate()) FOR [UPDATED_DATETIME]
GO
ALTER TABLE [rwd].[BALANCE_AND_INDEX] ADD  CONSTRAINT [DF_BALANCE_AND_INDEX_UPDATED_BY]  DEFAULT (suser_name()) FOR [UPDATED_BY]
GO
ALTER TABLE [rwd].[BALANCE_AND_INDEX] ADD  CONSTRAINT [DF_BALANCE_AND_INDEX_CREATED_DATETIME]  DEFAULT (getutcdate()) FOR [CREATED_DATETIME]
GO
ALTER TABLE [rwd].[BALANCE_AND_INDEX] ADD  CONSTRAINT [DF_BALANCE_AND_INDEX_CREATED_BY]  DEFAULT (suser_name()) FOR [CREATED_BY]
GO

