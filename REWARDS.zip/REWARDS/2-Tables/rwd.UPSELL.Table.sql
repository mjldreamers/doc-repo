CREATE TABLE [rwd].[UPSELL](
    [ID]                        [BIGINT] IDENTITY(1,1) NOT NULL,
    [CAMPAIGN_UUID]             [VARCHAR](36)          NOT NULL,
    [CAMPAIGN_NAME]             [VARCHAR](50)          NOT NULL,
    [CAMPAIGN_DESC]             [VARCHAR](500)         NULL,
    [PRODUCT_TYPE]              [VARCHAR](12)          NOT NULL,
    [IS_DELETED]                [CHAR](1)              NOT NULL,
    [CAMPAIGN_START]            [DATE]                 NOT NULL,
    [CAMPAIGN_END]              [DATE]                 NOT NULL,
    [CAMPAIGN_INDEX]            [VARCHAR](10)          NOT NULL,
    [CAMPAIGN_PERIOD]           [INT]                  NULL,
    [ALLOW_NEW_TO_BANK]         [CHAR](1)              NULL,
    [REFERENCE_BALANCE_POINT]   [VARCHAR](50)          NOT NULL,
    [ABSOLUTE_REFERENCE]        [INT]                  NULL,
    [CREATED_DATETIME]          [DATETIME2](7)         NOT NULL,
    [CREATED_BY]                [VARCHAR](150)         NOT NULL,
    [UPDATED_DATETIME]          [DATETIME2](7)         NULL,
    [UPDATED_BY]                [VARCHAR](150)         NULL,
    [STATUS]                    [VARCHAR](50)          NULL,
    CONSTRAINT [PK_UPSELL] PRIMARY KEY CLUSTERED
    (
      [ID] ASC
    ),
    CONSTRAINT [UQ_rwd.UPSELL_CAMPAIGN_UUID] UNIQUE NONCLUSTERED
    (
           [CAMPAIGN_UUID] ASC
    )
) 
GO
 
ALTER TABLE [rwd].[UPSELL] ADD  CONSTRAINT [DF_UPSELL_UPDATED_DATETIME]  DEFAULT (getutcdate()) FOR [UPDATED_DATETIME]
GO
ALTER TABLE [rwd].[UPSELL] ADD  CONSTRAINT [DF_UPSELL_UPDATED_BY]  DEFAULT (suser_name()) FOR [UPDATED_BY]
GO
ALTER TABLE [rwd].[UPSELL] ADD  CONSTRAINT [DF_UPSELL_CREATED_DATETIME]  DEFAULT (getutcdate()) FOR [CREATED_DATETIME]
GO
ALTER TABLE [rwd].[UPSELL] ADD  CONSTRAINT [DF_UPSELL_CREATED_BY]  DEFAULT (suser_name()) FOR [CREATED_BY]
GO
 