
CREATE TABLE [rpt].[WAT_Rule_Type_PTM_BULKMANUAL](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[RULE_NAME] [varchar](10) NULL,
	[Logic_Code] [varchar](5) NULL,
	[Logic_Type] [varchar](5) NULL,
	[Logic_Desc] [varchar](500) NULL,
	[Created_By] [varchar](100) NULL,
	[Created_Datetime] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
),
 CONSTRAINT [AK_RPT_WRT_PTM_BULKMANUAL] UNIQUE NONCLUSTERED 
(
	[RULE_NAME] ASC
)
) ON [PRIMARY]
GO

ALTER TABLE [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] ADD  DEFAULT (suser_name()) FOR [Created_By]
GO

ALTER TABLE [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] ADD  DEFAULT (getutcdate()) FOR [Created_Datetime]
GO
