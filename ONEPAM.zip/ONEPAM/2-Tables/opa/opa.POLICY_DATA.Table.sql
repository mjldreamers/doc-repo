CREATE TABLE [opa].[POLICY_DATA]
(
    [NAME]                      [nvarchar](100)            NOT NULL,
    [PATH]                      [nvarchar](100)            NOT NULL,
    [TYPE]                      [nvarchar](50)             NOT NULL,
    [UPDATED_BY]                [nvarchar](100)            NULL,
    [UPDATED_DATETIME]          [datetime]                 NULL,
    [CREATED_BY]                [nvarchar](100)            NOT NULL,
    [CREATED_DATETIME]          [datetime]                 NOT NULL,
    CONSTRAINT [PK_POLICY_DATA] PRIMARY KEY CLUSTERED (NAME, TYPE)
)