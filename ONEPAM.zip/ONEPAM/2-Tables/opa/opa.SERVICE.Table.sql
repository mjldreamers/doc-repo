CREATE TABLE [opa].[SERVICE]
(
    [NAME]                      [nvarchar](100)            NOT NULL,
    [DOMAIN]                    [nvarchar](100)            NOT NULL,
    [ACTIVE]                    [char](1)                  NOT NULL,
    [UPDATED_BY]                [nvarchar](150)            NULL,
    [UPDATED_DATETIME]          [datetime]                 NULL,
    [CREATED_BY]                [nvarchar](150)            NOT NULL,
    [CREATED_DATETIME]          [datetime]                 NOT NULL,
    CONSTRAINT [PK_SERVICE] PRIMARY KEY CLUSTERED (NAME)
)