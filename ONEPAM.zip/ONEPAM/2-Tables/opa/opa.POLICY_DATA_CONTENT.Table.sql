CREATE TABLE [opa].[POLICY_DATA_CONTENT]
(
    [ID]                        [bigint]                   NOT NULL IDENTITY(1,1),
    [NAME]                      [nvarchar](100)            NOT NULL,
    [TYPE]                      [nvarchar](50)             NOT NULL,
    [VERSION]                   [nvarchar](100)            NOT NULL,
    [FILE_NAME]                 [nvarchar](100)            NOT NULL,
    [CONTENT]                   [varchar](max)             NOT NULL,
    [EFFECTIVE_DATETIME]        [datetime]                 NOT NULL,
    [EXPIRY_DATETIME]           [datetime]                 NOT NULL,
    [UPDATED_BY]                [nvarchar](150)            NULL,
    [UPDATED_DATETIME]          [datetime]                 NULL,
    [CREATED_BY]                [nvarchar](150)            NOT NULL,
    [CREATED_DATETIME]          [datetime]                 NOT NULL,
    CONSTRAINT [PK_POLICY_DATA_CONTENT] PRIMARY KEY CLUSTERED ([ID] ASC)
)
GO
ALTER TABLE [opa].[POLICY_DATA_CONTENT]
    ADD CONSTRAINT FK_POLICY_DATA_CONTENT_POLICY_DATA FOREIGN KEY (NAME, TYPE)
    REFERENCES [opa].[POLICY_DATA] (NAME, TYPE);