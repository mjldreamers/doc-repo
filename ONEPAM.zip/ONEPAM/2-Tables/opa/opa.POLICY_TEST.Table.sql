CREATE TABLE [opa].[POLICY_TEST]
(
    [ID]                        [bigint]                   NOT NULL IDENTITY(1,1),
    [POLICY_DATA_CONTENT_ID]    [bigint]                   NOT NULL,
    [CONTENT]                   [varchar](max)             NOT NULL,
    [UPDATED_BY]                [nvarchar](150)            NULL,
    [UPDATED_DATETIME]          [datetime]                 NULL,
    [CREATED_BY]                [nvarchar](150)            NOT NULL,
    [CREATED_DATETIME]          [datetime]                 NOT NULL,
    CONSTRAINT [PK_POLICY_TEST] PRIMARY KEY CLUSTERED ([ID] ASC)
)