CREATE TABLE [opa].[AUDIT_LOG]
(
    [ID]                    [bigint]                       NOT NULL IDENTITY(1,1),
    [LOG_DATETIME]          [datetime]                     NOT NULL,
    [APPLICATION]           [nvarchar](100)                NULL,
    [SOURCE_SYSTEM]         [nvarchar](100)                NULL,
    [ACTION_TYPE]           [nvarchar](50)                 NOT NULL,
    [DETAILS]               [nvarchar](4000)               NOT NULL DEFAULT ('Default details') ,
    [ACTOR]                 [nvarchar](50)                 NOT NULL,
    [IP_ADDRESS]            [nvarchar](20)                 NOT NULL,
    [RESULT]                [nvarchar](20)                 NOT NULL DEFAULT ('ACCEPTED'),
    [CREATED_BY]            [nvarchar](150)                NOT NULL,
    [CREATED_DATETIME]      [datetime]                     NOT NULL,
    [ADVICE_TYPE]           [NVARCHAR](100)                NOT NULL DEFAULT ('AFTER_SUCCESS'),
    [UPDATED_BY]            [NVARCHAR](150)                NULL,
    [UPDATED_DATETIME]      [DATETIME2]                    NULL,
    CONSTRAINT [PK_AUDIT_LOG] PRIMARY KEY CLUSTERED ([ID] ASC)
)

ALTER TABLE [opa].[AUDIT_LOG] ADD  CONSTRAINT [DF_AUDIT_LOG_CREATED_BY]  DEFAULT (suser_sname()) FOR [CREATED_BY]
GO
ALTER TABLE [opa].[AUDIT_LOG] ADD  CONSTRAINT [DF_AUDIT_LOG_CREATED_DATETIME]  DEFAULT (getutcdate()) FOR [CREATED_DATETIME]
GO
ALTER TABLE [opa].[AUDIT_LOG] ADD  CONSTRAINT [DF_AUDIT_LOG_UPDATED_BY]  DEFAULT (suser_sname()) FOR [UPDATED_BY]
GO
ALTER TABLE [opa].[AUDIT_LOG] ADD  CONSTRAINT [DF_AUDIT_LOG_UPDATED_DATETIME]  DEFAULT (getutcdate()) FOR [UPDATED_DATETIME]
GO
