CREATE TABLE [swt].[ATM_BALANCE_INQUIRY_TRANSACTION](
    [ID]                                        [bigint] IDENTITY(1,1)  NOT NULL,
    [ACCOUNT_NUMBER]                            [varchar](12)           COLLATE Latin1_General_BIN2 ENCRYPTED WITH (ENCRYPTION_TYPE = DETERMINISTIC, ALGORITHM = 'AEAD_AES_256_CBC_HMAC_SHA_256', COLUMN_ENCRYPTION_KEY = ONEPAM_SWT_CEK) NULL,
    [CARD_NUMBER]                               [varchar](16)           COLLATE Latin1_General_BIN2 ENCRYPTED WITH (ENCRYPTION_TYPE = DETERMINISTIC, ALGORITHM = 'AEAD_AES_256_CBC_HMAC_SHA_256', COLUMN_ENCRYPTION_KEY = ONEPAM_SWT_CEK) NULL,
    [STATUS]                                    [varchar](10)           NULL,
    [SETTLEMENT_FEE_AMOUNT]                     [decimal](19, 2)        NULL,
    [SETTLEMENT_FEE_CURRENCY]                   [varchar](3)            NULL,
    [TRANSACTION_FEE_AMOUNT]                    [decimal](19, 2)        NULL,
    [TRANSACTION_FEE_CURRENCY]                  [varchar](3)            NULL,
    [PROCESSING_FEE_AMOUNT]                     [decimal](19, 2)        NULL,
    [AVAILABLE_BALANCE_AMOUNT]                  [decimal](19, 2)        NULL,
    [CURRENT_BALANCE_AMOUNT]                    [decimal](19, 2)        NULL,
    [RETRIEVAL_REFERENCE_NUMBER]                [varchar](12)           NULL,
    [SYSTEM_TRACE_AUDIT_NUMBER]                 [varchar](6)            NULL,
    [TRANSMISSION_DATETIME]                     [varchar](10)           NULL,
    [LOCAL_TRANSACTION_DATETIME]                [varchar](10)           NULL,
    [ACQUIRER_INSTITUTION_CODE]                 [varchar](11)           NULL,
    [CARD_ACCEPTOR_ID]                          [varchar](20)           NULL,
    [CARD_ACCEPTOR_TERMINAL_ID]                 [varchar](8)            NULL,
    [FORWARDING_INSTITUTION_CODE]               [varchar](20)           NULL,
    [MERCHANT_CATEGORY_CODE]                    [varchar](10)           NULL,
    [POS_ENTRY_MODE]                            [varchar](3)            NULL,
    [APPROVAL_CODE]                             [varchar](6)            NULL,
    [SETTLEMENT_DATE]                           [varchar](7)            NULL,
    [TRACK2]                                    [varchar](255)          NULL,
    [CARD_ACCEPTOR_NAME]                        [varchar](50)           NULL,
    [CARD_ACCEPTOR_CITY]                        [varchar](50)           NULL,
    [CARD_ACCEPTOR_STATE]                       [varchar](50)           NULL,
    [CARD_ACCEPTOR_COUNTRY]                     [varchar](50)           NULL,
    [CARD_ACCOUNT_NBR_KEY]                      [varchar](128)          NULL,
    [RECEIPT_NUMBER]                            [varchar](16)           NULL,
    [BATCH_TRANSACTION_REF]                     [varchar](64)           NULL,
    [DEBIT_AMT_TRANSACTION_REF]                 [varchar](64)           NULL,
    [CREDIT_AMT_TRANSACTION_REF]                [varchar](64)           NULL,
    [PROC_FEE_TRANSACTION_REF]                  [varchar](100)          NULL,
    [RECEIVED_DATETIME]                         [datetime2](7)          NULL,
    [TRANSACTION_IDENTIFIER]                    [varchar](15)           NULL,
    [MESSAGE_ID]                                [varchar](36)           NULL,
    [IS_REVERSAL]                               [varchar](5)            NULL,
    [REMARKS]                                   [varchar](255)          NULL,
    [CARD_REFERENCE]                            [varchar](36)           NULL,
    [UPDATED_BY]                                [varchar](100)          NULL,
    [UPDATED_DATETIME]                          [datetime2](7)          NULL,
    [CREATED_BY]                                [varchar](100)          NOT NULL,
    [CREATED_DATETIME]                          [datetime2](7)          NOT NULL,
    [STAND_IN]                                  [varchar](1)            NULL
) ON [PRIMARY]
GO
ALTER TABLE [swt].[ATM_BALANCE_INQUIRY_TRANSACTION] ADD  CONSTRAINT [PK_ATM_BALANCE_INQUIRY_TRANSACTION] PRIMARY KEY CLUSTERED
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [swt].[ATM_BALANCE_INQUIRY_TRANSACTION] ADD CONSTRAINT [DF_ATM_BALANCE_INQUIRY_TRANSACTION_CREATEDDATE_TIME] DEFAULT (getutcdate()) FOR [CREATED_DATETIME]
GO
ALTER TABLE [swt].[ATM_BALANCE_INQUIRY_TRANSACTION] ADD CONSTRAINT [DF_ATM_BALANCE_INQUIRY_TRANSACTION_CREATED_BY] DEFAULT (suser_sname()) FOR [CREATED_BY]
GO
ALTER TABLE [swt].[ATM_BALANCE_INQUIRY_TRANSACTION] ADD CONSTRAINT [DF_ATM_BALANCE_INQUIRY_TRANSACTION_UPDATED_BY] DEFAULT (suser_sname()) FOR [UPDATED_BY]
GO