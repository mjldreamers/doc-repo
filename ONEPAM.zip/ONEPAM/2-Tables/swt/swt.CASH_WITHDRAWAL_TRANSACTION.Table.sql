CREATE TABLE [swt].[CASH_WITHDRAWAL_TRANSACTION](
[ID]                                        [bigint] IDENTITY(1,1)  NOT NULL,
[CARD_NUMBER]                               [varchar](19)           COLLATE Latin1_General_BIN2 ENCRYPTED WITH (ENCRYPTION_TYPE = DETERMINISTIC, ALGORITHM = 'AEAD_AES_256_CBC_HMAC_SHA_256', COLUMN_ENCRYPTION_KEY = ONEPAM_SWT_CEK) NULL,
[ACCOUNT_NUMBER]                            [varchar](12)           COLLATE Latin1_General_BIN2 ENCRYPTED WITH (ENCRYPTION_TYPE = DETERMINISTIC, ALGORITHM = 'AEAD_AES_256_CBC_HMAC_SHA_256', COLUMN_ENCRYPTION_KEY = ONEPAM_SWT_CEK) NULL,
[SYSTEM_TRACE_AUDIT_NUMBER]                 [varchar](6)            NULL,
[RETRIEVAL_REFERENCE_NUMBER]                [varchar](12)           NULL,
[TRANSMISSION_DATETIME]                     [varchar](10)           NULL,
[IS_REVERSAL]                               [varchar](1)            NULL,
[STATUS]                                    [varchar](20)           NULL,
[CARD_HOLDER_BILLING_AMOUNT]                [decimal](19, 2)        NULL,
[SETTLEMENT_AMOUNT]                         [decimal](19, 2)        NULL,
[SETTLEMENT_FEE_AMOUNT]                     [decimal](19, 2)        NULL,
[SETTLEMENT_CURRENCY]                       [varchar](3)            NULL,
[SETTLEMENT_DATE]                           [varchar](4)            NULL,
[CONVERSION_RATE]                           [decimal](19, 2)        NULL,
[TRANSACTION_AMOUNT]                        [decimal](19, 2)        NULL,
[TRANSACTION_FEE_AMOUNT]                    [decimal](19, 2)        NULL,
[MARK_UP_AMOUNT]                            [decimal](19, 2)        NULL,
[PROCESSING_FEE_AMOUNT]                     [decimal](19, 2)        NULL,
[TRANSACTION_CURRENCY]                      [varchar](3)            NULL,
[LOCAL_TRANSACTION_DATETIME]                [varchar](10)           NULL,
[ACQUIRER_INSTITUTION_CODE]                 [varchar](11)           NULL,
[FORWARDING_INSTITUTION_CODE]               [varchar](11)           NULL,
[MERCHANT_CATEGORY_CODE]                    [varchar](4)            NULL,
[CARD_ACCEPTOR_NAME]                        [varchar](25)           NULL,
[CARD_ACCEPTOR_CITY]                        [varchar](15)           NULL,
[CARD_ACCEPTOR_STATE]                       [varchar](2)            NULL,
[CARD_ACCEPTOR_COUNTRY]                     [varchar](2)            NULL,
[CARD_ACCEPTOR_TERMINAL_ID]                 [varchar](8)            NULL,
[CARD_ACCEPTOR_ID]                          [varchar](15)           NULL,
[POS_ENTRY_MODE]                            [varchar](3)            NULL,
[REMARKS]                                   [varchar](1000)         NULL,
[TRACK2]                                    [varchar](255)          NULL,
[APPROVAL_CODE]                             [varchar](6)            NULL,
[AVAILABLE_BALANCE_AMOUNT]                  [decimal](19, 2)        NULL,
[CURRENT_BALANCE_AMOUNT]                    [decimal](19, 2)        NULL,
[RECEIPT_NUMBER]                            [varchar](16)           NULL,
[MESSAGE_ID]                                [varchar](36)           NULL,
[BATCH_TRANSACTION_REF]                     [varchar](50)           NULL,
[DEBIT_AMT_TRANSACTION_REF]                 [varchar](50)           NULL,
[CREDIT_AMT_TRANSACTION_REF]                [varchar](50)           NULL,
[ACQUIRER_FEE_TRANSACTION_REF]              [varchar](50)           NULL,
[MARK_UP_TRANSACTION_REF]                   [varchar](50)           NULL,
[PROC_FEE_TRANSACTION_REF]                  [varchar](100)          NULL,
[REPLACEMENT_AMOUNT]                        [varchar](60)           NULL,
[CARD_ACCOUNT_NBR_KEY]                      [varchar](128)          NULL,
[TRANSACTION_IDENTIFIER]                    [varchar](15)           NULL,
[RECEIVED_DATETIME]                         [datetime2](7)          NOT NULL,
[CARD_REFERENCE]                            [varchar](36)           NULL,
[CREATED_BY]                                [varchar](100)          NULL,
[CREATED_DATETIME]                          [datetime2](7)          NOT NULL,
[UPDATED_BY]                                [varchar](50)           NULL,
[UPDATED_DATETIME]                          [datetime2](7)          NULL,
[STAND_IN]                                  [varchar](1)            NULL
) ON [PRIMARY]
GO
ALTER TABLE [swt].[CASH_WITHDRAWAL_TRANSACTION] ADD CONSTRAINT [PK_CASH_WITHDRAWAL_TRANSACTION] PRIMARY KEY CLUSTERED
(
[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [swt].[CASH_WITHDRAWAL_TRANSACTION] ADD CONSTRAINT [DF_CASH_WITHDRAWAL_TRANSACTION_CREATEDDATE_TIME] DEFAULT (getutcdate()) FOR [CREATED_DATETIME]
GO
ALTER TABLE [swt].[CASH_WITHDRAWAL_TRANSACTION] ADD CONSTRAINT [DF_CASH_WITHDRAWAL_TRANSACTION_CREATED_BY] DEFAULT (suser_sname()) FOR [CREATED_BY]
GO
ALTER TABLE [swt].[CASH_WITHDRAWAL_TRANSACTION] ADD CONSTRAINT [DF_CASH_WITHDRAWAL_TRANSACTION_UPDATED_DATETIME] DEFAULT (getutcdate()) FOR [UPDATED_DATETIME]
GO
ALTER TABLE [swt].[CASH_WITHDRAWAL_TRANSACTION] ADD CONSTRAINT [DF_CASH_WITHDRAWAL_TRANSACTION_UPDATED_BY] DEFAULT (suser_sname()) FOR [UPDATED_BY]
GO