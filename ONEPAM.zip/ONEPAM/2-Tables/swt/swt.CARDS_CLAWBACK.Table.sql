CREATE TABLE [swt].[CARDS_CLAWBACK](
	[ID] 									[bigint] IDENTITY(1,1)  NOT NULL,
	[TRANSACTION_TYPE] 						[varchar](15) 			NULL,
	[ACCOUNT_NUMBER] 						[varchar](12) 			NOT NULL,
	[CARD_NUMBER] 							[varchar](19) COLLATE Latin1_General_BIN2 ENCRYPTED WITH (ENCRYPTION_TYPE = DETERMINISTIC, ALGORITHM = 'AEAD_AES_256_CBC_HMAC_SHA_256', COLUMN_ENCRYPTION_KEY = ONEPAM_SWT_CEK) NULL,
	[SWITCH_ISO_HISTORY_MSG_ID]				[varchar](36)			NOT NULL,
	[SYSTEM_TRACE_AUDIT_NUMBER]             [varchar](6)            NULL,
	[RETRIEVAL_REFERENCE_NUMBER]            [varchar](12)           NULL,
	[BATCH_TRANSACTION_REF]                 [varchar](100)          NULL,
	[SETTLEMENT_AMOUNT]                     [decimal](19, 2)        NULL,
    [SETTLEMENT_FEE_AMOUNT]                 [decimal](19, 2)        NULL,
    [SETTLEMENT_CURRENCY]                   [varchar](3)            NULL,
    [SETTLEMENT_DATE]                       [varchar](4)            NULL,
    [CONVERSION_RATE]                       [decimal](19, 2)        NULL,
    [TRANSACTION_AMOUNT]                    [decimal](19, 2)        NULL,
	[PERM_HOLD_ID] 							[bigint] 				NULL,
	[PERM_HOLD_SEQ] 						[bigint] 				NULL,
	[STATUS] 								[varchar](23) 			NOT NULL,
	[CLAWBACK_STATUS] 						[varchar](23) 			NOT NULL,
	[CARD_ACCOUNT_NBR_KEY]                  [varchar](128)          NULL,
	[CREATED_DATETIME] 						[datetime2](7) 			NULL,
	[CREATED_BY] 							[varchar](150) 			NULL,
	[UPDATED_DATETIME] 						[datetime2](7) 			NULL,
	[UPDATED_BY] 							[varchar](150) 			NULL
 	CONSTRAINT [PK_CARDS_CLAWBACK] PRIMARY KEY CLUSTERED
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [swt].[CARDS_CLAWBACK] ADD  CONSTRAINT [DF_CARDS_CLAWBACK_CREATED_DATETIME]  DEFAULT (getutcdate()) FOR [CREATED_DATETIME]
GO
ALTER TABLE [swt].[CARDS_CLAWBACK] ADD  CONSTRAINT [DF_CARDS_CLAWBACK_CREATED_BY]  DEFAULT (suser_sname()) FOR [CREATED_BY]
GO
ALTER TABLE [swt].[CARDS_CLAWBACK] ADD  CONSTRAINT [DF_CARDS_CLAWBACK_UPDATED_DATETIME]  DEFAULT (getutcdate()) FOR [UPDATED_DATETIME]
GO
ALTER TABLE [swt].[CARDS_CLAWBACK] ADD  CONSTRAINT [DF_CARDS_CLAWBACK_UPDATED_BY]  DEFAULT (suser_sname()) FOR [UPDATED_BY]
GO