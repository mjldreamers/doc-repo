CREATE TABLE [recon].[BNET_BILLS_OUT](
     [ID]                          [BIGINT] IDENTITY (1, 1)  NOT NULL,
     [RECON_FILE_UPLOAD_ID]        [BIGINT]                  NOT NULL,
     [ACQUIRER_BANK_CODE]          [VARCHAR](4)              NULL,
     [ACQUIRER_TERMINAL_ID]        [VARCHAR](8)              NULL,
     [ISSUER_CODE]                 [VARCHAR](4)              NULL,
     [TXN_DATE]                    [DATE]                    NOT NULL,
     [TXN_TIME]                    [TIME]                    NOT NULL,
     [BNET_SEQ_NUMBER]             [VARCHAR](6)              NULL,
     [ACQUIRER_TRACE_NUMBER]       [VARCHAR](6)              NULL,
     [TXN_CODE]                    [VARCHAR](3)              NULL,
     [ACCOUNT_NUMBER]              [VARCHAR](16)             NULL,
     [CARD_NUMBER]                 [NVARCHAR](20)            NULL,
     [AMOUNT]                      [DECIMAL](19, 2)          NULL,
     [REV_CODE]                    [VARCHAR](3)              NULL,
     [TRANSFEREE_BANK_CODE]        [VARCHAR](4)              NULL,
     [TRANSFEREE_ACCT_NUMBER]      [VARCHAR](16)             NULL,
     [MERCHANT_ID]                 [VARCHAR](15)             NULL,
     [BILLER_CODE]                 [VARCHAR](4)              NULL,
     [SUBSCRIBER_NUMBER]           [VARCHAR](16)             NULL,
     [DEPOSITORY_BANK_CODE]        [VARCHAR](4)              NULL,
     [BPS_FEE_AMOUNT]              [DECIMAL](19, 2)          NULL,
     [NET_AMOUNT]                  [DECIMAL](19, 2)          NULL,
     [BPS_ACQUIRER_SHARE]          [DECIMAL](19, 2)          NULL,
     [BPS_ISSUER_SHARE]            [DECIMAL](19, 2)          NULL,
     [ACQUIRER_NETWORK_FLAG]       [VARCHAR](1)              NULL,
     [ACQUIRER_TERMINAL_AREA_CODE] [VARCHAR](1)              NULL,
     [ISSUER_NETWORK_FLAG]         [VARCHAR](1)              NULL,
     [CHANNEL_DEVICE_USED]         [VARCHAR](1)              NULL,
     [ACCOUNT_TYPE]                [VARCHAR](2)              NULL,
     [BILLER_NAME]                 [VARCHAR](30)             NULL,
     [BPS_BANCNET_SHARE]           [DECIMAL](19, 2)          NULL,
     [CREATED_DATETIME]            [DATETIME2](7)            NOT NULL,
     [UPDATED_DATETIME]            [DATETIME2](7)            NULL,
     [CREATED_BY]                  [VARCHAR](150)            NOT NULL,
     [UPDATED_BY]                  [VARCHAR](150)            NULL,
     [BILLER_CODE_CONV]            [VARCHAR](4)              NULL
         CONSTRAINT [PK_BNET_BILLS_OUT] PRIMARY KEY CLUSTERED
             (
              [ID] ASC
                 )
             WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
         ON [PRIMARY]
) ON [PRIMARY]
GO




ALTER TABLE [recon].[BNET_BILLS_OUT]
    ADD CONSTRAINT [DF_BNET_BILLS_OUT_CREATED_DATETIME] DEFAULT (GETUTCDATE()) FOR [CREATED_DATETIME]
GO
ALTER TABLE [recon].[BNET_BILLS_OUT]
    ADD CONSTRAINT [DF_BNET_BILLS_OUT_CREATED_BY] DEFAULT (SUSER_SNAME()) FOR [CREATED_BY]
GO
ALTER TABLE [recon].[BNET_BILLS_OUT]
    WITH CHECK ADD  CONSTRAINT [FK_BNET_BILLS_OUT_RECON_FILE_UPLOAD] FOREIGN KEY([RECON_FILE_UPLOAD_ID])
        REFERENCES [recon].[RECON_FILE_UPLOAD] ([ID])
GO
