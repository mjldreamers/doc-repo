CREATE TABLE [rtb].[BANK_CERT](
	[ID]                  [BIGINT] IDENTITY(1,1) NOT NULL,
    [LOCATION_CD]         [VARCHAR](5)           NULL,
    [BANK_CERT_ID]        [VARCHAR](36)          NOT NULL UNIQUE,
    [REFERENCE_CD]        [VARCHAR](18)          NOT NULL UNIQUE,
    [PARTY_UUID]          [VARCHAR](36)          NOT NULL,
    [PURPOSE_CD]          [VARCHAR](15)          NOT NULL,
    [ADDRESSEE]           [VARCHAR](100)         NULL,
    [ADDRESS]             [VARCHAR](250)         NULL,
    [COUNTRY_CD]          [VARCHAR](2)           NULL,
    [ZIPCODE]             [VARCHAR](10)          NULL,
    [CITY]                [VARCHAR](40)          NULL,
    [DELETED]             [CHAR]                 NULL,

    [CREATED_DATETIME]    [DATETIME2](7)         NOT NULL,
    [CREATED_BY]          [VARCHAR](150)         NOT NULL,
    [UPDATED_DATETIME]    [DATETIME2](7)         NULL,
    [UPDATED_BY]          [VARCHAR](150)         NULL,
    CONSTRAINT [PK_BANK_CERT] PRIMARY KEY CLUSTERED
    (
      [ID] ASC
    )
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [ONEPAMRTBSEC]
) ON [ONEPAMRTBSEC]
GO
