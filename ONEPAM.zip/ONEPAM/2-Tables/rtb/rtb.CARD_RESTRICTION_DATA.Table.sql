CREATE TABLE [rtb].[CARD_RESTRICTION_DATA](
   [ID]                  [BIGINT] IDENTITY(1,1) NOT NULL,
    [CIF]                 [VARCHAR](36)          NOT NULL,
    [UUID]                [VARCHAR](36)          NOT NULL,
    [ACCOUNTNO]           [VARCHAR](36)          NULL,
    [STATUS]              [VARCHAR](256)         NOT NULL,
    [REMARKS]             [VARCHAR](256)         NOT NULL,
    [REQUEST_STATUS]      [VARCHAR](256)         NOT NULL,
    [DELETED]             [BIT]                  NULL,
    [CREATED_DATETIME]    [DATETIME2](7)         NOT NULL,
    [CREATED_BY]          [VARCHAR](64)          NOT NULL,
    [UPDATED_DATETIME]    [DATETIME2](7)         NULL,
    [UPDATED_BY]          [VARCHAR](64)          NULL,
   CONSTRAINT [PK_CARD_RESTRICTION_DATA] PRIMARY KEY CLUSTERED
    (
      [ID] ASC
    )
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [ONEPAMRTBSEC]
) ON [ONEPAMRTBSEC]
GO