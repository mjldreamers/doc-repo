CREATE TABLE [rtb].[KYC_NS_PROCESS_LOG](
    [PROCESS_LOG_ID]            [varchar](36)       NOT NULL,
    [CIF]                       [nvarchar](50)      NOT NULL,
    [REQUEST]                   [nvarchar](4000)    NULL,
    [REQUEST_DATETIME]          [datetime2](7)      NULL,
    [RESPONSE]                  [nvarchar](4000)    NULL,
    [RESPONSE_DATETIME]         [datetime2](7)      NULL,
    [IS_SUCCESS]                [bit]               NULL,
    [IS_NS_TURNED_ON]           [bit]               NULL,
    [UPDATED_DATETIME]          [datetime2](7)      NULL,
    [CREATED_DATETIME]          [datetime2](7)      NOT NULL,
    [UPDATED_BY]                [varchar](150)      NULL,
    [CREATED_BY]                [varchar](150)      NOT NULL,

    CONSTRAINT [PK_KYC_NS_PROCESS_LOG] PRIMARY KEY CLUSTERED ([PROCESS_LOG_ID] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [rtb].[KYC_NS_PROCESS_LOG] ADD CONSTRAINT [DF_KYC_NS_PROCESS_LOG_UPDATED_DATE] DEFAULT (getutcdate()) FOR [UPDATED_DATETIME]
GO
ALTER TABLE [rtb].[KYC_NS_PROCESS_LOG] ADD CONSTRAINT [DF_KYC_NS_PROCESS_LOG_CREATED_DATE] DEFAULT (getutcdate()) FOR [CREATED_DATETIME]
GO
ALTER TABLE [rtb].[KYC_NS_PROCESS_LOG] ADD CONSTRAINT [DF_KYC_NS_PROCESS_LOG_UPDATED_BY] DEFAULT (suser_sname()) FOR [UPDATED_BY]
GO
ALTER TABLE [rtb].[KYC_NS_PROCESS_LOG] ADD CONSTRAINT [DF_KYC_NS_PROCESS_LOG_CREATED_BY] DEFAULT (suser_sname()) FOR [CREATED_BY]
GO