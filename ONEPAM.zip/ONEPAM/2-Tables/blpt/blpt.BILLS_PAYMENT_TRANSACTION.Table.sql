CREATE TABLE [blpt].[BILLS_PAYMENT_TRANSACTION](
    [ID]                        [BIGINT]           IDENTITY(1,1)    NOT NULL,
    [BILLER_ID]                 [VARCHAR](255)                      NOT NULL,
    [ACCOUNT_NUMBER]            [VARCHAR](36)                       NOT NULL,
    [ACCOUNT_NAME]              [NVARCHAR](200)                     NOT NULL,
    [PAYMENT_TOKEN]             [VARCHAR](64)                       NOT NULL,
    [AMOUNT]                    [VARCHAR](20)                       NOT NULL,
    [SUBSCRIBER_NUMBER]         [VARCHAR](20)                       NOT NULL,
    [CIF]                       [VARCHAR](36)                       NOT NULL,
    [RECEIPT]                   [VARCHAR](16)                       NULL,
    [STATUS]                    [VARCHAR](20)                       NOT NULL,
    [FORM_VALUES]               [VARCHAR](4000)                      NULL,
    [TRANSACTION_DATETIME]      [DATETIME2](7)                      NOT NULL,
    [CREATED_BY]                [NVARCHAR](150)                     NOT NULL,
    [CREATED_DATETIME]          [DATETIME2](7)                      NOT NULL,
    [UPDATED_BY]                [NVARCHAR](150)                     NULL,
    [UPDATED_DATETIME]          [DATETIME2](7)                      NULL,

    CONSTRAINT [PK_BILLS_PAYMENT_TRANSACTION] PRIMARY KEY CLUSTERED
        (
         [ID] ASC
            )
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
        ON [ONEPAMRTBSEC]
) ON [ONEPAMRTBSEC]
GO

ALTER TABLE [blpt].[BILLS_PAYMENT_TRANSACTION]
    ADD CONSTRAINT [DF_BILLS_PAYMENT_TRANSACTION_UPDATED_DATETIME] DEFAULT (GETUTCDATE()) FOR [UPDATED_DATETIME]
GO
ALTER TABLE [blpt].[BILLS_PAYMENT_TRANSACTION]
    ADD CONSTRAINT [DF_BILLS_PAYMENT_TRANSACTION_UPDATED_BY] DEFAULT (SUSER_SNAME()) FOR [UPDATED_BY]
GO
ALTER TABLE [blpt].[BILLS_PAYMENT_TRANSACTION]
    ADD CONSTRAINT [DF_BILLS_PAYMENT_TRANSACTION_CREATED_DATETIME] DEFAULT (GETUTCDATE()) FOR [CREATED_DATETIME]
GO
ALTER TABLE [blpt].[BILLS_PAYMENT_TRANSACTION]
    ADD CONSTRAINT [DF_BILLS_PAYMENT_TRANSACTION_CREATED_BY] DEFAULT (SUSER_SNAME()) FOR [CREATED_BY]
GO