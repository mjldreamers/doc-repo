CREATE TABLE [csm].[STR_MANAGEMENT_REPORT] (

    [ID]                              [BIGINT] IDENTITY(1,1)  NOT NULL,
    [SUBMISSION_TYPE]                 [VARCHAR](15)           NOT NULL,
    [STATUS]                          [VARCHAR](64)           NOT NULL,
    [REPORT_TYPE]                     [VARCHAR](50)           NOT NULL,
    [CIF]                             [VARCHAR](50)           NOT NULL,
    [ACCOUNT_NUMBER]                  [VARCHAR](50)           NULL,
    [CARD_NUMBER]                     [VARCHAR](50)           NULL,
    [ESCALATION_DATE]                 [DATETIME2](7)          NULL,
    [ACCT_HOLDER_FIRST_NAME]          [NVARCHAR](150)         NOT NULL,
    [ACCT_HOLDER_MIDDLE_NAME]         [NVARCHAR](150)         NOT NULL,
    [ACCT_HOLDER_LAST_NAME]           [NVARCHAR](150)         NOT NULL,
    [SUBJECT_OF_SUSPICION]            [VARCHAR](150)          NULL,
    [REASON]                          [VARCHAR](10)           NULL,
    [ADDITIONAL_REASON]               [NVARCHAR](4000)        NULL,
    [NARRATIVE]                       [NVARCHAR](4000)        NULL,
    [REPORT_DATE]                     [DATE]                  NOT NULL,
    [CHECKSUM]                        [VARCHAR](128)          NULL,
    [REPORTER_CORP_KEY]               [VARCHAR](10)           NOT NULL,
    [REPORTER_NAME]                   [NVARCHAR](200)         NOT NULL,
    [REVIEWER_CORP_KEY]               [VARCHAR](10)           NULL,
    [REVIEWER_NAME]                   [NVARCHAR](200)         NULL,
    [CREATED_BY]                      [VARCHAR](150)          NOT NULL,
    [CREATED_DATETIME]                [DATETIME2](7)          NOT NULL,
    [UPDATED_BY]                      [VARCHAR](150)          NULL,
    [UPDATED_DATETIME]                [DATETIME2](7)          NULL,

    CONSTRAINT [PK_STR_MANAGEMENT_REPORT] PRIMARY KEY CLUSTERED
    (
      [ID] ASC
    )
    ON [PRIMARY],

) ON [PRIMARY]
GO

ALTER TABLE [csm].[STR_MANAGEMENT_REPORT] ADD CONSTRAINT [DR_STR_MANAGEMENT_REPORT_CREATED_BY] DEFAULT (SUSER_SNAME()) FOR [CREATED_BY]
GO
ALTER TABLE [csm].[STR_MANAGEMENT_REPORT] ADD CONSTRAINT [DF_STR_MANAGEMENT_REPORT_CREATED_DATETIME] DEFAULT (getutcdate()) FOR [CREATED_DATETIME]
GO
ALTER TABLE [csm].[STR_MANAGEMENT_REPORT] ADD CONSTRAINT [DR_STR_MANAGEMENT_REPORT_UPDATED_BY] DEFAULT (SUSER_SNAME()) FOR [UPDATED_BY]
GO
ALTER TABLE [csm].[STR_MANAGEMENT_REPORT] ADD CONSTRAINT [DF_STR_MANAGEMENT_REPORT_UPDATED_DATETIME] DEFAULT (getutcdate()) FOR [UPDATED_DATETIME]
GO