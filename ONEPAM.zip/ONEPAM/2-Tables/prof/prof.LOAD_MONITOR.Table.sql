CREATE TABLE [prof].[LOAD_MONITOR](
	[Load_Name] [varchar](20) NULL,
	[Load_Start_Date] [datetime] NULL,
	[Load_End_Date] [datetime] NULL,
	[Audit_Pass] [bit] NULL
) ON [PRIMARY]
GO