CREATE TABLE [prof].[INTERFACES](
	[InterfaceId] [int] IDENTITY(1,1) NOT NULL,
	[InterfaceCode] [nvarchar](20) NULL,
	[Interfacedescription] [nvarchar](255) NULL,
	[sourcetable] [nvarchar](150) NULL,
	[destinationtable] [nvarchar](150) NOT NULL,
	[delimeter] [nvarchar](100) NULL,
	[delimeter_value] [nvarchar](10) NULL,
	[ssispackage] [nvarchar](100) NULL,
 CONSTRAINT [PK_Interfaces] PRIMARY KEY CLUSTERED 
(
	[InterfaceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO