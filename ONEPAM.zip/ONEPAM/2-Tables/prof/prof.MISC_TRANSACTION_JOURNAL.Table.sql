CREATE TABLE [prof].[MISC_TRANSACTION_JOURNAL](
	[MTJ_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Profile_No] [varchar](50) NOT NULL,
	[Report_Date] [date] NOT NULL,
	[Account] [varchar](100) NULL,
	[BrCd] [varchar](100) NULL,
	[Seq] [varchar](100) NULL,
	[TranCd] [varchar](100) NULL,
	[Amount] [varchar](100) NULL,
	[Location] [varchar](100) NULL,
	[User] [varchar](100) NULL,
	[Time] [time](0) NULL,
	[POU] [varchar](100) NULL,
	[Effective] [varchar](100) NULL,
	[Source] [varchar](100) NULL,
	[CC] [varchar](100) NULL,
	[BaseAmt] [varchar](100) NULL,
	[BaseCurr] [varchar](100) NULL,
	[ExchRate] [varchar](100) NULL,
	[CustCode] [varchar](100) NULL,
	[Txn_Comment] [varchar](100) NULL,
	[Created_By] [varchar](100) NOT NULL,
	[Created_Datetime] [datetime2](7) NOT NULL,
	[Updated_By] [varchar](100) NULL,
	[Updated_Datetime] [datetime2](7) NULL,
 CONSTRAINT [PK_MTJ_Report] PRIMARY KEY CLUSTERED 
(
	[MTJ_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [prof].[Misc_Transaction_Journal] ADD  CONSTRAINT [DF_MTJ_CREATED_BY]  DEFAULT (suser_name()) FOR [Created_By]
GO
ALTER TABLE [prof].[Misc_Transaction_Journal] ADD  CONSTRAINT [DF_MTJ_CREATED_DATETIME]  DEFAULT (getutcdate()) FOR [Created_Datetime]
GO
ALTER TABLE [prof].[Misc_Transaction_Journal] ADD  CONSTRAINT [DF_MTJ_UPDATED_BY]  DEFAULT (suser_name()) FOR [Updated_By]
GO
ALTER TABLE [prof].[Misc_Transaction_Journal] ADD  CONSTRAINT [DF_MTJ_UPDATED_DATETIME]  DEFAULT (getutcdate()) FOR [Updated_Datetime]
GO