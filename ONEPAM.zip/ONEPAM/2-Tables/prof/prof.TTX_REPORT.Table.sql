CREATE TABLE [prof].[TTX_REPORT](
	[TTX_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Profile_No] [varchar](50) NOT NULL,
	[Report_Date] [date] NOT NULL,
	[Sys_Processing_Date] [date] NOT NULL,
	[Transaction_Seq] [varchar](100) NOT NULL,
	[Account_No] [varchar](100) NOT NULL,
	[Transaction_Class] [varchar](100) NULL,
	[Currency_Code] [varchar](100) NULL,
	[DR_Text_Ind] [varchar](100) NULL,
	[Trancode] [varchar](100) NULL,
	[Transaction_Group] [varchar](100) NULL,
	[Exchange_Rate] [varchar](100) NULL,
	[Transation_Amt] [varchar](100) NULL,
	[Clock_Time] [varchar](100) NULL,
	[Transaction_Trace_No] [varchar](100) NULL,
	[Transaction_Effectiv] [varchar](100) NULL,
	[Ending_Bal] [varchar](100) NULL,
	[Branch_Code] [varchar](100) NULL,
	[Base_Amount] [varchar](100) NULL,
	[Accrued_Int] [varchar](100) NULL,
	[W_Amount] [varchar](100) NULL,
	[Int] [varchar](100) NULL,
	[Off_Line] [varchar](100) NULL,
	[Rev] [varchar](100) NULL,
	[EC] [varchar](100) NULL,
	[Created_By] [varchar](100) NOT NULL,
	[Created_Datetime] [datetime2](7) NOT NULL,
	[Updated_By] [varchar](100) NULL,
	[Updated_Datetime] [datetime2](7) NULL,
	[Transaction_Amount] [varchar](20) NULL,
	[Principal] [varchar](20) NULL,
	[Transaction_Source] [varchar](500) NULL,
	[Transaction_Comment] [varchar](500) NULL,
	[User_Id] [varchar](20) NULL
 CONSTRAINT [PK_TTX_Report] PRIMARY KEY CLUSTERED 
(
	[TTX_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [prof].[TTX_Report] ADD  CONSTRAINT [DF_TTX_Report_CREATED_BY]  DEFAULT (suser_name()) FOR [Created_By]
GO
ALTER TABLE [prof].[TTX_Report] ADD  CONSTRAINT [DF_TTX_Report_CREATED_DATETIME]  DEFAULT (getutcdate()) FOR [Created_Datetime]
GO
ALTER TABLE [prof].[TTX_Report] ADD  CONSTRAINT [DF_TTX_Report_Updated_BY]  DEFAULT (suser_name()) FOR [Updated_By]
GO
ALTER TABLE [prof].[TTX_Report] ADD  CONSTRAINT [DF_TTX_Report_Updated_DATETIME]  DEFAULT (getutcdate()) FOR [Updated_Datetime]
GO
