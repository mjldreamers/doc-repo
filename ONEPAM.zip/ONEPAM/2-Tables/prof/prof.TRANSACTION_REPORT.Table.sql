CREATE TABLE [prof].[TRANSACTION_REPORT](
	[TR_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Profile_No] [varchar](50) NOT NULL,
	[Report_Date] [date] NOT NULL,
	[Account_No] [varchar](100) NOT NULL,
	[Customer_No] [varchar](100) NOT NULL,
	[Product_Type] [varchar](100) NULL,
	[Ledger_Bal] [varchar](100) NULL,
	[Product_Type2] [varchar](100) NULL,
	[Base_Currency] [varchar](100) NULL,
	[Base_Amount] [varchar](100) NULL,
	[Transaction_Amount] [varchar](100) NULL,
	[Currency_Code] [varchar](100) NULL,
	[Cost_Center] [varchar](100) NULL,
	[GL_Set_Code] [varchar](100) NULL,
	[Trancode] [varchar](100) NULL,
	[ITC_Byte1] [varchar](100) NULL,
	[Int] [varchar](100) NULL,
	[Rev] [varchar](100) NULL,
	[Sys_Accounting_Date] [date] NOT NULL,
	[W_Amount] [varchar](100) NULL,
	[Int2] [varchar](100) NULL,
	[Transaction_Source] [varchar](1000) NULL,
	[Created_By] [varchar](100) NOT NULL,
	[Created_Datetime] [datetime2](7) NOT NULL,
	[Updated_By] [varchar](100) NULL,
	[Updated_Datetime] [datetime2](7) NULL,
 CONSTRAINT [PK_Transaction_Report] PRIMARY KEY CLUSTERED 
(
	[TR_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [prof].[Transaction_Report] ADD  CONSTRAINT [DF_Transaction_Report_CREATED_BY]  DEFAULT (suser_name()) FOR [Created_By]
GO
ALTER TABLE [prof].[Transaction_Report] ADD  CONSTRAINT [DF_Transaction_Report_CREATED_DATETIME]  DEFAULT (getutcdate()) FOR [Created_Datetime]
GO
ALTER TABLE [prof].[Transaction_Report] ADD  CONSTRAINT [DF_Transaction_Report_Updated_By]  DEFAULT (suser_name()) FOR [Updated_By]
GO
ALTER TABLE [prof].[Transaction_Report] ADD  CONSTRAINT [DF_Transaction_Report_Updated_Datetime]  DEFAULT (getutcdate()) FOR [Updated_Datetime]
GO