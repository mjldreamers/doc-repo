CREATE TABLE [prof].[TABLEMAPPINGS](
	[tablemappingid] [int] IDENTITY(1,1) NOT NULL,
	[interfacecode] [nvarchar](20) NULL,
	[sourcefield] [nvarchar](100) NULL,
	[destination] [nvarchar](100) NULL,
	[startposition] [nvarchar](20) NULL,
	[strlength] [nvarchar](20) NULL,
	[ordinalposition] [nvarchar](20) NULL,
	[filterfield] [bit] NULL,
	[filterfieldtype] [nvarchar](50) NULL,
	[query] [nvarchar](max) NULL,
	[updatefields] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Index [PK_tablemappings]    Script Date: 9/9/2019 5:07:55 PM ******/
ALTER TABLE [prof].[tablemappings] ADD  CONSTRAINT [PK_tablemappings] PRIMARY KEY NONCLUSTERED 
(
	[tablemappingid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO