CREATE TABLE [prof].[IMPORT_PROFILE](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[InterfaceCode] [nvarchar](20) NULL,
	[Filename] [nvarchar](50) NOT NULL,
	[Line_Number] [bigint] NOT NULL,
	[Line_Data] [nvarchar](max) NOT NULL,
	[Report_Date] [date] NULL,
	[Created_Datetime] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [prof].[Import_Profile] ADD  DEFAULT (getutcdate()) FOR [Created_Datetime]
GO