CREATE TABLE [prof].[Schedule22A](
	[S22a_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Profile_No] [varchar](50) NOT NULL,
	[Report_Date] [date] NOT NULL,
	[System_Date] [date] NOT NULL,
	[Report_ID] [varchar](100) NULL,
	[Deposit_Size] [varchar](100) NULL,
	[Account_Code] [varchar](100) NULL,
	[Group] [varchar](100) NULL,
	[Currency_Code] [varchar](100) NULL,
	[No_Of_Account] [varchar](100) NULL,
	[Amount] [varchar](100) NULL,
	[Created_By] [varchar](100) NOT NULL,
	[Created_Datetime] [datetime2](7) NOT NULL,
	[Updated_By] [varchar](100) NULL,
	[Updated_Datetime] [datetime2](7) NULL,
 CONSTRAINT [PK_S22a_Report] PRIMARY KEY CLUSTERED 
(
	[S22a_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [prof].[Schedule22a] ADD  CONSTRAINT [DF_Schedule22a_CREATED_BY]  DEFAULT (suser_name()) FOR [Created_By]
GO
ALTER TABLE [prof].[Schedule22a] ADD  CONSTRAINT [DF_Schedule22a_CREATED_DATETIME]  DEFAULT (getutcdate()) FOR [Created_Datetime]
GO
ALTER TABLE [prof].[Schedule22a] ADD  CONSTRAINT [DF_Schedule22a_UPDATED_BY]  DEFAULT (suser_name()) FOR [Updated_By]
GO
ALTER TABLE [prof].[Schedule22a] ADD  CONSTRAINT [DF_Schedule22a_UPDATED_DATETIME]  DEFAULT (getutcdate()) FOR [Updated_Datetime]
GO