CREATE TABLE [prof].[DAILY_TRANSACTION_JOURNAL](
	[DTJ_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Profile_No] [varchar](50) NOT NULL,
	[Report_Date] [date] NOT NULL,
	[Account] [varchar](100) NULL,
	[Seq] [bigint] NULL,
	[BrCode] [bigint] NULL,
	[CstCtr] [varchar](100) NULL,
	[TranCode] [varchar](100) NULL,
	[TellerID] [varchar](100) NULL,
	[Effective] [varchar](100) NULL,
	[Transaction] [varchar](100) NULL,
	[Principal] [varchar](100) NULL,
	[Int/Div] [varchar](100) NULL,
	[Amount] [varchar](100) NULL,
	[Desc] [varchar](100) NULL,
	[OR] [varchar](100) NULL,
	[POU] [varchar](100) NULL,
	[BaseCurr] [varchar](100) NULL,
	[AccCurr] [varchar](100) NULL,
	[CustCode] [varchar](50) NULL,
	[BaseAmt] [varchar](100) NULL,
	[TreasRef] [varchar](100) NULL,
	[ExcRate] [varchar](100) NULL,
	[Created_By] [varchar](100) NOT NULL,
	[Created_Datetime] [datetime2](7) NOT NULL,
	[Updated_By] [varchar](100) NULL,
	[Updated_Datetime] [datetime2](7) NULL,
 CONSTRAINT [PK_DTJ_Report] PRIMARY KEY CLUSTERED 
(
	[DTJ_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [prof].[Daily_Transaction_Journal] ADD  CONSTRAINT [DF_DTJ_CREATED_BY]  DEFAULT (suser_name()) FOR [Created_By]
GO
ALTER TABLE [prof].[Daily_Transaction_Journal] ADD  CONSTRAINT [DF_DTJ_CREATED_DATETIME]  DEFAULT (getutcdate()) FOR [Created_Datetime]
GO
ALTER TABLE [prof].[Daily_Transaction_Journal] ADD  CONSTRAINT [DF_DTJ_UPDATED_BY]  DEFAULT (suser_name()) FOR [Updated_By]
GO
ALTER TABLE [prof].[Daily_Transaction_Journal] ADD  CONSTRAINT [DF_DTJ_UPDATED_DATETIME]  DEFAULT (getutcdate()) FOR [Updated_Datetime]
GO