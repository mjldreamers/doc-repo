CREATE TABLE [prof].[SSIS CONFIGURATIONS](
	[Configuration_ID] [int] IDENTITY(1,1) NOT NULL,
	[Configuration_Filter] [nvarchar](255) NOT NULL,
	[Configured_Value] [nvarchar](4000) NULL,
	[Package_Path] [nvarchar](255) NOT NULL,
	[ConfiguredValue_Type] [nvarchar](20) NOT NULL,
	[CONFIG_TYPE] [varchar](8) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Index [PK_SSIS Configurations]    Script Date: 9/9/2019 5:07:55 PM ******/
ALTER TABLE [prof].[SSIS Configurations] ADD  CONSTRAINT [PK_SSIS Configurations] PRIMARY KEY NONCLUSTERED 
(
	[Configuration_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [prof].[SSIS Configurations] ADD  CONSTRAINT [DF_SSISConfigurations_CONFIG_TYPE]  DEFAULT ('') FOR [CONFIG_TYPE]
GO