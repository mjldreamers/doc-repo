CREATE TABLE [prof].[SAVING_TRIAL_BALANCE](
	[STB_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Profile_No] [varchar](50) NOT NULL,
	[Report_Date] [date] NOT NULL,
	[Account_No] [varchar](100) NOT NULL,
	[Account_Title] [varchar](100) NULL,
	[Balance] [varchar](100) NULL,
	[Org_Date] [date] NOT NULL,
	[Last_Tran] [date] NULL,
	[Hld_Amt] [varchar](100) NULL,
	[Int_Rate] [varchar](100) NULL,
	[Acr_Int] [varchar](100) NULL,
	[Int_YTD] [varchar](100) NULL,
	[Created_By] [varchar](100) NOT NULL,
	[Created_Datetime] [datetime2](7) NOT NULL,
	[Updated_By] [varchar](100) NULL,
	[Updated_Datetime] [datetime2](7) NULL,
 CONSTRAINT [PK_Saving_Trial_Balance] PRIMARY KEY CLUSTERED 
(
	[STB_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [prof].[Saving_Trial_Balance] ADD  CONSTRAINT [DF_Saving_Trial_Balance_CREATED_BY]  DEFAULT (suser_name()) FOR [Created_By]
GO
ALTER TABLE [prof].[Saving_Trial_Balance] ADD  CONSTRAINT [DF_Saving_Trial_Balance_CREATED_DATETIME]  DEFAULT (getutcdate()) FOR [Created_Datetime]
GO
ALTER TABLE [prof].[Saving_Trial_Balance] ADD  CONSTRAINT [DF_Saving_Trial_Balance_Updated_BY]  DEFAULT (suser_name()) FOR [Updated_By]
GO
ALTER TABLE [prof].[Saving_Trial_Balance] ADD  CONSTRAINT [DF_Saving_Trial_Balance_Udated_DATETIME]  DEFAULT (getutcdate()) FOR [Updated_Datetime]
GO