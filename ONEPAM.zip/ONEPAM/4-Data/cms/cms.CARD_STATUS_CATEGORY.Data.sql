INSERT INTO [ONEPAM].[cms].[CARD_STATUS_CATEGORY]
  (STATUS_CATEGORY_CODE, DESCRIPTION, ACTION) VALUES
    ('CN004', 'Compromised', 'Reissue'),
    ('CR006', 'Customer Request', 'Replace'),
    ('DA003', 'Damaged', 'Replace'),
    ('FR002', 'Fraud', 'Reissue'),
    ('OT005', 'Lost', 'Reissue'),
    ('ST001', 'Stolen', 'Reissue');