UPDATE [blpt].[BILLER]
SET
    [METADATA] = '{"visaMCC": "8398"}'
    WHERE [ID] IN (
      'MANILA_MEMORIAL',
      'RESOURCES_BLIND',
      'ROCKWELL_RESIDENTIAL',
      'WORLD_VISION'
    );
UPDATE [blpt].[BILLER]
SET
    [METADATA] = '{"visaMCC": "6012"}'
    WHERE [ID] IN (
      'CTBC_ASSOC',
      'AUB_CARDS',
      'BANKARD_RCBC',
      'BDO_CARD',
      'CBC_CARD',
      'CTB_VISA_MC',
      'CTBC_BANK',
      'EASTWEST_CARD',
      'HSBC_CARDS',
      'MAYBANK_CC',
      'MBTC_PSB_CARD',
      'PNB_CREDIT_CARDS',
      'ROBINSONS_CC',
      'SECURITY_BK_CC',
      'SBC_CASHCARDS',
      'UBP_CREDIT_CARDS'
    )
GO
UPDATE [blpt].[BILLER]
SET
    [METADATA] = '{"visaMCC": "6300"}'
    WHERE [ID] IN (
      'AXA_PHILIPPINES',
      'FORTUNE_LIFE',
      'FORTUNE_MEDICARE',
      'FPG_INSURE',
      'FWD',
      'MANULIFE_CB_LIFE',
      'MANULIFE_PHILIPPINES',
      'PARAMOUNT_LIFE',
      'PHILAM_INSURANCE',
      'PRULIFE_INSURANCE',
      'STANDARD_INSURANCE',
      'SUNLIFE_CANADA'
    )
GO
UPDATE [blpt].[BILLER]
SET
    [METADATA] = '{"visaMCC": "6513"}'
    WHERE [ID] IN (
      'ALABANG_COUNTRY_CLUB',
      'BALESIN',
      'CITY_CLUB'
    )
GO
UPDATE [blpt].[BILLER]
SET
    [METADATA] = '{"visaMCC": "6012"}'
    WHERE [ID] IN (
      'AIQON',
      'CHINA_BANK_LOANS',
      'CTB_PERSONAL_LOANS',
      'CTB_FINANCIAL',
      'COFFER_LENDING',
      'CTBC_BANK_SALSTRETCH',
      'EQUICOM_SVNGS',
      'HSBC_PERSONAL_LOANS',
      'MANULIFE_FINANCIAL',
      'MAYBANK_LOAN',
      'PBCOM_LOANS',
      'PSBANK_LOANS',
      'STERLING_SALARY_LOANS',
      'TOYOTA_FINANCIAL'
    )
GO
UPDATE [blpt].[BILLER]
SET
    [METADATA] = '{"visaMCC": "8299"}'
    WHERE [ID] IN (
      'ATENEO',
      'DLS_SANTIAGO_ZOBEL',
      'MARANATHA_ACADEMY',
      'MIRIAM_COLLEGE',
      'UNI_SAN_JOSE_RECOLETOS',
      'UNI_EAST'
    )
GO
UPDATE [blpt].[BILLER]
SET
    [METADATA] = '{"visaMCC": "4814"}'
    WHERE [ID] IN (
      'ICC_BAYANTEL',
      'CABLELINK',
      'EASTERN_TEL',
      'GLOBE',
      'INNOVE',
      'PLANET_CABLE',
      'PLDT',
      'SKY_CABLE',
      'SMART'
    )
GO
UPDATE [blpt].[BILLER]
SET
    [METADATA] = '{"visaMCC": "4789"}'
    WHERE [ID] IN (
      'CEBU_PACIFIC',
      'EASYTRIP'
    )
GO
UPDATE [blpt].[BILLER]
SET
    [METADATA] = '{"visaMCC": "4900"}'
    WHERE [ID] IN (
      'FIRST_PEAK',
      'MANILA_WATER',
      'MAYNILAD',
      'MERALCO',
      'PRIME_WATER',
      'SUBIC_WATER',
      'VECO'
    )
GO
UPDATE [blpt].[BILLER]
SET
    [METADATA] = '{"visaMCC": "6513"}'
    WHERE [ID] IN (
     'COSMOPOLITAN_COMMUNITIES',
     'EPRIME_BUSINESS',
     'IPM_REALTY',
     'ROCKWELL_RESIDENTIAL'
    )
GO
UPDATE [blpt].[BILLER]
SET
    [METADATA] = '{"visaMCC": "2741"}'
    WHERE [ID] IN (
     'DIRECTORIES_PHC'
    )
GO
UPDATE [blpt].[BILLER]
SET
    [METADATA] = '{"visaMCC": "6300"}'
    WHERE [ID] IN (
      'GREPALIFE'
    )
GO
UPDATE [blpt].[BILLER]
SET
    [METADATA] = '{"visaMCC": "5047"}'
    WHERE [ID] IN (
      'IOS_MARKETING'
    )
GO