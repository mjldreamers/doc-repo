
SET IDENTITY_INSERT [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] ON 

INSERT [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] ([ID], [RULE_NAME], [Logic_Code], [Logic_Type], [Logic_Desc], [Created_By], [Created_Datetime]) VALUES (1, N'GCAM81', N'1D', N'NA', N'Account Entry: Debit', N'sa', CAST(N'2020-01-16T05:25:17.867' AS DateTime))
INSERT [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] ([ID], [RULE_NAME], [Logic_Code], [Logic_Type], [Logic_Desc], [Created_By], [Created_Datetime]) VALUES (2, N'GCAM98', N'1D', N'NA', N'Account Entry: Debit', N'sa', CAST(N'2020-01-16T05:25:17.867' AS DateTime))
INSERT [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] ([ID], [RULE_NAME], [Logic_Code], [Logic_Type], [Logic_Desc], [Created_By], [Created_Datetime]) VALUES (6, N'GCAM61', N'1M', N'OR', N'Filter: Threshold OR Frequency, Account Entry: Credit', N'sa', CAST(N'2020-01-16T05:25:17.867' AS DateTime))
INSERT [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] ([ID], [RULE_NAME], [Logic_Code], [Logic_Type], [Logic_Desc], [Created_By], [Created_Datetime]) VALUES (7, N'GCAM101', N'1M', N'OR', N'Filter: Threshold OR Frequency, Account Entry: Debit', N'sa', CAST(N'2020-01-16T05:25:17.867' AS DateTime))
INSERT [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] ([ID], [RULE_NAME], [Logic_Code], [Logic_Type], [Logic_Desc], [Created_By], [Created_Datetime]) VALUES (10, N'GCAM49', N'3M', N'NA', NULL, N'sa', CAST(N'2020-01-16T05:25:17.867' AS DateTime))
INSERT [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] ([ID], [RULE_NAME], [Logic_Code], [Logic_Type], [Logic_Desc], [Created_By], [Created_Datetime]) VALUES (11, N'GCAM67', N'4M', N'AND', NULL, N'sa', CAST(N'2020-01-16T05:25:17.867' AS DateTime))
INSERT [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] ([ID], [RULE_NAME], [Logic_Code], [Logic_Type], [Logic_Desc], [Created_By], [Created_Datetime]) VALUES (16, N'GCAM84', N'2D', N'NA', NULL, N'sa', CAST(N'2020-01-16T05:25:17.867' AS DateTime))
INSERT [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] ([ID], [RULE_NAME], [Logic_Code], [Logic_Type], [Logic_Desc], [Created_By], [Created_Datetime]) VALUES (17, N'LOC01', N'2D', N'AND', NULL, N'sa', CAST(N'2020-01-16T05:25:17.867' AS DateTime))
INSERT [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] ([ID], [RULE_NAME], [Logic_Code], [Logic_Type], [Logic_Desc], [Created_By], [Created_Datetime]) VALUES (18, N'GCAM82_1D', N'3D', N'NA', N'Account Entry: Debit', N'sa', CAST(N'2020-01-16T05:25:17.867' AS DateTime))
INSERT [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] ([ID], [RULE_NAME], [Logic_Code], [Logic_Type], [Logic_Desc], [Created_By], [Created_Datetime]) VALUES (19, N'GCAM82_1M', N'6M', N'OR', N'Filter: Threshold OR Frequency, Account Entry: Credit', N'sa', CAST(N'2020-01-16T05:25:17.867' AS DateTime))

SET IDENTITY_INSERT [rpt].[WAT_Rule_Type_PTM_BULKMANUAL] OFF