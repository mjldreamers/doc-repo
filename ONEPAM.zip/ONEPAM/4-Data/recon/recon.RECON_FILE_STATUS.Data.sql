INSERT INTO [recon].[RECON_FILE_STATUS] ([CODE], [DESCRIPTION], [ACTIVE])
VALUES ('DOWNLOAD_STARTED', 'Download Started', 1),
       ('DOWNLOAD_FAILED', 'Download Failed', 1),
       ('UPLOAD_FAILED', 'Upload Failed', 1),
       ('UPLOAD_SUCCEEDED', 'Upload Succeeded', 1),
       ('PARSE_FAILED', 'Parse Failed', 1),
       ('PARSE_SUCCEEDED', 'Parse Succeeded', 1),
       ('RECON_FAILED', 'Recon Failed', 1),
       ('RECON_SUCCEEDED', 'Recon Succeeded', 1)
GO
