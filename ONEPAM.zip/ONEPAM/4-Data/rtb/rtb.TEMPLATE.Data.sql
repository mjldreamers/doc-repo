INSERT INTO [rtb].[TEMPLATE](template_id, LOCATION_CODE, type, CREATED_DATETIME, CREATED_BY, TEMPLATE, NAME, VERSION)
	VALUES (NEWID(), 'PH', 4, GETUTCDATE(), suser_name(),
	'<html xmlns="http://www.w3.org/1999/xhtml" xmlns:th="http://www.thymeleaf.org">

<head>
    <style>
        body,
        template,
        header,
        footer,
        main,
        section {
          padding: 0;
          margin: 0;
        }

        section header {
          border-bottom: 2px solid rgb(255, 98, 0);
        }

        div.header3 > span {
          font-weight: normal !important;
        }

        div.header3{
          display: block;
          font-size: 1.17em;
          margin-top: .8em;
          margin-bottom: .8em;
          margin-left: 0;
          margin-right: 0;
          font-weight: bold;
        }

        .logo {
          height: 60px;
          background-size: auto 40px;
          background-repeat: no-repeat;
          background-position: left bottom;
          margin: 0;
          background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAbAAAABsCAYAAAALxefKAAAAAXNSR0IArs4c6QAAQABJREFUeAHtnQncVVMXxpc0zwMaKaGkUdIsGSKkyRCSMs8hDcpQIalQKDJHmUMlpZDiK8qYJGWoRJqjuYRv/e9+d/fc8955eu/NWf3uPdM++5yz79teZ631rGcd8K+KeOKNgDcC3gh4I+CNQJaNQL4su1/vdr0R8EbAGwFvBLwR8I2Ap8C8PwRvBLwR2D9GYO9ukSl3iWxcvn88j/cUEUcgf8QWXgNvBLwR8EYg00bgn70ii2eIfDdTZOVnIje/L1KwqEi5qiJ3HCXSoKNI29tEqjYKvPONK0SKlhYpop+v3hD56AlVeLpv7x6RGieKXPSY9lMs8BxvK2NH4AAvBpaxv413Y94IeCMQbAR+/Vrk2W4iv33rP3pab5FzRohs2yBy68H+/Q3PEelwj8jW9SIz9fiP/xN5YJ1u62dwHZEdf/jb9pwuUrutyO6tItOGiOQvJHL0ySJHqWLzJCNHwFNgGfmzeDfljYA3AvtGYOFkkSXvGauqSn2R4qqgdv4p8vDpIsvn72smV70q0vBckWsO9O9j7YADRCxWDYV29USRF68x1pez5am3iGxZK7LoHdO/PXb2QJF2g+yWt8ygEfBciBn0Y3i34o2ANwKOEUBJPX+puvreMjs/HGOWpSqIVKotUriEo7GuvnS9yKHHiuTT0P4///iPWeXFnmPaGCtt4RT/cbv2/ki7ZpYly4tc9ZpaYK3MNpbZkg9E6rXTa3hTZ+Bg5c2WZ4Hlzbh7V/VGwBuBcCOwe5vIKFU2P38arlXuY0VKieza4re43C36fCTy1gDjSnQfc29XqGnciNs3GqX3l4JEkMObiFw3SaSkKlJP8nQEPAWWp8PvXdwbAW8Eco3Anh0ij54hskyVTbKlSj2RX79JvNfyChTpO9e4MxPvzeshzhHwFFicA+ed5o2ANwKpGIF/RUafbeJQ7u5xD7a+zlg+KxaIfKugi5VfaCs9J+micbPiBxnLK1T/9durJTY56Vf2Oox+BDwFFv1YeS29EfBGINUj8IHGoV7rFXiVymo1obhOuMoAMpxHt6l7b4Lu/+pN59741wsUEWlzq8hJN6ii1BgY1iBQ/aWzRYibuXPMLh6r93V1/NfzzkxoBDwFltDweSd7I+CNQNJGYMdmkQHVFAGoMSwrFz0ucqIiBq38/p3melUzOV9235qlIk9fKLLqK7snviUW3tWvixx8RPDzAYNMvVs/g/zHi5QUGfqL5pVp7M2TtI9AvrRf0bugNwLeCHgjEGwE9mwXOXuQH11Yo7Vfef22SGRIQ5FBij7sW1HkZUUcrlliegFscceXIi2vDNZrdPsKFRe5YapfeS2dJfJqT5GHThL5XpOkEeD4QOqbX2a2+UbZzs5BR/r3emtpGgHPAkvTQHuX8UbAG4EII7Bjk8LmVTl8TVxJlcVd34hUrqPJxmqZ3dNAZJNaOk5BoTQ6X6TbUyKFSij6UJGLdyq4YssaZ6vo1lteYfqh9Ws3i3zwcOB59TUud+6DIodo/8D77zgyJz6mzUocrFbYShHcj56kdQQ8Cyytw+1dzBsBbwSCjgAWFkrKp7y0xbGdjPKi8f9UQbmVF/tx6X32qsjwliJ//6WWm1pRFz+hykyX0QiUUcXKqa7UxOdGF5gzfvkit/LiyMK3jfW38nPjLjy9n/8KsHx8rvlinqR9BLxsvLQPuXdBbwS8Ecg1AoAwNq3y7wbhZ2X+i3Yt+BJYPC6/Y5SZg/Me2ap0UOqOJH/rp3ki36jy+eJ1zekqLNJKARd1zzK5XAVzLCYUIdYc8vUkswz2jZL85HnDr9j6ekNNBSUVgpJt1t2sZ+s3FjAvCtBrHVjAoDDLq3s2g8VTYBn843i35o3Af2YENvwc+Kjfq0JCIezdJbL628Bjzq1D1Wprq9ZQrVOde9UKK2Y+ZQ8TOV6tK3gS4TYsrhaXW6zyYj8xuDJVRN7oGwgmsefYuBvKzzJ8QBzcVLkZQSxCKJwtsv5Hk65AsviKz0TW/5T7zhm7K17S/TkKPneLPN3jKbA8HX7v4t4IeCPgGwHiSk7BIjtnuIGyt7hc5GO1cJxC3InYV/0Ozr2h10tXCn3MeQR3IrD4Gq1FHtO+QTg6xbJxbP5VY2DrzRGsv473Zr7y+vdvw2zyjYJVvpmiLwaK6AwnKON2d2mLHOX1nsYAYUg5o79aaAXDnZm2Yx6II21D7V3IGwFvBEKOwIgTctM7oUjIs0KwwlBqcxRWX76GWgUvi5QKo5SYrH/50sTDKtQyfdjvdT8YiwNr7Ijm2qaEPRK4BAwyrJnIhhX+/TZ5+YePldW+lX8//Iv1zjb3lWlgDhTtKz01n22GulUVEBNMIEk+7jxt857ID3P8LYgrAl5p3sMor94VRKo1Erle3bLED/NYPAWWxz+Ad3lvBP7zIzB/gimP4h4IrKH+8zXmdJz/CFD7AhrL4lgwgXCXXK1Px6tLT9v2UUVTRd2MTkGBTb9PZN44kcOOFemtE3YoJYbivFfb/L3X9ICLsd1Ac423demWE681NcXc+/N6e9FUkfFXivypStnKAap0iQeedKMhObb7F00TeeHyQDRnsbIGVMNLAWhPXiJuVmWHizYPxVNgeTj43qW9EfjPjwDMFoPqmPgRg3HKLYoCHOkfFkqnXK/urupN/ftCrf25WhGJLfwW0+WqGBt3Dd6a6s3kk2GRlDzE5IBVPT5429f1noDPH6F9w6X4y9dqfZ1o6oYFO6NNL+P+DKVkg52Tjn2/Lxa5r7F/rLkmtc7qtDUAGiy1SvpbkLYA+AW6rnCC9Qo5ch4+p6fAwv1A3jFvBLwRSO0IjG7n5z08605TRfnGYq5ragym+aUindRqgt4plCx+V+uDfWog9UXVYoASKpx8q5YGBS6xIo45TeSg6uFam2NL3hd58nwzyYdrTXVnFGhpBYRkksx7VnPt1LqKVQqXVNehKnjctrgiLfqy4xCNiQ2ItbektfcUWNKG0uvIGwFvBGIaASbB3g6FNEator17RG4KEZM6Ty2zU2+O6RJJa7xqoWHc+GScUZDRdIzb7dq3/PXEojkn5W3+Fbm/WWAh0EjXBMzR+gYRXjCIiS1Tl+vIU7XmmrpVgdv3U2utqsbF8kDUCeqJNwLeCHgjkAcjAHrPKVg394dxFVKHC/n3HxE4EX/7xvAfklxMZeafPzEWFS6wZAs8i+R6kQsWrWzfpFWj1bL7/oNoz0hDO7VmLxqjiid/4LW6PCzSc7pBGAJUoWCoTS8gPWDmcOOeJWkb65J8OoTxGKPglY0rfJvp/vIssHSPuHc9bwS8ETAjAKjgf09HPxrDV6sLS+NWyEvXGUSi2Qr8JqZ1q1oJFY4O3O/c2rpW5HV1MaI0sQSpsIw1wcTOku1L9N7qqosTAbwwxAEmMXuj+yavbJDGn3DDZYp8+KhROqQDgKhEIQFOcQpgF2J9f/7u30ti89mDtfJ1fcNMwssEAqjDVx/tILOdpm9PgaVpoL3LeCPgjYBrBO7SyXDtMtfOMJujdxoEom3y+SsiT11otwKXkWIzD59uyqQEnmW2iPV0vl+k5sn+oyvUyhuq++MVi16M9/xUn4cigrkEKi/AG78vMQoOYMw/OUrKeQ8AWsgJ+1Vdq1YYt5s0Dkn8MU2irxmeeCPgjYBzBHbt+ktW/rpeVqzSzy/rZMvWnbJ9xy7ZsWO3bN+5WzhetEhBKVGiqJQoVliXRaRk8SJSpVI5qXFERd/S2V8i66vXbJYBQ17a18Vzj1ynnh11A2W7/K2xrmDMD+GeC+QgEHor8BdS0HLmA2aPz3oqaFB24cAetKZYJfGc6hoPIvfJyiFHGmQdtFNOSdRFNusRkdN6a7KzG6DivEgerH/8hBkL3LM8M0TG0HBFkp/m5m4Bm8ew5sYVWe7w3MdTsGefAluy7DfZ+7cm/2WoHHJQKSl/cKmY727nrj2+CSjmE+M4oUjhglJSJ7NMlB068S79Ud+m0iT58x8odWsdlqarxX+ZzX9sl/lf/iDzvzAfxmjNuj+UJUiD3XFKEVVuR1arIEdVryi1alaR5sfXkCbHHaVKr1DMPX7z3Up5bdK8feeNGNRNDi6XQa6ofXcW4wrK6x/XfFO5rslLIofrj99yd0j8xV13C4ooiH/XqruL82cMM8S6oWp62V5BHv61S+SaNwxP4oblJukZVnq38uKcZbPtmfEtiYct0BeRREq+xHfl8GcBoydOBw8l+XZFS0enwEL1CnMJIBFK06QB2LFPgbU9/15Zv3FLqNvK8/39enaUgX3Oi/k+nh7/gfS7e0LM58VzQkl9I5/yYj9pfOyR8Zye0nO+XbJKWncYmNJrODsvU7qY/LboSeeujFn/9PNlMmn6Z/LuB1/Lsp+Sr9R37twji5b84vvIO/N9z41CP65edWnR9Ghp2eRoOalFbSlUSGMtEeTLhT8HtFi/Ycv+ocDcFE28sd+hQAlqawVTXozCKs2/wkJyS3V96+eDWCg8IIRwUvZQBSDs1Wvp7++s7xXsHBJ3F88wUHuqM+8TtYThV4SvMRr5VkESmabAiBMOUMvp5RtUkU+M5ikit9myVmRES5H295hUBhKmUySp6zlFN5zJ3W7ZukPadx0mC776MZNv8z95byitm29/To5odIOc3GmwPPLktJQor1CDu3fv3z5L76HH3pbO3UfIYQ2ulStuHivvzf5G/v47SIwhp6O3pmk8wiHrNvzp2MriVRKYnXJyTwVOHKgJtJ849/rXyT+y7PH+vbnXCqhCAcRBAnQ4KaFtkI0rzTLcN67JwRoTOtilPA+urrD+W8KdGXgMNCLQ80yTEuVFrnpd41eqpEEYJkPgjIQQGRCIm6g5Gf3n9KG/jJEypYtrrO5f4d8OfYPcpa63vJZiRQtL4Zy31HjcL9w/7hz6IYaRDrFKbMoEtcQauv7g03EDIa5RrGghqXdMVcGliqX9x59R+LlD9BVqdz7lg6tYvrSU0HjQwQflvZtrz5698vqUT+SxZ2fIV4tcE2aoh0jT/q3bdspLb3zs+xxUtoR0btdEzmvfTJo3rrkvxvXMi7Nk8ffq2nEIFth+IW5OPjtxAtkOJuyvfUawI4H7SEyuGMH64gxiYMia741lZbaCf9u42+rFgcdxWUJs+9HYyInNnEn1Zkq/HNYwsJ9M2SKZmw/0WdQ3I86F2xaGDnLBeIkoU1kTv6uKlNNP0TLGDctv89krubkseS5+j7vrmWoAJ16jO9RqTaKERCHyxkgQ+6tvlstb7yyQqe99IexLleB+u7BzCzn1xHrSoG41qXhIGcmXL3kPi3LerJP21zqRfarxjqkzvpCFi1ek6nE0FqbuxAxTYs6HBZjwmVqKuNEmTPxI/twSYuJwnhRknQn3gk4tpEXjo30AhgMPzHujfruCLbCwnnj+Pck2i6Vi+TLSpOFRsmHzVpk7//tcsbgRgy+R6y87PcgvkWW7Xr1JBGCDlRHqdsJyotJxKHBHr1mKDDzJnpF7SamToU1EGp4j0v253Mede5ikB6sCwuo7Re8FwtpwwiTdv5qfgZ62Z92lbrLBIk+cJ/JllO43crBOvC7clbL3GAwdU3RMlgd6DfY9UK1TzO9SRt23SZKQCszd/7Kffpfu149OyaR/rr55jr7/8rQDIN6fs0juuO9lIVCeCsl0JWafecOmrXLhVaN8E6bdF2nJsz018ho5+/Q4c2MiXSCO47ykjHvlQ7nngYmydn3irjasd+JVtWpUkepVy8uhlcv50IZF1ZolpgUqceu2XbJ6zSb5acVan0sSpcN4pkr63NBBBvc7P1Xdp6/fcd21OOQL/utd8qwIdbV6ldN9//r3O9cgngUc4BYshOlDjSW0Z6fI+SNVKSmaLpyAgiTuY8u03KnxNzfpr/P8V7W/WQ8794hcrUoLZfmIWobQWEUjTbqKXDYhmpbZ2wZy5lfVJey2snki0KHXTRI5vGlSni9qBcbVQGw1P/N2WamWWbKkwxnHy8tPRvhjS9bFgvQDOu/SGx+Tt2d8HuRo4ruyRYn99dffvheUSdNDvD05hqJShTIy4/U75Yhq+seYIfLBR4uk7+AJsmTZrwnd0dFHVZbTWteXNq3r+ZRXNEAL9wV5IZr9v8XyoX7+pwotme7rHheeJI8Nv8J9yezbflKtFidogGrKxJMeaRv+WaBmQtFZIcl2aGOdnPR3L1zClDNB0VnBbQfakDwn0g8oAeJkoaDG1cTe5lzicBRwhNDWKe+P0qRnvTe33L3UJFbfWSOQud3djm0SsLlXJvARukyyKy3YJfN0H8/64tUiC9/OfRvEKbGQj78w97EY98SkwOh75uyF0rHb8BgvE7w5sakfP3tUSpUsGrxBmvYSRD+x/V3ypbpLUyHZosR+U0uiTstesnv3X2GHAcur67knhG2TroO8gPS/5yV5avz7cV8St2eXji2kX88OPuh73B0FOZEXgynvfiZjNA4HkCRROatNQ3n92VsT7Sbvz4cQ94vX/fcB8wWksO/c7d8XbI3YFYwPMD8gU+7Uc+416xeOVs6+69XNt0Hh9DpHEcfZ5PKugIgDYg/DBsUagY3f20ARjgtNH3yjSM97yGyjGPtXUwUYJHxytLrEYLHAmosklFmB7WLhZJFGXfT+a0Y6Y/84TnyQWmRuCi7qp135qlqw5yb0nNpLbMLb6eFVD4ntpBCtu3RsnufKi1tjAntq5LW+ZYhbTWi3D9hxsaITv8xsdGLlCmXlUn3DDyfkdmWK8gLt2fT0AXErL0AnXTR+9+Ws4fL0qGuSrrwYxwIFDpRzzm4qs94aKPOmD5GLz2sVFXw+1G+QbTG9UM/hiz05D4LOi4ZWCuU0SoEG63L+L2FZkQdGTS+UF4JbcOaI3MqLY7SHIomSLUysSP8FIj3GGYAC287SLe/eH1x50Q5UYTTKi7afvmAsQeJm/xXlxXO3UuDGzTMVNKOWr1Ng93j2YhE3H6azTRTrMSsw+jy1Vb0ouo7c5LST6kdulKYWtWpUlpNaulwHSbx2tiixSL9JuwyJeT361HQ5ReHwPy5fE9evdEKzWvLFB8MEZgsSjtMhDepUkycfulp+WPCoXN29jYKUYv/vt25/QSECnnALtEXRCFbV1MGmZbtBmoz8ZiDjO0APkmjrdwjeG7lbPsmJtR1YUKRZd5E71Qq7+AmtTJwTY8RCnP1Y8D5i3Qu7Be5ROAh3/hHr2dndvkZr85JQwWV1ArV/rKPhmYzzCWP/H6QXqnvMYXFeLvC0+rWrBu7I4y3QdKkUlNjZXe/PaEuMSTacwCiRlwJQ46YBz/mS08PlT4W7x5uuPkumvTxAah5ZKVyzlB0DNj/y3h7y4eRBMbOV7BcwehQQ7O6xCiS7MGiQfGvrUbHPLVhQJOcCltinrByNrp2kxLwaLrj4ScdOXSU+dsJVxrojLvaUxsNCAUoCz4xua4cqLqy+vvp3N/mO6M7ZX1qRYH7rbP3tXEps11aRRxUEg1Uch8SlwA4/LHEXInxuVQ89OI5bTt0pjRqobzzFQv4PSgzqokyUCoeUFibYUHJc/dSPUahrb9u+Szr3GBG3y7C48hZOGNtTht5xUcrcxaHuPdj+4/XvDbfifbdfFDXNFDE/0gSyViiDMlg9Hat1GUnIM6Ki8uUvigz8Vic6tWKGqvIjqZik20gC16GbYR2CXioQH1QtdGL0fL0esa1ytCkW6SqxHwcpiWty86rYz83mM0pWUJTph7mV2JZ1Smd1elyWacwgDsaPWE6itERMJuu+fyajfg7y3MoedWlK893sA5Ps+/aLt2VUsrO9twat+wRlqSBWuHXFeNssrUsU/xldhsQNtCFu++a4PnlmdUUaLDgYOyg46hclEY4k380dKdWS8BIZ6TopOf7DR4adIVznEMue3k+k3tkGMQhn4s+fKnHv58byAoiBm/BoVUbEzsaeY0AClVUxdlLF4KYu+nC0Wj43mnjMOQruAK1oBWvQ0loVKZkb3g0nJsnOENX+qErta7XeiMOFklpttETLe6GOBu4nCbrjfYH7/gtbIBSHNcvNgtJUY2KXxja/6F9C7AKrQ6LCBJ5pQm5POOsjmfdrLbFMBHaUKF446KPmFVoU9pBOSr8UL0qU5OC8dBkGHUzXTtyZc6YMlkguXE5bl8Gcpa7Hyr0ZLPZlWx1woMiN00RuU2VVr51hd8CNd6t6auDWgyl9uk740xR1+NnL5ixAGbgRT7ohuPKilc05AiLvVF4cgxx47VKFyffyJ1ZjfT2oCvK57iJvDzQuRaD53Z7Soo46+d6koASY8Llft5z3oIGHR2O5ffWW++z/xjYpBddP0d+ieODzfqou3680nhmDxKXAChTIH8MlgjfNBMaGYHeWzvvKVCVWvFjwl4vSpVLgTgn2Izj2AUO/4MqRMm+BTjJxCKTCMKJkmrs62KNQbeG9N+6KCCbK6jgY1hHgFcrTt7gscBigKYLKaO5zCqiooQqkm0LhFWrtrrBMH5bNAQAGCcV1zsxtednesdwQilK6pUhpVX5qneGivOgxc5R2y2Yb5OA79yjQoL0q0YMMcweuP2D4V6oCHfKTSBO9R6cQc7viJZELHnHuzb1OkUsU538N0GFHonI94xp2A5kmXK1W9lrbKuJS/xI8cY5APMgw5/mxrmeiEgP6HUwsL2WwY6nad8Ntz/gIb+PpnzjruEdvkNpHHxrP6XlyDt6NV5662cf+EeoGshpKjwWGJdP+7tyuOJgbBh4j8oIqto0rcj9+IX1jJ9n4nh9MDlfuFv49oP6+fVdjTcNEJt1u9n8wSvPDRpjSK/6W/jWUGVJfFVbzS41lZ/aYb+inyDu7QxXYyFPNPZ5wpbOFWodDFPehbsdmPTTWUyvwmHPrlvfVXfaCJjevce79b63X03F2xyhxz46/Kupx8BSYa6jCWWCpeou3SixTgR12iNJdSHHcy7Nl/Gtz7OVjXl536ek+Ro2YT8zjE3CvT9Rk5XJlHLEaxz1ltQVWURWULV9C2Q2n7FZE2rplzj1mHeb4zsO1ztQqkS4PG6vlma4aS2ttilfaMwBHAMB4XPPCeqnFBLrtrdvUgttkWmz6ReTNviJ3qXV3f1OFtI8WoVSKU3Af/vyJSNexmuD8o8ktC1YfjBywB1uLPK/K1inke03QCfgvvRfcmqEEeH6Tiw2iMlSb/8J+ZXYKyLvjmReqe3H++KiePnFfYFSXyZ5G4RTYkNsvlPsfniTfaq2nZAtKrL0mO2cCsCNUMcd0KrCFi1dKr7uej3uYj9FCkvcOuCDu8/P6REAn40Zf70Osuu8lqxUYVhTy8zwtW/+dWQ/1DQM6YI5TNT5FvGSZvsxMvTsw+fWhkzUJWf9O4CLEvbdFLRpiYrj5Slc2DOolNIYGXJuikigzyIKXzzcfWDwg5KWQJaVVUH7bN2pM7FajvCiYeeYdJvaG0nEzcqxXJecWErKhyQpX/oV8MNIBYOhIpVBbbemHOYjHAwyVVZV6Ioc2CB7DS+W9BOubOOJlqqzu0ftxVoJ+q78mqJ9jWPCDnZezz1NgrsHJH4ZN/fe1f8j0V2+XMxUNR8HCZIu1xDJBiSX72WLpb9euv+Tiax9JqKTP8IHdEmK8iOV+U9X2lFZ1Ba7QyVp80ylrs70mGJWJx/XITS/kfEjYKohtgSwkf2r8lcrU8Yy2UPecU1BEA1URQEUFKvE4VUgwcxQr62yVe32zTuwo0SVqSVkAB2hHlBeCIsRdOFevidVHTKvpJca6iiaHjdhWuPgWbsaXrtOCmr+KdBhirpnMb6xZcs7mjQveK7XM2qiSxlVaoEjwNunaS521zvcrubLGIq3w+8BTSaw0jOQLc+w/eSicBbZk6a/q1iku01SJUVsrFWKVWF66E0NZYKl43mB9Dnt0kvwUJ8MG/THxn3yCTnz7gQwZcKEULKiTs0Oy2gLjOUATurnxHM8nxKJIREZ5AVsfpG5HH82US3k5zwFhSG5Yy8sjKy/OAzBy3HmazKyuwtu/MNYgoAq3bFyhII4OSnukyquS3kd/VZiRmO7dfYTb/n1JuKPxHQMEcd/xoZUXva7/WRXo9fo8Oo9F6a6L72aiPAtLlN/bKTOHRwR0eArMOWC6fqAbFeM4vmLVOt+WUWIDUqrEcCdmGsQ+HYqNsj0jx051jHrsq/fqpL+/SHVl/L+q26kBj7N+458B21m3EapopX0QXIAUkcSCwKVH3lAkwQKLV3jbjyRM8vc1Nu5HyrVcrlZkMmS3KwaXjD6f7ebPbYvUHwUrUc5PnOu3PiOdk4rjuBIZV6cQn5wy0Lkn17qnwFxDEs4C27BRzfIcKasVrHEn1q9dze5K6jITLDH3A6VDgUETRSXleKV1i9r6m6TGOo73nhI97yrlTXTKuiTUOnP2l/Z1yyTPhfMXzH15kGgjTjC8gbmPBt9DsnG8Em0tr98XG8tmwcsiR7YMfrWi6rokR6zdIK28fFzwNs69yVZg3ON37/mvQIpAPwWlwPNIknUo+fINBa0ca6D9odqkev/R+qJW98zAq2B5h/ltPQUWOFxaMkgDnSHEPYGTYzTtlQEpVWJYYul2J+KeDyah9gdrG8++2XMXy5x5+h8wAbmi2ykJnJ2Zpx55eAVpdrzGhHJkk9blgxMya4UcLmIwPacZEt1cD6LPRmwrFqH9huXqclKLAiSiU4JNgIveMS0glP3iNWfr8OsonGcuUveburyCSbmqJg/s7IHKefg/ZQw5OVgr/z5yzmDGd8f2/C1iW/vlK397YlzE7uCGBLjRY5wmew81ZWuOaOFvZ9c2rTIvDtHE+Ow5yV62vS2wR+KSvvEJ3G23PAVmRyLOpVVix9Y9PM4ewp9m0YnpVmLB7sqtwIO1SWQfCM9EBB7H9qc3SqSLjD33kvNb7bu3f7QURSqrPu+7UKpWqh2vDPL6xk89Ld78kyKq9F64XJky1DKCdsop5BUxEVphooZlA1Sir+zKL/ZI9EurAN1nMPm/qZPwyi+M5UByNLXHQgkK9LVeBpKfqOLYs10Vf86z44Ztf0/gVUtXEkFBdBwiQmFQyIvdwgsALCS/LXIfSc/2kWp5QyXmFF5IdgZ3m3sKzDlQca6jxN55ub/8F5RYnEMU8TQU9EeffBexXbgGnds1EejA9kehpljhwn53W1YnM5P7U6WBJhpPN0okWT8YcHHyyJwURXAY/jRXP/P8V1mxwMR7AGdAFRVOUASxCuCD+/RFCpccCElyxiLJso+U2UNdjk9fELv1CVSefLfbDlW36xhzJYAwC3TiH6EvPtcXVkSnTvU3lzEuUMAb8DWSOhBMUBajVenGwIgRrJu492E5OgV4/SfPO/fsW08g8rmvD29FRwCaJZRYu4uGxs3ZF24grSUGLVJelzQJd5/xHksUuMF1256sE8Z+KpBff/z23bJTUwyQZFSEyLuhUjc9cS54DSMJOVj4rmcMM8S9kdpznMmO8h21NKaCNQRfIjlkR+nbPcAAq1B+VBdfJKECdDeNwwC1D4ZS5HxiXXvVkoKpI5iQ1ByN8JyfvWo+FWtpteJzjDVyWEODrESZAjhZo8jFXxeaKtIscZE6LUyutU0tKVIPnAKsH1otPnPUMgwnJH2PUQXfRxUrdF3plAYdRcjdwxq0wv3CwuIST4G5BiSRTZTY1Jf6+5JPv1j4cyJdBT13f1Vim/7YJtM/+DroM0e7s1jRwtKqmf6n348lmyixIv4MsFUsV0sokjCpd7xXlYS+nICUs1KumuE/pGQ9CsopoBbp3ylMgOSfESfbu8t5JPw6faFABi3254s5z4D9vm0/k4QLK0cs8TRnP+514PUkWSdLqh5viIuJFZIjFo3QlsKhqchTC3d9FDVkznBiWqFiAC7WQwNfUvPZ494yOSNgldhx9asnp0NXL1aJZUJMzHVrcW9OnPKp/PXX3rjP58QTmx+TK18qoQ69k1M7ApGg9Pbqv31j1uAnxO1oZeMKk4/VX5UgRS4jCYoIyyVa5VXucH+PUEvB4Xj+KGX2qOjfzxpVm+eNMy7KZpeoxdQ08HhebxVXS+a6KZpXp+N0i7oNH9mibk1Vxlg50ciM4UqCrPG8dAukzm7B5ewST4G5BiQZm5QdwRJLVYHM/U2JvfxGFK6cCD9Mql4YIlzWOxzvCBzRPLozcf2RdMtbOZRD0EtZgam+qrrvLDO93Z+MZdfHjcVCXxbVCEIZ1ginMLk/f6kWZNQJl7iRBVE42zjXKbMCg32wStHOdslYh2HjLnUx1j87sDcSsikSWrF24P5gW3/ri+U4fb6/9wQ7mrp9AHzciPBvp+W6nqfAcg1JcnZYJXb8sUckp0NXL/uLEluz7g+Z/+UPrqeLffPYeofHfpJ3Rt6NQLQKbJdaDGN0AqZqL0wNWEFW3h9pQCBb9VgyBasFC8DmTVGjilpVyGm99UsVWTwC9+Hd6gq77AXD/kFRzlRK1UbGYoTjkXhY7/IiN+gLQD8FezzQWq+s7tloBERiMt2Z0VyT3wC+RqeALnWV1vEUmHOAkrxesgRVl/tL42Ndb21Jus7+oMQ+/kTdOkmQaApBJuEyXhfJGgGg0sGKWzbUONdRJwbW9oL094FWCqJQhCHlS6rnWG8Q806+0x/sL1zSEPjGeo8ldGK3pVQ4twbXVyVF7MsnOtE/p+5BuAshCe48LGd/jAvAFjzHuB6GGqtUpUCLMsbuIjYHdMK17qpproeiB1AC/+LKzyKTKTsv8O7Q0CAWZ7tkrrvdiABVvpsZcAVPgQUMR/I3fErspdukScOjkt+59pjtSixR6DyDShoDOWCeZNEIFCph3H/OWwYscLXGlHrPFjlnuPOImTyBpU/XiZQAv5WPnvCT5gLmuG+FFp+c7VA+tmHOsvYZgTso1dJrVuDbPooQofTLPlElNudxLWqpViAlWSJJ0TJKKtw5t4La8LNBSVKbDJh7tLFAYnJYJbEICgtEJghJFDTIzOrNDMv+tZM0Lva5//4oGROOjgtXoq2rFss9JNLWWsDOPlxuRE+BOQcnRevUd5ryosLfPSWWa4Q//lTfShOUKhXLJdiDd3qejEDttoGXtcUhcQ2+EURJMNlPGhA4kTrLm8CSQVwMC6pRl8C+2WrWXet8qRKyQjztJn2jJyaEe8+KdVPh4nPHvGybcMsGnUztMpK1By8xxTudFl64c0MdQzn3+dgwyMfiwgR00vE+TfD+zVSQ7jdP5MLRCuJQiDzxwza9TcLzqM0iQ1dq0vVZoe7AJJ2TQ5cuObxx7isBqHGIp8Acg5HK1X1K7DjPErPjvG37Lln202q7GfeySiVPgcU9eHl5Yu3TA6/+vVpCbw8ycHU3ND6gpVpDoWSiTsgwbbjjJ+Ry9Rinic4/+s8EGFI+5/8jdEtWvpthCISLqCUGK/5x59sj0S2/fksJchWoQRI1CElKguwrjlkouj7crTapciEWiMK5WZWu273mbs821tZw/f91Rn+/pcVLAHXNYCeZ+YApQXPKTYY8GaaO6yaHf17y6tIlWOlu1CdpEI5KBp4CS9ePoddBiVHrq2mjGim5ara5E39asTYp4+ApsKQMY/o7IQ5W1OH6fU8nVApWJiLU8XpYFaM7+dYqxEVT/b3DOAFpMLRP0D3BiI4wyT/Q2uQhweCBRVeklO9QwFe5asaqw8JxW2oosaGNNX+sjta5ukGTk18xVl4wt5i9bkDnQTbWKdhpVBuTC0XpmIsc1mSQ5gH5cau/0/paD6lCrq73c73GxJ5SK7ePobC6WX+DwXVN0jdcit2eDIwJOvuG7QQWj3SJk/iZa+LKpCBpjuS3K94yPSMAowJsGh26DZdPPlua9ItaJZYNjB2J1PxyDlxZrdHmSRaOABN3nTNNgjG3D0OEWy55VoRaXz+q+wzFFI2Q7/V4x8CW0ElR8PJjnZydApkutE81Wmu14kP8pVugpHrhMmfLwHUsK9yDlH1BcMcFuz/Y4fmEExCZsG68drO/FWNT9lBl3lDAxT86aVuB7YPr9PpAkx+vMflnoep5/aZtV+iYAsAASRlKUO70ywfGEyw3YoOhCnLOesSP0AzVZ7L2Q47sFsApOS7ffO5j3nbqR8AqseaNa6bkYlaJffq5/ifMYPkxgaKVzscqUrigc9Nbz6YRQDmFEiZxjhcsovRPs0K1Cr7fTf5K5eWRp4YGTSyb7VdewXsM3AvV0tMXGQYOjuDSo3JzLPEp2yPKEDeeE2BCbA/r4x79P9z1icBcN3LPHtVY1a6tpo3tx72E3Hfo8eGVl/sctokzocBDCQnF8C+mQ4IRDqPAcsSzwOxIpHlZrGghmTweS2yYzFvg/0GSdRsoMay8yeP7psxlmei9rl6zKdEufOdnmgIb9sgkcdaOS8pDxtlJ3WMOk0u6qAssU4U4GG7EHX/kvkPeslFev34TW22w3D0Z6Hiw/Ynsw014b0MTWzuimeHqA8H4whWaYqUKKFpB0SCNzhdZrMrBCpDx0Wdr3tY8k8jttAixKB9SizKYS9Ke71weoLYK5L18KtUx1hXW2VJ9MeDlgFgT3JHExSKR+AJnn/ecCDyVqZZiZXNfAVqpHMlvV7xl+kfAKrGOlwyXufO/T/oNZLoS275jd1KeuUiRzLLAJkz8WJLlHk10gDqd2TizFRixKuDmc5/N/ajUDCOBeUz7QMuJ8vMAJIK5HHP3ktieQsUVfn64mfRx9ZUsb0qxWIJeLJURLUUaX2QUAC6vpheHZE8PejNYNBAL28KaxNt2btGm/xr346s9Rbqrwti4XASEpi2CyfPjAg0n5dXLQ00wkpqdyoAXAxQWzwFhcaurc5bqlqSI5MRbc3NMOq+TLgVmUxqc1yYVIUc8BWZHIo+WRon1lY6XjJD/fbok6XeRyUpsR5IUWNIHzeswvSOAmzCYAoNuCdACCDwrIAKpsYU70C1YEU0vMXud+WHudna7xzhj2QDU4IOl57acWl6pRSDv88e6OJc6Yi/qRG+FGNL8CeZj98WyJE+LuNYeVSbIOSNMkvcLl5ttqKyo7dX+bgWN9FA4fENVcApAQSw4xWzl/v5rVyBikfpjT2i8zcdqry/NlhsS6D+KjFI0p2osDgVleShz92rovYjtRUNHFez8RPbZZ9c+PAWWyEAm6dyiRQrJpBf6SKfuIyRZzBTOW8tUJbZth/7nSoLs3LknCb0kr4s7e50jUGT9sWWH/Lllu6xZ+4cs+/l3+UE/e/bsTd6FXD1VPfRgqXP0ocISUmk+tY6q7GqVgZuAKwBQYG055cuJzi2TiHvRGFOKZenswGMk+kJWC1MG8S7ACJFkzljlBFTFg/WEQFUEU4YDpu2rBgysntwpS/2EtVKhltbg6q/nqOJLhjgTmkvrbwZtlhVAHLM0vnbuA/p8apV2uFfklRvt0fBLYnUoqzI5fwcAXOCWZOkUlCWKGhaUfPlEjmwRXoFxLpZjqhWY+4WC6xL7yxFPgdmRyOOlUWJ9pZNaYslgp3A/TiYqsb//1jfXJMiOnfpWmUFyfsfmQe8Gl+mMD7+WYVp5etESnViSJBTyvO2mTj7llaQu09sNYA0opMhPCiVlq4r01AkTKwEXl3Niq1Jf5MZpSiNVycCsgYc7BVJb3HIwTUCjZGW5KqwhjUyu1yFHKvquqWGnGHVaYBwIKiviTTC4N7/MuN5qqKLrN1c5EscblyLuvmRJmSoGtEHpEFul+aMnTT4Zz3HCVToGz6jF+HUUV9T7ur26KUdDLbRQiEjGgmcsV02ZTjTuRjmXSIICIy8tlQJs3i0UuMyRfHbFW+b9CABGeEstsROb107JzVgllinoxJLFiyblOXdkmAUW6qFwF3c+q4nMmz5EQim5UOeG2n/tpafJhMd7Zq/ysg8WDo0Iwq//fD/ijhImCPEzcrBINkZ54dp78nz/pE8bWNcf1QlvxO+GfYJ9TgEqTp0xXG1IlXpKZTUnEPVnjoh8PUnksfZKVXWQ5nfp/9E7axrARjKVF9eCMxEuxk5D7ZVNDa9Zj5rt/PrcbXqZdRRatca58978Z6pS32OqPK//UeON6j485RZT4wu3JC8OUExZ2bjCAGaWzbZ7Qi+J29lYYOhWiR3hN3WLg6XeU2DuwcnjbZTYm8/3ltYtUqfE2l88TDJBiZUsqW/GSZC163USyiI58MB88viIK6Vi+TIJ3fVBZUvI4H5dEuojY04mEdgxMe27L1yCWCJYXdBLgfqzhK7Nexj0HMi5sTox33aYKpm39p3qy+3CPUi/qxebPvxH/WtUNUaJWSQkVkiQ6r/7TsDdh1UGgCMVZUbgHMSN6XRlcnEAHLjPYIafoG5MBHAHyr2HLsNJ6xvUwtoocs1EZfR/SBGEA9Siu8NwT96tChNi4Vhl7x51My6K9azY2lPHzS0o8BzxFJgdiQxa+pTYuD4pU2JQOGWCEitVIjkW2MpVGzLo14vuVviNu3TSOEMCcmrrekJO4X4h7z2obsEgbjhYF4hnTdbJduaIQOuKpGRqccGPSKKuhaMzIHAPXqzHERTT450Nqa3Zk/t70TuqCKoaBdn7EMNSkbtVavfgSkWwlMjzwpp0Cuz7H442SbwWUci4oOhQ1KWrOFsHrmM9AqVHUIIwbgCjZx1KrVveD251mjNCfwN8SaXArOIWB8uKp8Dcg5Mh24ULF5A3VYmd1LJOSu4oE5RYshjkf/ltfUrGKNWdNkuQUqxZI3Vh7Q+yTX8/mN6TJUzIEN/Cc8gb/BPnhU/Mtdel9hgxJ5bplqrHGxCKvS50TU73nK0QTZzwOLUWYZIHIo8l+MHD5iyr1GwfziWxP5CbQ5sogXEpg2Qkyflm9QIQX6tYS3kQVcnFKlivqRTos9zieE5PgbkHJ4O2UWJvPNdbTmlVNyV3FUqJ4eJKh9SqGeaNMYYb+HX1Jtm7V5Mrs0yOPLxCQndcuWLZhM7PmJOxvpwovERv7Dx1tRHbeq67WlXVNFFXrYtMFkqZXPlyDp2V62+CsixYksTyEBQRBSpLaTvcq8g79xgrc8tasx3qG8Skj03eYekChsHCXaDXr9IgdisslS5EXiQg73UL6RI5kp6Zyl7NW8Y8Aiixic/emlYllizLKNLD1k6SAvvrr73yzXe/RLpcxh2njlkikq7fKZF7jHguSbnA2a0Q77ryVQMVJwfryBPC16my59kloIbpCuyApPfTF1ITo7LXStYS9CPKiFjdviKa2jkuxVtnmyKelnORa8LCgdhK1Ez01Bez2+Zo8O+aJxs2DlsUlFYkBj+jLsjBtYOfE27v5lXhjiZ2DOsumFsZwE6OeArMjkQGLwsVMkrs1BPrpeQu3ZbYEdXKp+Q67k4PrXyQj6HfvT+e7c+++jGe0/L0nML6uyYiRTOMgSSuZyFh1iam8mZ9/RRDqXTm7YYVvc9Hqow0DuKuHRbqYvT15+pQR3PvR2ECj4fANh4hZwtofyKCAtmmAAvEqYQAKwDvR0ocbJZ8wwiP/OmIDwHwiISGbHKxIQHu9pS6Ed/VMisDlKFD3Yg2pgT6MVaFFMnq891onF+u2l/7erGWp+7wFNi+UcnsFZTY68/0kjYauE+FOJVYbU2GTZe0SBKh8Wdf/ZSuW07adQoWzJ9QXwUKJHZ+QhdPxsmwSMBsbuXyl5RaoZDIsjkmz4mJGt694uVEbphqGDgSVRb2WnYJfP/atxSdpyAQrh2tABKBEWToLxpPUgV01l3xJ/WSbAwsH3osX1mXnGmZGNjkO80dkRtWsoJZh7sQBKBTUUcTtzvsOP/TFS6hKQhDNJa2QOQRBXKcq27ceIScrGS6f533sGiac8u/Tt5fjngKzI5EFixRYq893UtOO8n/Aybztq0SSyezRdtT9A04CTJ77rdJ6CW7uiiQX11M2SzU5nIWmKRgIwjAB1trwcUrTGJtb/UGvHiteUo4EAcpaCFc1WDneAAdh5apg07UV72mSciKWHQL8HwsD2JKLS5zH829TQ4Vbr0h+sLE/cBagTJoP1jvTf8GqWp8Wt/c50XaA4EuOU9nD9R7Hu5vbVMG2EP9NASLDSUWiUbKtPZ/w+IxsY8BbvQ71BS1RHli6ZGSEK9EIv+Np18saesqdZ/vKTD3iGTPtlVip5+kAdcUCErs+n5P6/9L/Y+ZBjnjlOQ8x+o1m2VBFroRExniYGlTifSX9nPfHxV4yWBv8ts3KkpurE68vU1bXGlwAoI0jCTkhOE2I+fpuPMMg4X7HFBusHG80U/kiBbuo4HbjbuaHCrcjd9/YJCTq742beAxhE+R0ijnDFMlpooiVuFZESf7hFNJOYltx3Y2baP+PkDk1Zu0qOUDBuACGISilhSyXD5fQSCbo+4pV0PrAs51IIEdX+gLh3McbFeUmHGUWEnPLGUv7i2TMgK4nl59+hZpe3JyJn/3TaHE/vnnH/fulGwTB6tfu1pS+p7yrkKLPcmOEaCe1A9zzL3C+N5L3YWPqVvsDlUIbftrzEctL6cAUhh/pULLdxugw2066R6ik1k44RpM9OR4LfvILIO1J39splo9z6qyCydNVIFRMZp8MXK0XrpO88bUg3DrwUorpS6+4aoAx19l3HtnqesPN2MsgnWESw6GCytOl6kT8eeE2Nu2YZf/KnpxRe4WuB4fOTMwnpa7Vfg9wRRN+DPCHyWvDSBOMDm2U8BeT4EFDEf2bKDEXnnqFjkjSS64vHzyq7qfmpTLv/H2pwpa0v+onmT+CEAHZV+SumgcrGZrdcepS/TQ+oZUFldck26Bz4G7r29FkbcHazt9ecPSiSQAAUa3U7fkiSLT7o3UOvzxR3Wif3ugkg47wBOcsW2DWjDq/kOwavpVVgj/JYHAC3M0/DcxrSXvmxigbYl78937TZzpphmq3G+zR2JbFi1reBxxpfZ4PhAUw70/1SW2/pytiVMmUz4Zp27SFcF7hDXfIfkd695qlo2AVWIXXjVKpr3/ZZbdvf92L+zUUu4c+ops2rzNvzOOtZWr1ss7730p7U5zBKvj6Mc7JQ0jgFWEVK6niqqrWkfTjCsLsEKLy7V8iQIqLtWJFgvkg5GmLd+4uqYOMst2qkzSJcXVyqIe2JEtdfI/XQSr8Qe16rA+sOCYcGENwapEocF84Rae6/NX/fW83MfZ/vBRw3toj4FKhPW+xCEmRmcRiPZ4NEtIjAHBUHTTSjNVsItVIfJSAOt/IhWWncTKtv94l1hf04YEPxv4/OGNA455CixgOLJvo0CBA+XlJ2+Wi64e5Zu8s+8JNAauuW6XXniSPPjY2wnf/phnZngKLOFRTHEHTPhM/gg1p25R68BJA4V1duUrpgAjvH0oDNyHTog35UWOOsH0kcpvcrGA9nMPWIhOodClWyAF/kb/jpmE3SwVKBIYQmB9DxVzIrYWTFAwn6hCJ14VqzBOVnlxf8DmiXHzTHxI+CZnLphQXgUGe5RyKIkmHhnqXPd+0ipI1A4mpDvIAQFH9Ck8yfYRQIm99MTNWT1x33xNO1/9qkR/iznzFstXi5Yn2o13fipHgDd/YOBWnMqLfdAoDVErGlg5wiQ7SCfRVtfohmMCezNOd5qv0yi/Gp6jqEd1HXLd5QuM+3KhKjQsBaohU4gTlyZ5WCAG4RsEMNLvE1N80nmZpbOM6xOXaawCxP/1W2M9y7RfOtsQHfcsqZZYEaWMKqCxwXP1pUGBJ8ipt5il+5u8PCw3EsrDSayxvlB9odRx0YYSW7fNcdyzwByDkc2rKLEXx94kF1/7iLw94/Ose5RyZYrLgFs6S99B4xO+99vueVFmvHZHwv14HaRoBJyM8SAKccfx5k1SrE3k3bhC5H51eZ10gybc9tccKAV1dH3cQN6XzTY3BultqgUUI8ANkJCWGb1gMZOfZqsZO+8B6qeL9D7hK4Qh/ke1uHAtIiAeqbN1TBuzHcs3fIcWpRjLebg+ccvaumKcC7LxqzdUAavionBlMPQn7QDTUKHZCSRhv1t45mQIKElncrazT9hKgqBEPQvMOUi6/s8//7r2ZM+mUWI9pX3bRtlz0447vbbHaVLzSPVzJyhUtZ78bs7be4J9eafHMQJ7dxuY+WcvG8UEkALKKATAwJdvmnWKQ4LWwwK46xuRYeomI8ZkhdgKrsL+1UQGHqMowW4iV7yk7XvZFqlfgjTEKrDKiytiMVrlhfJFoVnBinj6AgWb6N8x51qWC3uc2B/KmPNiEWfScrTnAenvv0CRnWopYhG6x+11HcfNvxpm+mB9kiOGuF2nZq/5JpejaGnnnvjWiQ1SHDSUnN436BHPAnMNSzj4eLpIbl23FNNmfk1upcAhlli2wcoZ3zHDrpDTz79XEq3W3P+el+SUE+ruP+VGYvoryKPGEOji1kNx7dwSeBMFi4q01gkdF5t9469U29AiHa5v1wXVtXVgToyIMh8TrvJbDSiLNWq50D9v++c9aGJBoRJdA6+c2Bb5UlaIh9VsbQpAAiiocaJRuMSAiBEtna1gFHW5ffWWsSSDMexbS4gK06GqI9vrJbJEccIpybjirsWCAaL//kP+XiH2xVULHZZT+K34jcgZA7gSitKJcziX2F4islJfNimLE0rI/arfIejRBK8ctM+s3rk3TJl7lEM2iFVil1w3WiZN1z/SLJLmSi11R69zZPCI1xO66xW/rJOeA56VZx/WSdOT1IwApTyY3HgLZ5IE7h0qAM+ESOFJp0zMielAwIurjlgLMPpq6kHgjfvpC52tjQvJktrCSpGoAmNyhk4Jiwg2ja3rTa4UtcUAkpBzZgUAAawelpvQ7rdL3Gy4Dfl0HWvg8AvUWkSZO2XLOrN1ULXUKjCqWJM2gMVHLOvupSJHn6wsHO8bpOPCyeY+cNlaty17jmpl2O8fOUPHYrnIuB6BZV3MWf5vBy+hf2cMa7hVx7RXhbkz9EnnqdK1tcxcrfR1yBPnCOze85dzM2A9XxZRH6DExj9+o3Q8o3HAM2TDRt8bO8jJJ9RJ+FZfeXOuvDjx44T78TpwjQDlSe5XBQJ/3wtX6Nvz5YbuKZTycp2eaxMmh9ljNCm4gUHorVpoIN7uhsC9bTKvjSu524Tbxhqp01bJe/Vtnlph1L+q0VoLRNYyxSB9xL6dFL4/Xi2TnxXirywVCBbWJc8Y5UXO01qddGcM1+Uyc5xvCkSOUqUBWpJE5HrtjLsT6imnoLiQZMWNTG+5v7EEbaoC7k8KYf6xWqTWKYb3MQggwtcJJMoVaopcpmMAcIVEZwAroSSUQg/V3rkflCZVA0LFvWjbQi2zMNRh+Z39eev6e+3SN8kQ8rdNvAxxPNN245JDiXW/frS8+c78TLu9kPdzgL4oPPvI9XJSx4GyfGXOG2vI1uEP3DTgOaHuVpPjdMLyJPERwDKh9EYo9gViWhWPMe6qV3v63YXuKxdSiwerzJ1DRJ4Tbq1G54tcoJMubra5z/ljThxnYrYWhLtf9zaWUbPupmIxCikY5BuFDEgCNyBxI5QayMdb9VojdcLfst7Es4D+Y0HZe6Yi9C0fiJSrquwgx+o5qhyxKj+doDEwVWJV9TnOfUBrbb3ot3KoYAyUPZnJv4A0Ot1nSrJAN7VaxwzrDyVm5yyqVk9S5YQVBvEwiE7auIX4JNYbY0Xs65+97haB27iB4xFqk1F1mmrZoaTsoeouHhnqqG9/XBbY/sx2sGVraFN2795/wg5mJh5EiT0/5gbp3E7fmLNIDjmopEx9sb8kWvNqx87d0qn7CFm05JcsevoMvVVykcZfEVp5nawKC1QhDO9AzG2syz4OcRmQbX3nqmLYpKCNX3PHX2iLgsD1hmsRxveLn7A9GDclE3E0gscEKwslcljD4MqLfrBOvtHJ/udPNdH4NaOsbj9CiXn1/wyKBgAFIAMsGVyYluYKKxB2DhQSQkI2Qsxu5gizTr5VSx0zC/8n7vRGXz8y0bSK/RtrEoQg7kFKo8BaQo2vSnVU+XfR555sqjYXKubo+18DroGVBJ8EZUoAAA8VSURBVLddMPlYx5p8M3dqQ7C27LMEw6GOB9sPz+HINuGVF8qz+3PmbyBYHzn74lJge7SAYKJCEcJME6r6wgMYSrbvCH0s1DmZsN+nxEZnnxI7vOohMnlCPylVsmhCw/jHn9ulfdf7ZfH3qxLq5z9/MhO9G5xhB4Vgfqf77ZZRFs7yJIccpblInxhLgdgTgI1IDBAgEBEUgwUaoEScBLemRfBv3GRO6DWuMHdyMWdiFQUTFNRv3/qPwL04XJX40BVqyZxi9hMHfLyz5oC9p4AJ/Tttf4+yu6uSQ+HhYsUdSpxt4CJ9ZlXgyGxVyhbMYfZE/gZ6f8v7Sr67RLkLt6ji3CHy8Fa9H1WuFfU6ToGTcWAtw+1Y4WhFIM411295ub8VgJhQAnpy1zaRSEwn/Ia4XaOVtUv1nk9THklVsO6XG3cfF43xj7H7mGM7LgW2a7f+ISQoO3cl3keCt5Dr9DXrwvyo2vrPLfpHk6Vildg5ZzfNqieoW+swmTy+n5TVPLFEZO36P+XE9gPl9ck6iXoS3wj88oX/PNxlTI5WzrzDIN7sdpdRInfq5I2A3oPHDyvIKa2vF7lQJyqnonMeX/m5SWbmbbzMoc4jkdehokJxILirAITcelAgCs8cFWmjbj/cVVaoP9a2nxIMz1Lrb6xxJ2LNrVsm8oBaL8S4zh6kca6zDSJx8XQzMaM4YKG/Xe8b6xHlRokY0H9A7f/eY66AhRkurmTvwy65n0tfMBM6Y4771S2gNCEYJgkcqwwORYA1PfXerGXW7WnDph8plu8D3Aw3lpj7Os7tg6qrRaqWYDjhZWPZbIMqvbueUfTh2nOMsT/h6kitfMdVhcYum/9Q7ZygYOlg8WQSsm/VbxvDPtWGTVt98G6UQTaKVWLEmCZOyZ6JvHHDI+WDNwdK+4uHyarfNsQ99LgTu98wWj7/+ie5746LJFt/x7gHIJETyQmylkqN1qYI5C61AO48ykzQuA0RyJTtBAkYAIFBPBjtEu2A1pNH9ExX09b9jbXSQa2aWCmUcGcCVUdIkAWajwRzeaFIqQUGAS9AB6ijbMmOmieZyRTOQAAaWHCj2hiLkNwqLBkmZgSACcoMxCI5bnA4Qn/FM0RrNZqeAr9xodpillzvHR0PlCPKsubJpu0r+rwQAROjRHAdwqJBIrMV7gFQCePCs6JYQwnPG0kAsdyvL8S8mIBG5INbkzHE3bxhuXHNOnPoIvXJ31GnoZFa7Tueb99aDCs/r1gXQ+vgTcm3Wq5Q50yS75b9GvZ2iP0t+UF/mCyWfPkOkHGPXi/ndWiWVU9BgvOHkwZJHbXIEpVHn54uZ1xwn6zboK6YPJRffo1fGaf1tmGAgL8Ppoyqx5sJ3hcL0smRIpEkH9tkVtxP43qYuJBPmR0o0lQnSysowh8+9oML2I+rL1RiL644wBKiijFaKVZW2TsGmNZYO1iHxOaw5EAcWiEeRTIvbbAkYGq/cZpRXigKACRW8RDHAqxhhQl6/gQDdihVye41sT+2gOVboRQMbeORphfrC8A5/jOhbQJsgkLf5x7VsbHjb1te8IgiLXNeINiHFYr1COLz2M6G4cS2TWTJfZDvRr22x/VFhdgW3Ipv6fh//JSJG0bbP5RdPcZpa32xiVLiUmALF6+Isvvwzb5elJx+wl8l+qPzv/ghYuPPs7B0vfuhUGLPKcrv/I7N3YcyertShTJqid2VFEDK/z5dIo3b3CbPvzI77SVYAArdft/L0rRtziSb0aOuNzdLJ0MLW7/8RTM5W+ACaDViWsg2VXRznzGuJ4AKPqSgTq41WpnjfBMvekC3+1TwWwvsR7kEE+peTY/+jdzXhbMWF+5LkmDhNERA7CG486j/BYfhGD3uYwrRiRPX37b1hvljUB1jYaDgELcVSR4arkCnO9BaNc7cKkAgq781fcTyjVsTJKYVy2aCwqzbzuF61fsmaRmEIQI9FBagFZKxx+rz4/okNoYF+d6D9mhmLFtdZV6MQrmTQ9xlzAoMhoSpM74I0V1su996R9+AMkR2a1xvxqyvI97Nxzrx7Q+CEiPJt0sn/WPPIilRvIiPaeTh+y5TFvuCCd35ug1/yrV9npKWOuHN+FBdQykWaMqenvCB1D2hl4x8fKrs2bM3xVdMUvdOih9rWRBT4o0eAlubL0V1YjuZk9f1Wi8TJ0MpIAvfVgslZ+5ASRBDQXC9havqGwnKbXrxfxObsoIlRYI18SkQhVhnCJYD+VwIsPz7Gpl1vmGSt24vCIVxhSFWgZgtk6v2QGuj8Ow+XIYoabgTExXcg3bsuEeLHNy6Vq2rGoG9k+iLNYxgbToFAIx1NfJcuBpDpUE4z0vHOm5kUgC6qpuUl40YRZ86Nnl83EzZuHlrbCeFaP32zM/li4U/hzia3t3PvDRL1m/cEvGiE7Vo4q+rN0Zslw0NUGLPjLpWLuicXUqMsb2y2ykyZ8pgqVUj5406gQGHvb7TJcOl0an95IVX54RFosZzmU0aM0Zh1VHF1bP/s1H9nUW6ToM61aRkiaKRmiXnuNOaAHmGoKzIi8LFV66ab9e+SZ8tXG8wOVirhXjZKzeadnzzpl1FY0colecv8+9PxhoQcyvwJ1JPy+YbbciZb0AMOgXr0YoTqYjCs7G0zb/ZFmaJYsU15xRiUE6yYuexmNfVerWy+F1DuzV1sLFcbR4ZicYg+wCYYFWRx2aVFb8B4A5ccj3GmeRt218mLPkNLlPXKqkVcUpMCgzrY+Aw/YNNkmDNXXrjGIH2Jy/lpxVrZcSjk6O6BeD/fQdNSJirL6qLpaGRVWIXdm6Zhqsl9xIgFOfPuE/u6X+BFC2iE2KC8t3SX+Wa3k/KYQ2ula5XPyyvTZonq9dsjqvX7Tt2y/tzFsmVt4yVIxrd4HMZJuPvvN4xVeUlrf82b/qQhNMLon4wC8rgBFsGxVI6sW8fzY9jwmU/YtGD468S2bTS7OO7Sn0Dtad0PGjDZArJvFbsRG+3SfJFLCzfbBnwgV3fuMKuGdejL/lZn+3g6v796Viz1izXKnGwueLbgwzE3TLTY/EB4b+zpnmpIAnZCgjIB08yVFA8Q6SyKPa8VC95CWp1tTKv/GjinwlcL+d1KnwPQJCfeP49eWDMFB9yMHzr2I7+uHyNtGx3p9x567nS9dwT0k6+yiRzxc2Pa0Bfg5tRCvyCXa4YKY/ef7lULF86yrMytxmoxKdHXaM17g7IOuolUKy3Xne2dNF4Xh8txTJ5urp8EhTYWN6atsD3oatqhx0iDesd7mP0OKJaBV9ydfFihaVYsUK+6gWgcjf/sV2wtH746XeZu+B7Wbh4ZVJfcho1OEL69ewoZ7VpmODTxXE6LsKfPjEnYslAZOsssWHh4U5WdnsZwAUwPnz+it1jlhVrGZciE3KyBVefBYVAG/XtdP8VrAID1YdSgP8Qse2xqjapUrCyzx2pVkyf/ymacYFh7cDScioY2z6ZS+vGpM9qjQN73r7JbLsVNIwgCK5aqlwjgClAZVoaLrM3/d+8CDU816Q3kBeYBNmnwJYs+03gAdyhb45bFeK+Sd2E32ri58JvV8jHn34vqUw8ppT8LXeM85WVb9H4aGlQt5ocfWRlKV26mJQqUUQnisK+SePgco43qxgefumPq2Xrtl2+Z9iybafP4vtJFedULT8f71vxtPe/lBlNvpbTWteXZsfXkOpVy0vlimV9aQFMqgAO4r3fGB4taU1RYk8+dLUioA+QCa+rayjLpEqlcr7K1Likh6s1PXXmF0kDZ/A3Eu/fSSLDyG/RpnU9ufGKM+SUVqpE8kpI2rUKDCuq0jGBk/dKnSxBIpJ75BbcRAA63AIEG0oqi/JzH09km4KTJ6jFh0ASPOUuQwHFNmwbVoDUfzPVbNnYHhaNVQr5C6o7Ti0YEnBBIJKgjCIByNL2NkMzZRWg7TOZS+J0MGLwYgDJbhGd/2wiuXXrul2h5IAh9rlYnzncAG/cxMIcS7WgtGDCb9DJoB8TJf913e8BCg332f1V1W0STQzIdX7aNiF4HdT3/LiuR+zhZ3UTplPu6n2e3HZTx3ReMinX4s/hmt5PyfjX5uTq7+ijKsuXs/Q/QxYI7sAHHpsiAIUA6GSTAFTpdn4ruUbro8HjmOfCpD7gcDOxM0Fe8bJC5S81MS5urlYbkzwbrCz9wUcqglFdRemUg6opY4UqU4toAxkJ6TACtdPw39X6OsSUC5nYx+yH6eKmmSbORMoAAvFvl4eV8kpjxCARqyrQA+YJ3HdYYFaZmNap+T6tt2HBp/fXb1HU5ChzHSzYQd8ZjsXe5f3X7jdPFUYzkdFn+S0w/9HkrGF9U/MNS9eoD9MvbkpicMQ9+ZAfBgLUKtXkXD2gl30WWMBeb+M/OwK89Y994EpfLiqAhmyVY2pW8aEsR917qbw5db689Ob/ZO7875NmlSV7XAoUyC+nqpVFLPKs0xpKkQQRlkm9P+JYuKCAnOPWerB1YPewP4SSdCsv7mPDCpPs2+Fec1eQ+U6+Q+99jSphBTbMeUxpkgaZel6mhd+FCPDECoTCY881eVfsI9bEJ51C/a6mCkSpXE9zt240KQ08A4UofeKzP/x3hLIgT2zxDP++ZK2hNEmetmhHcvNQYgB0sKS5dhxIwkRub58Cw/1VqJBq0AyV0iXVjI5TSuobbelS8Z8fz2ULZ/BYRnoelNjjI67Ul9V88uqkub44D4AbYmTZJiXVBd3jwta+D+jRmbMXyuy538mcuYvz3OOAi/lkVVptTqwnp5/cQMolSJeV0t8GZYALy7Kbp/RiSeicvDLrfqPgIpRVICcRS8WEhdDuLmNFgIhEcHGdpcoOgVUfFhE+eSnE5FBgpB3wHDBdIMTrsDJxZ2IRAaxBiYBMtM9gWsb3DTgHsAvXBbbvBr6AbmQs7XjGd5WEztrnQkyoF+9kbwSycAQg9/1ME9O/W7pKYGHB7RiJDzPex8QtCJvIsXUP932Oa1BdQFF64o2ANwLxj4CnwOIfO+/M/XAEYK4HOr92/R+ybv0Ws9T8wJ3Ko7h7916ByBqwk01CLqCAnQPz55MC+fMLVnepUkWljFr7WPwHqYV1WOWDFMV4sJQtXXw/HC3vkbwRyNsR8BRY3o6/d3VvBLwR8EbAG4E4R0CdnJ54I+CNgDcC3gh4I5B9I/B/l7/WykLGwiQAAAAASUVORK5CYI");
        }

        template#template1,
        template#template2,
        template#template3 {
          position: relative;
          display: block;
          background: white;
          color: rgb(51, 51, 51);
          font-size: 12px;
          font-family: "ING Me", ING Me, INGMe, "Roboto", "Noto", helvetica, sans-serif;
          font-smoothing: antialiased;
        }

        .legends {
          color: rgb(128, 128, 128);
        }

        .clear-float:after {
          content: "";
          display: block;
          clear: both;
        }

        .grey-light {
          color: #adadad;
        }

        .grey-mid {
          color: rgb(128, 128, 128);
        }

        .orange {
          color: rgb(255, 98, 0);
        }

        .align-right {
          text-align: right;
        }

        .bold-text {
          font-weight: 600;
        }

        .bottom-underline {
          border-bottom: 1px solid rgb(0, 0, 0);
          padding: 0 10px;
        }

        a {
          color: rgb(0, 0, 0);
          text-decoration: none;
        }

        .header {
          position: relative;
        }

        .header .logo {
          float: left;
          width: 35%;
        }

        .header .header-text {
          width: 65%;
          height: 40px;
          text-align: right;
          position: absolute;
          bottom:0;
          right:0;
        }

        .footer .export-details {
          float: left;
          width: 50%;
        }

        .footer .page {
          float: right;
          width: 50%;
          text-align: right;
        }

        .footnote {
          display: block;
          margin-top: 20px;
        }

        .header div.header3 {
          font-weight: 600;
          margin-bottom: 0px;
        }

        .header .align-right p {
          text-align: right;
        }

        .loan-account-number div.header3 {
          margin: 0 0 5px 0;
          padding: 0;
        }

        .loan-account-number {
          margin-top: 20px;
        }

        .loan-account-number p {
          display:block;
          text-align: right;
          margin: 0;
          padding: 0;

        }

        .annex {
          margin: 160px 0;
        }

        .annex header div.header3 {
          margin: 7px 0;
        }

        .annex header h4 {
          text-transform: uppercase;
        }

        .annex header p {
          margin: 0;
        }

        .amount-container, .amount-container-two {
          padding: 0 0 14px;
          margin: 0px
        }

        .amount-container label {
          float: left;
        }

        .amount-container .amount,
        .amount-container-two .amount {
          float: right;
        }

        .amount-container .amount u,
        .amount-container-two .amount u {
          border-bottom: 1px solid rgb(0, 0, 0);
          text-decoration: none;
          padding: 0 5px;
        }

        .stamp {
          border: 1px solid #000;
          margin: 0px;
          text-align: center;
          width: 100%;
        }

        .stamp .copy {
          padding: 10.5px 24px;
        }

        .stamp p {
          margin: 0;
          text-align: center;
        }

        .stamp .date {
          border-top: 1px solid #000;
          font-weight: 600;
          padding: 10.5px;
        }

        .stamp.bank .copy {
          position: relative;
        }

        .stamp.bank .marker {
          color: #fff;
          font-weight: 600;
          left: -56px;
          position: absolute;
          transform: rotate(-90deg);
          top: 56px;
        }

        .visibility-hidden {
          visibility: hidden;
        }

        p {
          margin: 8px 0;
          padding: 0;
        }

        table {
          border-collapse: collapse;
          margin: 0;
          text-align: initial;
          width: 100%;
        }

        tr:nth-child(even) {
          background: #eee;
        }

        table.head-no-background tr:nth-child(odd) {
          background: #eee;
        }

        table.head-no-background tr:nth-child(even) {
          background: transparent;
        }

        table thead th,
        table.amort-sched-table th {
          background: #eee;
          text-align: center;
        }

        table.head-no-background thead th,
        table.head-no-background thead tr {
          background-color: transparent !important;
        }

        table thead.not-centered th {
          text-align: left;
        }

        .with-border {
          border-top: 2px solid rgb(255, 98, 0);
          border-bottom: 2px solid #eee;
        }

        .orange-border-top {
          border-top: 2px solid rgb(255, 98, 0);
        }

        th {
          text-align: left;
          vertical-align: top;
        }

        th,
        td {
          padding: 10px 14px;
        }

        table.details {
          background: #ddd;
          border: 0;
          margin: 28px auto;
          width: 100%;
        }

        table.no-background,
        table.no-background tr {
          background: transparent;
        }

        ol {
          margin-left: 0;
        }

        .no-margin-left {
          margin-left: 0;
        }

        .padding-left-34 {
          padding-left: 34px;
        }

        ol.list-style-inside {
          list-style-position: inside;
          margin-left: 0;
          margin-top: 10px;
          margin-bottom: 10px;
        }

        ol.list-style-inside ol,
        ol.list-style-inside ul {
          list-style-position: initial;
        }

        ol,
        p {
          text-align: justify;
        }

        li {
          margin: 10px 0;
          padding: 2px 0;
        }

        ol ol {
          margin-left: 42px;
        }

        ol ul,
        ul ul {
          margin-left: 14px
        }

        ol ol li {
          margin: 0;
        }

        .list-disc {
          list-style-type: disc;
        }

        .list-alpha {
          list-style-type: lower-alpha;
        }

        .list-bold>li>label {
          font-weight: 600;
        }

        ul {
          list-style: disc;
        }

        .dark-gray {
          color: #808080;
        }

        fieldset {
          border: 0;
        }

        fieldset legend {
          font-weight: 600;
        }

        fieldset ul {
          list-style: none;
        }

        fieldset li {
          margin: 0;
        }

        .all-caps {
          text-transform: uppercase;
        }

        .inline {
          display: inline;
        }

        .muted {
          color: #ccc;
        }

        .semi-muted {
          color: #bbb;
        }

        .semi-muted .bottom-underline {
          border-bottom: 1px solid #bbb;
        }

        .margin-bottom-24 {
          margin-bottom: 28px;
        }

        .margin-top-24 {
          margin-top: 28px;
        }

        .margin-bottom-32 {
          margin-bottom: -32px;
        }

        .margin-bottom-112 {
          margin-bottom: -112px;
        }

        .tabbed {
          margin-left: 35px;
        }

        .bordered-items {
          counter-reset: li;
          list-style: none;
          margin: 0;
          padding-left: 0;
        }

        .bordered-items > li.gray {
          background-color: #eee;
        }

        .bordered-items > li {
          counter-increment: li;
          position: relative;
          padding: 15px 14px 15px 22px;
        }

        .bordered-items > li:last-child {
          border: 0;
        }

        .bordered-items > li:before {
          content: counter(li) ".";
          left: 10px;
          position: absolute;
          top: 15px;
        }

        .bordered-items.list-alpha {
          margin-top: 10px;
          counter-reset: lis;
        }

        .bordered-items.list-alpha > li {
          padding: 10px 0px 10px 24px;
          counter-increment: lis;
        }

        .bordered-items.list-alpha>li:before {
          content: counter(lis, lower-alpha) ".";
          left: 10px;
          position: absolute;
          top: 10px;
        }


        .big-jump-alpha > li {
          counter-increment: start 27;
          list-style-type: none;
        }

        .big-jump-alpha>li:before {
          content: counter(start, lower-alpha) ".";
        }

        .bordered-items.list-alpha.separate > li {
          padding: 10px 0px 10px 24px;
          counter-increment: mycounter 3;
        }
        .bordered-items.list-alpha.separate > li:before {
          content: counter(mycounter, lower-alpha) ".";
          left: 10px;
          position: absolute;
          top: 10px;
        }

        .bordered-items p {
          margin: 0;
          padding: 0;
        }

        .align-center {
          text-align: center;
        }

        header#header1,
        header#header2,
        header#header3 {
          display: block;
          position: running(header);
          margin-bottom: 0px;
          padding-bottom: 0px;
        }

        footer#footer  {
          display: block;
          position: running(footer);
        }

        main#content1,
        main#content2,
        main#content3 {
          display: block;
          margin-top: 0px;
          padding-top: 0px;
          padding: 0;
        }

        #pagenumber:before {
          content: counter(page);
        }

        #pagecount:before {
          content: counter(pages);
        }

        @page {
          @top-center {
            content: element(header)
          }
        }

        @page {
          @bottom-center {
            content: element(footer)
          }
        }

        @page {
          margin: 135px 50px 100px;
          size: A4 portrait;
        }

        @media print {
          .page-break-auto {
            page-break-inside: auto;
          }

          .page-break-avoid {
            page-break-before: avoid;
            page-break-inside: avoid;
          }

          .page-break {
            page-break-after: always;
            page-break-inside: avoid;
            clear:both;
          }

          .page-break-before {
            page-break-before: always;
            page-break-inside: avoid;
            clear:both;
          }
        }
    </style>
</head>

<body>
    <template id="template1" class="page-break">
        <div>
            <header id="header1">
              <div class="header clear-float">
                <div class="logo"></div>
                <div class="loan-account-number align-right">
              <div class="header3">Loan Agreement</div>
              <p class="muted"> Loan Account No.:
                <template th:text="${loanAccountNumber}" />
              </p>
                </div>
              </div>
            </header>
            <footer id="footer">
                <div class="footer clear-float">
                    <div class="export-details v-spacing">
                        <div class="font-light-bold grey-mid">This document is digitally generated <span th:if="${templateVersion != null && templateVersion != ''''}">| Version
                            <template th:text="${templateVersion}" /></span>
                        </div>
                    </div>
                    <div class="page grey-light font-subinfo">Page
                        <span id="pagenumber"></span> of
                        <span id="pagecount"></span>
                    </div>
                </div>
            </footer>
            <main id="content1">
                <section id="loan-agreement page-break-avoid">
                    <p> This Loan Agreement (the “Loan Agreement”) is between
                        <span class="orange">
                            <strong><template th:text="${creditorBusinessName}" /></strong>
                        </span>, a branch office of ING Bank N.V., a company incorporated with limited liability under the laws
                        of the Netherlands, licensed to do business in the Philippines and authorized to operate as a universal
                        bank by the BSP, with principal place of business at 22/F Arthaland Century Pacific Tower, 5th Avenue corner 30th Street, Bonifacio Global City, 1634 Taguig City, Philippines (“ING”), and
                        <span class="orange">
                            <strong>Borrower</strong></span>, of legal age, whose personal details appear below (“You” or the “Borrower”):
                    </p>
                    <table class="with-border">
                        <tr>
                            <th>Name of Borrower</th>
                            <td>
                                <template th:text="${customerName}" />
                            </td>
                        </tr>
                        <tr>
                            <th>Residence</th>
                            <td>
                                <template th:text="${residence}" />
                            </td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td>
                                <template th:text="${customerEmail}" />
                            </td>
                        </tr>
                    </table>
                    <p> Each of ING and Borrower shall be referred to as a “Party,” and collectively, the “Parties.” </p>

                    <p> The Parties agree as follows: </p>
                    <ol class="list-style-inside">
                        <li>
                            <p class="inline">
                                <strong>Entire Agreement.</strong> This document (Loan Agreement) together with Annex 1 (the Standard
                                T&amp;Cs Applicable to Consumer Loans), and Annex 2 (the Disclosure Statement) which are attached
                                and incorporated by reference, shall replace and supersede all prior verbal or written arrangements
                                and representations and consists of the entire agreement between the Parties.</p>
                            <p>The Standard T&amp;Cs Applicable to Consumer Loans refers to the version in effect at the time
                                you agreed to this Loan Agreement, as evidenced by your electronic stamp and saved on your
                                ING Mobile Banking App. Capitalized terms in this Loan Agreement shall refer to the terms
                                as defined in the Standard T&amp;Cs Applicable to Consumer Loans, unless a different definition
                                is provided in this Loan Agreement.</p>

                            <p>In the event of conflict between the Standard T&amp;Cs Applicable to Consumer Loans and the Loan
                                Agreement, the Loan Agreement shall prevail.</p>

                        </li>
                        <li>
                            <p class="inline">
                                <strong>Loan Amount.</strong> The Loan Amount shall be
                                <span class="bottom-underline"><template th:text="${loanAmount}" /></span> Pesos (Php).</p>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Loan Term and Amortization Schedule.</strong> The loan shall be payable within the Loan Term.
                                You agree and understand that the attached Indicative Amortization Schedule is for informational
                                purposes only. Upon our execution of the Loan Agreement and disbursement of the loan proceeds,
                                we will provide an updated Amortization Schedule of due dates and amounts, assuming all Outstanding
                                Sums are paid on time. The updated Amortization Schedule is also for informational purposes
                                only.</p>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Annual Interest Rate.</strong> The Annual Interest Rate shall be
                                <span class="bottom-underline"><template th:text="${contractualInterestRate}" />%</span>.
                            </p>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Effective Interest Rate.</strong> The Effective Interest Rate shall be
                                <span class="bottom-underline"><template th:text="${effectiveInterestRate}" />%</span>.
                            </p>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Other Bank Charges.</strong>
                            </p>
                            <ol class="list-alpha no-margin-left">
                                <li>Documentary Stamp Tax shall be
                                    <span class="bottom-underline"><template th:text="${documentaryStampTax}" /></span>Pesos (Php).</li>
                                <li>Processing Fee shall be
                                    <span class="bottom-underline"><template th:text="${processingFee}" /></span>Pesos (Php).
                                </li>
                            </ol>
                        </li>

                        <li>
                            <p class="inline">
                                <strong>Conditional Charges.</strong>
                            </p>
                            <ol class="list-alpha no-margin-left">
                                <li> <strong>Prepayment Fee</strong> shall be five percent (5%) of the outstanding Principal.</li>
                                <li> <strong>Late Payment Penalty Charge</strong> shall be <template th:text="${latePaymentInterestRate}" />
                                     percent of the Late Principal Applicable per day overdue.
                                </li>
                                <li> <strong >Late Payment Fee</strong>: refers to the cost of collection, attorney’s fees, and other litigation
                                    expenses, which you will pay if your account is referred to a collection service provider
                                    and/or a lawyer.
                                </li>
                            </ol>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Disclosure Statement.</strong> In compliance with the Truth in Lending Act as amended, attached
                                as Annex 2 is the required Disclosure Statement which banks are mandated to provide all persons
                                to whom credit is extended with a copy of prior to the consummation of the loan transaction.</p>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Consent and Waiver of Secrecy of Bank Deposits.</strong> You:</p>
                            <ol class="list-alpha no-margin-left">
                                <li>agree and authorize ING to verify with the Bureau of Internal Revenue and other entities
                                    the tax returns and other financial documents you submitted to them;</li>
                                <li>signify your consent to the waiver of your right of confidentiality to all your bank accounts
                                    under existing bank secrecy laws, including but not limited to, Republic Act No. 1405
                                    or the Law on Secrecy of Bank Deposits, Republic Act No. 6426 or the Foreign Currency
                                    Deposit Act, and Republic Act No. 8791 or the General Banking Law of 2000, as may be
                                    amended in each case; and
                                </li>
                                <li>consent to the processing and updating of all information relative to your bank accounts
                                    under Republic Act No. 10173 or the Data Privacy Act of 2012.
                                </li>
                            </ol>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Authorization for Auto-Debit</strong>. You authorize us to make automatic debits from your
                                ING Pay Account for your Loan repayments.</p>
                            <p>If you currently do not have an ING Pay Account, you will have to open one for this purpose.</p>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Effectivity.</strong> This Loan Agreement shall be deemed effective and dated as of the date/time
                                appearing on ING’s electronic stamp.
                            </p>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Electronic Stamps.</strong> By clicking the acceptance Button, your electronic stamp shall
                                appear on the Loan Agreement (inclusive of the Annexes), signifying that you have read, understood,
                                agreed to, and executed the Loan Agreement, and shall serve as your confirmation that you
                                have been provided with the Disclosure Statement prior to the consummation of the loan/credit
                                transaction. You confirm that once we approve and execute this Loan Agreement, no additional/
                                physical signature shall be required from you or ING for the validity or enforceability of
                                this Loan Agreement in favor of or against you.</p>
                            <p>ING’s approval of the loan and execution of the Loan Agreement shall be signified by its issuance
                                of the Loan Agreement (inclusive of the Annexes), bearing ING’s electronic stamp.</p>
                        </li>
                    </ol>
                    <div class="page-break-avoid">
                    <table>
                        <tr>
                            <td width="50%">
                                <div class="stamp page-break-avoid">
                                    <div class="copy">
                                        <div class="header3">Document electronically signed by <br/>
                                            <template th:text="${customerName}" />
                                        </div>
                                        <p>The issuance of this electronic stamp evidences your signature to and execution of this Loan Agreement, subject to the terms and conditions stated in this document.</p>


                                    </div>
                                    <div class="date">
                                        <template th:text="${customerSignatureDate}" />
                                    </div>
                                </div>
                            </td>
                            <td width="50%" >
                                <div class="stamp bank page-break-avoid" th:if="${bankSignatureDate != null && bankSignatureDate != ''''}">
                                    <div class="copy">
                                        <div class="header3">Document electronically signed by <br/>
                                            <template th:text="${creditorBusinessName}" />
                                        </div>
                                        <p>The issuance of this Loan Agreement and ING’s electronic stamp signifies ING Bank’s
                                            approval of your Loan, which Loan shall be governed by the terms and conditions
                                            stated in this document.</p>
                                    </div>
                                    <div class="date">
                                        <template th:text="${bankSignatureDate}" />
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </table>
                    </div>
                </section>
            </main>
        </div>
    </template>
    <template id="template2">
        <div>
            <header id="header2">
                <div class="header clear-float">
                    <div class="logo"></div>
                    <div class="loan-account-number align-right">
                        <div class="header3">Annex 1</div>
                        <div class="header3">Standard T&amp;Cs Applicable To Consumer Loans</div>
                    </div>
                </div>
            </header>
            <footer id="footer">
                <div class="footer clear-float">
                    <div class="export-details v-spacing">
                        <div class="font-light-bold grey-mid">This document is digitally generated <span th:if="${templateVersion != null && templateVersion != ''''}">| Version
                            <template th:text="${templateVersion}" /></span>
                        </div>
                    </div>
                    <div class="page grey-light font-subinfo">Page
                        <span id="pagenumber"></span> of
                        <span id="pagecount"></span>
                    </div>
                </div>
            </footer>
            <main id="content2">
                <section id="standard-tnc-consumer-loan page-break-avoid">

                    <ol class="list-style-inside">
                        <li>
                            <p class="inline">
                                <strong>Agreement to ING’s Terms and Conditions</strong>
                            </p>
                            <p>Thank you for availing of ING’s services.</p>

                            <p>We want to make sure that you enjoy a safe, worry-free, and convenient banking experience with
                                us. Please take the time to read these Standard T&amp;Cs Applicable to Consumer Loans ("T&amp;Cs")
                                so that you fully understand your rights and obligations, as well as the risks when you avail
                                of an ING Loan (“Loan”).</p>

                            <p>In addition to the terms of the Loan Agreement, you agree that, the following shall be applicable
                                to your ING loan:</p>
                            <ol class="list-alpha no-margin-left">
                                <li> Terms of Use of the ING Mobile Banking App (“Terms of Use”)</li>
                                <li> General T&amp;Cs for all ING Products (“General T&amp;C”)
                                </li>
                            </ol>
                            <p>Both may be viewed at
                              https://ing.com.ph/legal/terms-and-conditions
                            </p>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Definitions</strong>
                            </p>
                            <p>Capitalized terms not defined here shall have the meanings ascribed to them on the Terms of Use
                                and General T&amp;C.
                            </p>
                            <ol class="list-alpha no-margin-left">
                                <li>
                                    <p class="inline">
                                        <strong>Amendment (to the Loan Agreement) or Amendment</strong> refers to a subsequent agreement
                                        entered into by and between you and ING, that modifies, amends, adds or supplements
                                        the original Loan Agreement.
                                    </p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Annual Interest Rate</strong> refers to the simple interest rate used as basis to compute the Interest.
                                    </p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Borrower or you</strong> refers to the person applying for a loan under these terms
                                        and conditions.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Conditional Charges</strong> refer to related fees and charges imposed by ING upon
                                        the happening of certain events such as prepayment or late payment of the Loan Amount
                                        and the Interest.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Cooling-Off Period</strong> refers to the two-banking-day period, after you have
                                        signed the Loan Agreement and an electronic stamp is generated, during which time
                                        you have the option to cancel the Loan Application.
                                    </p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Credit Check</strong> refers to the procedure to be conducted by ING to check your
                                        financial behavior.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Current Interest</strong> refers to the accrued Interest that is due to be paid on
                                        the next Due Date.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Current Principal</strong> refers to the Principal amount that is due to be paid
                                        on the next Due Date.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Disbursement Date</strong> refers to the date when the Loan Amount or portion of
                                        the Loan Amount is disbursed to the ING Pay Account linked to your Loan account.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Disclosure Statement</strong> refers to the disclosures made on Annex 2 of the Loan
                                        Agreement in compliance with the Truth in Lending Act. The Amortization Schedule
                                        in the Disclosure Statement will be updated depending on the Disbursement Date.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Due Date</strong> refers to the dates on which the periodic installment payments
                                        are due.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Late Interest</strong> refers to the accrued Interest that have not been paid on
                                        their Due Dates.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Late Principal</strong> refers to the principal amount that have not been paid on
                                        their Due Dates.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Effective Date</strong> refers to the date at which the Loan Agreement has been executed
                                        by ING</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Effective Interest Rate</strong> refers to a calculation that shows the cost of borrowing
                                        including Processing Fee, Annual Interest Rate, documentary stamp tax, if applicable</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Event of Default</strong> refers to the events mentioned in Clause 3(j).</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Income Verification</strong> refers to the procedure to be conducted by us to check
                                        proof of your income.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Amortization Schedule</strong> refers to the initial amortization schedule, relating
                                        to the monthly loan payments, showing the Principal and Interest due, attached to
                                        the Disclosure Statement annexed to the Loan Agreement. This will be updated based
                                        on the Disbursement Date.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Interest</strong> refers to the interest charged on the Principal payable by you,
                                        computed using the Annual Interest Rate. Interest is computed as: Outstanding principal
                                        balance * Annual Interest Rate * (number of days in cycle / number of days in year).</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Late Payment Penalty Charge</strong> refers to the amount imposed by us on the Principal
                                        amount that remains unpaid multiplied by the number of days the Principal amount
                                        is overdue.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Late Payment Fee</strong> refers to the cost of collection, attorney’s fees, and
                                        other litigation expenses, which you will pay if your account is referred to a collection
                                        service provider and/or a lawyer.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Loan Agreement</strong> refers to the agreement signed by you and us covering the
                                        terms and condition of your loan, including the accompanying annexes.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Loan Amount</strong> refers to the amount approved by us to lend to you as indicated
                                        in the original Loan Agreement.
                                    </p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Loan Application</strong> refers to the procedure which you go through to avail of
                                        the Loan contemplated in these T&amp;Cs.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Loan Maturity</strong> refers to the final payment date of the Loan Amount and the
                                        Interest.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Loan Term</strong> refers to the period beginning from the time the Loan Amount is
                                        released to you, covering the period for the monthly instalments, up to the Loan
                                        Maturity.</p>
                                </li>
                                </ol>
                                <ol class="no-margin-left big-jump-alpha">
                                <li>
                                    <p class="inline">
                                        <strong>Other ING Account/s</strong> refers to other ING account/s that is/are neither a
                                        Loan Account or the designated ING Pay Account for the auto-debiting arrangement.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Outstanding Sums</strong> refer to the amounts due under the Loan Agreement or the
                                        Amendment (to Loan Agreement), if applicable, representing the unpaid balance on
                                        the Principal and Interest due, including Conditional Charges and Taxes if applicable.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Prepayment Fee</strong> refers to the amount to be paid by you should you decide
                                        to prepay your loan prior to the Due Date.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Principal</strong> refers to the original amount borrowed without any Interest or
                                        charges applied.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Processing Fee</strong> refers to the cost incurred by us to process, review and
                                        approve the Loan Application.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Representations and Warranties</strong> refer to all facts you represent as true
                                        in relation to the Loan Application and the Loan Agreement, and your promise to indentify
                                        us if your assertions are false.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Right to Loan Acceleration</strong> refers to the right reserved by ING to require
                                        you to pay all Outstanding Sums.
                                    </p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Right to Set-Off</strong> refers to the right reserved by ING to reduce the Outstanding
                                        Sums, by offsetting against it any amounts deposited in, or held by ING, for your
                                        account.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Taxes</strong> refer to the taxes due and required by law to be paid, as a consequence
                                        of the availment of the Loan, which includes but is not limited to the applicable
                                        documentary stamp tax.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Top-Up</strong> refers to the process of re-availment of additional loans, which
                                        are added to the Loan Amount before its full payment.</p>
                                </li>
                            </ol>

                        </li>
                        <li>
                            <p class="inline">
                                <strong>The Loan Process</strong>
                            </p>
                            <ol class="list-alpha no-margin-left">
                                <li>
                                    <p class="inline">
                                        <strong>Loan Application</strong>
                                        <ol class="list-style-inside no-margin-left">
                                            <li>
                                                <p class="inline">You warrant that all information you provided to us is true, valid and accurate.
                                                    If you fail to submit any information or documentation within fifteen
                                                    (15) days from notice of such requirement, your Loan Application will
                                                    automatically be deemed withdrawn.</p>
                                            </li>
                                            <li>
                                                <p class="inline">You authorize us directly or through our authorized representatives and service
                                                    providers, to take steps we consider necessary to validate the financial
                                                    information you provided. You also authorize third parties in possession
                                                    of such financial information to confirm or disclose the same to us or
                                                    our authorized representatives and service providers.</p>
                                            </li>
                                            <li>
                                                <p class="inline">As part of the process for the Loan Application, we will require certain
                                                    personal data and financial information from you, conduct Know Your Customer
                                                    (“KYC”) procedures, Credit Check and Income Verification.</p>
                                            </li>
                                        </ol>

                                    </p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Assessment and Conditional Approval</strong>
                                        <ol class="list-style-inside no-margin-left">
                                            <li>
                                                <p class="inline">Even if you are eligible, you understand that we have the sole discretion,
                                                    to approve or deny your Loan Application.</p>
                                            </li>
                                            <li>
                                                <p class="inline">If we are satisfied with your eligibility, we may conditionally approve your
                                                    Loan Application and give you the following details:
                                                    <ol class="list-disc no-margin-left">
                                                        <li>Loan Amount</li>
                                                        <li>Loan Term and Amortization Schedule</li>
                                                        <li>Due Date</li>
                                                        <li>Annual Interest Rate</li>
                                                        <li>Effective Interest Rate</li>
                                                        <li>Conditional Charges</li>
                                                    </ol>
                                                </p>
                                            </li>
                                            <li>
                                                <p class="inline">To indicate your consent, you will be required to execute and attach your
                                                    signature stamp on the Loan Agreement. The Loan Agreement becomes binding
                                                    on us only upon [i] your opening of ING Pay Account, [ii] our execution
                                                    of the Loan Agreement, and [iii] the disbursement of the Loan Amount
                                                    to your ING Pay Account. Pending our execution of the Loan Agreement,
                                                    you already agree to abide by its terms. </p>
                                            </li>
                                        </ol>
                                    </p>

                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Disbursement of Loan Amount and Opening of ING Pay Account</strong>
                                        <ol class="list-style-inside no-margin-left">
                                            <li>
                                                <p class="inline">Unless you already have an existing ING Pay Account with us, you agree to
                                                    open an ING Pay Account and accept the terms and conditions of the ING
                                                    Pay Account.</p>
                                            </li>
                                            <li>
                                                <p class="inline">You authorize and instruct us to disburse the Loan Amount to your ING Pay
                                                    Account. We will not disburse the Loan Amount to any other account.</p>
                                            </li>
                                            <li>
                                                <p class="inline">Should you fail to open the ING Pay Account for whatever reason, you agree
                                                    and understand that the conditional approval of the Loan Application
                                                    is deemed rescinded and we are under no obligation to execute the Loan
                                                    Agreement and deliver the Loan Amount.</p>
                                            </li>
                                        </ol>

                                    </p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Final Approval and Disbursement </strong>
                                        <ol class="list-style-inside no-margin-left">
                                            <li>
                                                <p class="inline">You will be notified of the final approval of your Loan Application, and
                                                    the disbursement of the Loan Amount to your ING Pay Account.</p>
                                            </li>
                                            <li>
                                                <p class="inline">You may view and download a copy of the Loan Agreement executed by you and
                                                    us from the Mobile Banking App.</p>
                                            </li>
                                        </ol>

                                    </p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Cooling-Off Period</strong>
                                        <ol class="list-style-inside no-margin-left">
                                            <li>
                                                <p class="inline">You may cancel the Loan Agreement within two (2) banking days after affixing
                                                    your signature stamp on the Loan Agreement via the Mobile Banking App.</p>
                                            </li>
                                            <li>
                                                <p class="inline">In this case, you shall pay the Processing Fee incurred and any accrued Interest.
                                                    You authorize us to debit this amount from your ING Pay Account.</p>
                                            </li>
                                        </ol>

                                    </p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Interest, Charges, and Taxes</strong>
                                        <ol class="list-style-inside no-margin-left">
                                            <li>
                                                <p class="inline">Interest is calculated on a daily basis using the Annual Interest Rate, the
                                                    natural number of days in a month and a year, and the outstanding loan
                                                    balance at the end of the day, until the date when full payment of outstanding
                                                    loan balance is received. This means that Interest continues to be charged
                                                    on all outstanding balance until full payment is received.</p>
                                            </li>
                                            <li>
                                                <p class="inline">The Annual Interest Rate offered and payable by you will be based on your
                                                    personal credit profile and may differ from the published rate and the
                                                    rate offered to other borrowers. You agree and understand that the Effective
                                                    Interest Rate may be higher than the Annual Interest Rate if there are
                                                    additional charges imposed.</p>
                                            </li>
                                            <li>
                                                <p class="inline">Late Payment: If you fail to pay on any Due Date, you will pay the following
                                                    Conditional Charges, without need of demand:
                                                    <ol class="list-disc no-margin-left">
                                                        <li>
                                                            <p class="inline">Late Payment Penalty Charge. If you fail to repay your due amount
                                                                in accordance with the updated Amortization Schedule, an
                                                                additional Late Payment Penalty Charge will apply on the
                                                                unpaid principal that became due. This amount accrues on
                                                                a daily basis until the missed payment is settled.</p>
                                                        </li>
                                                        <li>
                                                            <p class="inline">Late Payment Fee. In addition to the foregoing, you agree that
                                                                if your account is referred to a collection service provider
                                                                and/or a lawyer, you will pay the cost of collection, attorney’s
                                                                fees, and other litigation expenses.</p>
                                                        </li>

                                                    </ol>
                                                </p>
                                            </li>

                                            <li>
                                                <p class="inline"> Prepayment: If you decide to prepay the outstanding balance of your loan
                                                    ahead of the agreed schedule, you must pay the following amounts:
                                                    <ol class="list-disc no-margin-left">
                                                        <li>
                                                            Outstanding Principal
                                                        </li>
                                                        <li>
                                                            Any accrued Interest
                                                        </li>
                                                        <li>
                                                            Prepayment Fee
                                                        </li>
                                                        <li>
                                                            Any other pending fees or charges
                                                        </li>
                                                    </ol>
                                                </p>
                                                <p class="inline">Prepayment is possible through the Mobile Banking App. We will check your
                                                    ING Pay Account if you have suffcient funds to cover the necessary payments.
                                                    If you have suffcient funds and we agree to the pre-termination, we will
                                                    notify you of our approval and the standard Auto-Debiting Arrangement,
                                                    as described below, will apply.</p>
                                            </li>
                                            <li>
                                                <p class="inline">Taxes: The documentary stamp tax on the Loan Agreement (including any amendments
                                                    to it) and other applicable taxes shall be for your account and shall
                                                    be charged against you.</p>
                                            </li>
                                            <li>
                                                <p class="inline">We reserve the right to modify the interest rates and other charges indicated
                                                    in these T&amp;Cs subject to a thirty (30) day notice through electronic
                                                    communication, which shall be effective on the date indicated in the notice.
                                                    If you do not agree to the changes, you may prepay the Outstanding Sums
                                                    within the said 30-day period without paying the Prepayment Fee.</p>
                                            </li>

                                        </ol>

                                    </p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Payment</strong>
                                        <ol class="list-style-inside">
                                            <li>
                                                <p class="inline">On the due date in accordance with these T&amp;Cs and the Loan Agreement,
                                                    without need of demand, you must repay the following: (1) fees and commissions
                                                    due to us and /or third parties (2) Conditional Charges (3) Late Interest
                                                    (4) Late Principal (5) Current Interest and (6) Current Principal.
                                                </p>
                                            </li>
                                            <li>
                                                <p class="inline">You waive your right to make application of payment under Article 1252 of
                                                    the Civil Code, and we shall have the right to apply payments made by
                                                    you to any of your obligations to us, regardless of the source and nature
                                                    of the obligations.</p>
                                            </li>
                                            <li>
                                                <p class="inline">A computation of the Outstanding Sums and their Due Dates may be viewed on
                                                    your dashboard in the Mobile Banking App. These details may be corrected
                                                    if any computational or technical errors are discovered.</p>
                                            </li>
                                            <li>
                                                <p class="inline">
                                                    The outstanding balance shall be due and payable within the Loan Term in the number of monthly installments stated in the
                                                    Amortization Schedule viewable in the Mobile Banking App. Each installment
                                                    repayment shall be due on the day of the month stated in the Amortization
                                                    Schedule, provided, that the first repayment date shall be more than
                                                    ten (10) days after the Disbursement Date and shall occur in the month
                                                    (in the following order of precedence):
                                                    <ol class="list-alpha no-margin-left">
                                                        <li>
                                                            <p class="inline">of Disbursement Date; or</p>
                                                        </li>
                                                        <li>
                                                            <p class="inline">subsequent to the month of Disbursement Date (“Month 2”); or</p>
                                                        </li>
                                                        <li>
                                                            <p class="inline">subsequent to Month 2.</p>
                                                        </li>
                                                    </ol>
                                                </p>
                                            </li>

                                        </ol>
                                    </p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Auto-Debiting Arrangement</strong>
                                    </p>
                                    <ol class="list-style-inside no-margin-left">
                                        <li> Loan repayment shall be carried out via an auto-debit arrangement using your designated
                                            ING Pay Account.</li>
                                        <li> Without need of prior demand or notice, you expressly allow us to automatically deduct
                                            the Outstanding Sums from your designated ING Pay Account when these amounts
                                            become due.
                                        </li>
                                        <li>You shall be responsible for maintaining adequate funds in your ING Pay Account to
                                            cover the Outstanding Sums as they become due.</li>
                                        <li>If the balance in your ING Pay Account is insufficient, at any time, to cover the
                                            Outstanding Sums at the time of deduction, you authorize us to debit any and/or
                                            all of your Other ING Accounts to pay for the Outstanding Sums.</li>
                                        <li>You shall not close the ING Pay Account until the Loan is fully paid.</li>
                                        <li>You acknowledge that authority granted under the Auto-Debit Arrangement is coupled
                                            with an interest and may be revoked only with our written and express consent.</li>
                                    </ol>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Top-up</strong>
                                    </p>
                                    <ol class="list-style-inside no-margin-left">
                                        <li> Subject to our approval, you may choose to Top-Up the existing Loan Amount even before
                                            it is fully paid. If you choose to do so, the Top-Up amount will be added to
                                            the balance of the existing Loan Amount.</li>
                                        <li> You may be eligible for Top-Up if you meet the requirements in ING’s feasibility
                                            check.
                                        </li>
                                        <li>Top-Up may be done through the Mobile Banking App. The relevant provisions relating
                                            to the Loan Application process shall be applicable to the Top-Up application
                                            process.</li>
                                        <li>If your application for Top-Up is approved, you must execute an Amendment to the
                                            Loan Agreement, which shall supersede the applicable terms of the existing Loan
                                            Agreement.</li>
                                        <li>You agree and understand that the Amendment to the Loan Agreement becomes binding
                                            on us only upon our execution of the same and the disbursement of the Top-Up
                                            proceeds to your ING Pay Account.</li>
                                        <li>The documentary stamp taxes and all other relevant taxes and charges, if any, shall
                                            be for your account.
                                        </li>
                                    </ol>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Default</strong>
                                    </p>
                                    <ol class="list-style-inside no-margin-left">
                                        <li>
                                            <p class="inline">We can terminate the Loan Agreement and the Amendment, if any, and demand immediate
                                                payment of all Outstanding Sums when any of the following events occur (“Event
                                                of Default”):
                                                <ol class="list-disc no-margin-left">
                                                    <li>You breach, default, or otherwise fail to promptly perform any of your
                                                        obligations or covenants under these T&amp;Cs and the Loan Agreement;</li>
                                                    <li>Any of your Representations and Warranties, or information, including
                                                        the purpose stated in your Loan Application is untrue or shall become
                                                        or shall prove to have been false when so made; and</li>
                                                    <li>At any time that: (1) the prospect of payment of the amounts due under
                                                        the Loan Agreement is impaired as shown by a default with respect
                                                        to your other obligations to us under any other credit accommodation;
                                                        (2) you made a sale or disposition of any substantial portion of
                                                        your assets or property; (3) a default in any of your obligations
                                                        to a third party; or (4) such other circumstances and conditions
                                                        have occurred which materially and adversely affect your financial
                                                        standing or the ability to perform your obligations under the Loan
                                                        Agreement.</li>
                                                </ol>
                                            </p>
                                        </li>
                                        <li>
                                            <p class="inline">If an Event of Default shall occur and be continuing, such Event of Default shall
                                                have the following effects, which shall be alternative, concurrent, and cumulative
                                                remedies to the Event of Default:
                                                <ol class="list-disc no-margin-left">
                                                    <li>You shall be liable for the penalties as stated in these T&amp;Cs, and
                                                        the Loan Agreement;
                                                    </li>
                                                    <li>We may refer your loan account to a law firm or collection agent, and
                                                        you shall be liable to ING for any and all attorney’s fees, collection
                                                        fees, and litigation costs we incurred or to be incurred in collecting
                                                        the Outstanding Sums;</li>
                                                    <li>We shall have the Right to Set-off, which means that we have the right
                                                        to immediately and without notice set off any liability or debt that
                                                        you owe us against any liability or debt that we owe to you. The
                                                        Right to Set-off means that we have the right to deduct from your
                                                        Other ING Account(s) any amounts that you owe to us pursuant to the
                                                        Loan Agreement. Prior to exercising the Right to Set-off, ING may
                                                        earmark a portion of your funds in your Other ING Account(s) to cover
                                                        your outstanding obligations. When a portion of your funds in your
                                                        Other ING Account(s) has been earmarked, you will not be able to
                                                        make withdrawals, purchases, or fund transfers that will reduce the
                                                        balance of your Other ING Account(s) below the earmarked amount.
                                                        However, fund transfers to your ING Pay Account shall be allowed,
                                                        and we shall debit your ING Pay Account pursuant to your Auto-Debit
                                                        Authorization in our favor.</li>
                                                    <li>
                                                        We have the Right to Loan Acceleration, and as such, we may declare that the entire balance of unpaid Loan Amount is due
                                                        immediately together with the accrued Interest, without need for
                                                        any demand, or notice of any kind, all of which you expressly waive.</li>
                                                    <li>ING shall have the right to exercise, alternatively concurrently and
                                                        cumulatively, all other rights and remedies now or from now on available
                                                        to it under these T&amp;Cs, and under applicable Laws.</li>
                                                </ol>
                                            </p>
                                        </li>
                                    </ol>
                                </li>
                            </ol>

                        </li>


                        <li>
                            <p class="inline">
                                <strong>Obligation to Notify</strong>
                            </p>
                            <p>You shall notify us within twenty-four (24) hours if you (i) file for bankruptcy or insolvency,
                                (ii) appoint or suffer appointment of a receiver or trustee over all or substantially all
                                of your property, or (iii) propose or is a party to any dissolution or liquidation.</p>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Right to Outsource Debt Collection</strong>
                            </p>
                            <p>You acknowledge and agree that we have the right to appoint and authorize an agent to collect
                                all and any Outstanding Sums due to us. We will inform you of the endorsement of the collection
                                of your Outstanding Sums to a collection agency/agent, or the endorsement of the account
                                from one collection agency/agent to another, at least seven (7) days before the actual endorsement.
                                We shall ensure that personnel handling the collection of your account will disclose his/her
                                full name to you.</p>
                            <p>You also acknowledge and agree that we may secure alternate phone numbers alternate contact details
                                from our collection agents (including but not limited to credit bureaus or law firms we may
                                engage) if we receive no response from you using the contact details you have provided us.</p>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Credit Information</strong>
                            </p>
                            <p>By availing of a loan with us, you authorize us to regularly submit and disclose your information,
                                whether positive or negative, relating to your basic credit data (as defined under Republic
                                Act No. 9510) with us, as well as any updates or corrections to such information, to the
                                Credit Information Corporation, TransUnion, other credit bureaus, and accredited credit information
                                management service providers with whom ING has or may have a relationship. You agree that
                                this Loan Agreement constitutes your written consent for such submission and disclosure of
                                information relating to your Loan Application for the mentioned purpose and under applicable
                                laws, rules and regulations.</p>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Representation and Warranties</strong>
                            </p>
                            <p>You represent and warrant to us the following:
                                <ol class="list-alpha no-margin-left">
                                    <li>You represent and warrant that you freely and voluntarily availed of the loan and agree
                                        to the Loan Agreement. You agree that a demand from us shall not be necessary for
                                        you to be considered in delay in the performance of any of your obligations under
                                        the Loan Agreement. You will be deemed in default when you breach, default, or otherwise
                                        fail to promptly perform any of your obligations or covenants under the Loan Agreement
                                        and under these T&amp;Cs.</li>
                                    <li>The purpose of the loan is for personal use only. You must not use the Loan Amount for
                                        business, investment, or speculative purposes, as a bridging loan or a mortgage deposit
                                        or to purchase or retain an interest in land.</li>
                                    <li>You freely and voluntarily submitted the Loan Application and agree to these T&amp;Cs
                                        and the provisions of the Loan Agreement.</li>
                                    <li>All of your loans and obligations with other lenders are updated and not delinquent or
                                        past due.</li>
                                    <li>All the information and documents you provided to us are accurate, current, authentic,
                                        complete and updated as of the date of the Loan Application and may be relied upon
                                        by us. Unless we receive any notice of any change, we will continue to rely on such
                                        information.</li>
                                    <li>You will notify us immediately of any changes to your personal information, including
                                        changes to your address, email address and contact details, by updating your information
                                        and profile in the Mobile Banking App.</li>
                                    <li>These T&amp;Cs shall be valid and binding upon you and enforceable in accordance with
                                        them.</li>
                                    <li>At any time during the Loan Term, we may request you to send us your latest income tax
                                        return and/ or other related financial documents. You undertake to provide all requested
                                        documents within fifteen (15) days from request.</li>
                                    <li>These Representations and Warranties are made as of the Effective Date as stated in the
                                        Disclosure Statement and are deemed repeated on each day that any amounts are outstanding.
                                        </li>
                                </ol>

                            </p>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Data Privacy</strong>
                            </p>
                            <p>In addition to the processing details discussed in our
                                <span class="orange">
                                    <strong>
                                      Data Privacy Statement</strong></span>, we collect the following information about you:</p>
                            <ol class="list-disc no-margin-left">
                                <li> Your name, gender, date of birth, place of birth, nationality, residence, mailing address,
                                    email address, phone number;</li>
                                <li> Your socio-economic information, such as employment status, occupation and designation, tenure
                                    (at current work and in total), industry and company name, company address and phone
                                    number, work email address, home ownership status, civil status, information about dependents,
                                    tax identification number, and
                                </li>
                                <li> Your financial information, such as income tax return, bank statements, source of income,
                                    amount of income and expenses, and financial information obtained from credit bureaus.
                                </li>
                            </ol>
                            <p>We also process your information for purposes other than those in our
                                <span class="orange"><strong>
                                  Data Privacy Statement</strong></span>, as follows:</p>
                            <ol class="list-disc no-margin-left">
                                <li> onboarding and loan availment and related ING products and services including the necessary
                                    procedures for KYC, Credit Check, and Income Verification and tax return verification
                                    with other banks and the Bureau of Internal Revenue. We make use of an automated system
                                    that processes the information and documents you submitted in determining whether or
                                    not to grant the loan. You acknowledge and agree to this automated decision-making.</li>
                                <li> using financial information and documents submitted to us for research and machine learning
                                    to be able to increase the capacity of our systems to detect and deter fraud;
                                </li>
                                <li> respond to queries, requests, and complaints and improve how we interact with you in relation
                                    to your loan availment and payment;
                                </li>
                                <li>send you statements, billings, notices, and other such documents necessary for the loan availment
                                    and payment;</li>
                                <li>collection and enforcement of our rights under the Loan Agreement;</li>
                                <li>mobile attribution tracking and direct marketing, including sending personalized notifications
                                    and content pertaining to the terms of the Loan Agreement; and</li>
                                <li>perform such other activities permitted by law or with your consent.</li>
                            </ol>
                            <p>We may disclose or obtain your personal information to and from third parties such as the Banker’s
                                Association of the Philippines, Credit Information Corporation, credit bureaus, other financial
                                institutions, consumer reporting or reference agencies, credit protection providers or guarantee
                                institutions, brokers, insurers, underwriters, and ING-accredited credit information management
                                service providers to be able to perform credit checks and see your credit scores, and enable
                                us to collect on the Loan and enforce our rights under the Loan Agreement.</p>
                            <p>We may also refer and disclose the details in the Loan Agreement to third parties, such as a
                                law firm or a collection agent, to assist us in collecting and enforcing our rights under
                                the Loan Agreement.</p>
                            <p>We may also disclose your relevant personal information to other service providers engaged by
                                us or a member of the ING Group, as well as marketing, promotional, network, loyalty program
                                and joint venture partners and other relevant external parties. We will exert reasonable
                                efforts to ensure that our service providers comply with our Privacy Policy in handling your
                                personal data and shall disclose only such personal information that is relevant to the service
                                being provided.</p>
                            <p>We may also disclose your personal information to any potential transferee or assignee of our
                                rights and/or obligations pursuant to a potential merger &amp; acquisition, creation of a
                                special purpose vehicle, or similar corporate restructuring.
                            </p>
                            <p>We are only allowed to keep your personal data for as long as it is still necessary for the purpose(s)
                                declared to you. Generally, ING will delete your personal data ten (10) years after your
                                obligations under the Loan Agreement has been completely closed and settled, unless such
                                personal data is necessary for an ongoing audit, investigation, litigation, or any other
                                legal proceedings. For those whose Loan Applications were rejected or cancelled, we will
                                delete your personal data, twelve (12) months from the date of the Loan Application.</p>
                        </li>
                        <li>
                            <p class="inline">
                                <strong>Miscellaneous</strong>
                                <br/>
                            </p>
                            <ol class="list-alpha no-margin-left padding-left-34">
                                <li>
                                    <p class="inline">
                                        <strong>Notices and Communication</strong>
                                        <br/>You agree that all notices and communications may be sent by (i) push notification/SMS/in-app
                                        notification, (ii) electronic mail, (iii) personal delivery, (iv) courier service,
                                        or (v) registered mail to the address you provided us.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Indemnification</strong>
                                        <br />You agree to indemnify and hold us and our agents, officers and representatives free
                                        and harmless from and against any and all claims, suits, actions, or demands for
                                        losses, damages, costs and expenses, including, without limiting the generality of
                                        those just mentioned, attorney’s fees and costs of suit that we may face, suffer,
                                        or incur by reason or in respect of your breach of the Loan Agreement and its Annexes,
                                        including any of the provisions, warranties and obligations set forth in these T&amp;Cs,
                                        and any and other related laws and/or government regulations, by reasons other than
                                        force majeure, acts of God, including natural disasters and calamities, acts of governments,
                                        industrial actions, rebellions, wars, and all other unforeseen or foreseen but inevitable
                                        events.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Limitation of Liability</strong>
                                        <br />We shall not be liable whether in contract, warranty, tort, or otherwise for any
                                        indirect, incidental, consequential, special, exemplary, punitive, or similar damages,
                                        including, without limitation, damages for lost revenue, profit, or business arising
                                        out of or relating to the loan agreement. Our total liability, if any arising out
                                        of or relating to the Loan Agreement shall not exceed the total amount of the Loan.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Compliance with Laws and Regulations</strong>
                                        <br />It is your responsibility to ensure that your availment of the Loan and all related
                                        transactions made are allowed and permissible under the laws. Accordingly, you acknowledge
                                        and agree to comply with all laws.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Governing Law and Venue</strong>
                                        <br />You acknowledge that these T&amp;Cs shall be governed by and construed in accordance
                                        with the laws of the Republic of the Philippines and by ING’s charter documents,
                                        regulations and practices which shall be brought to your attention by publication,
                                        display, advertisement, or other electronic transmission means of delivery.</p>
                                    <p>We shall endeavor our best to address your concerns. However, should any dispute arising
                                        from or relating to the Loan (the availment, approval, or payment of the Loan), these
                                        terms and conditions be brought to court, you agree to submit to the exclusive jurisdiction
                                        of Taguig City courts.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Separability Clause</strong>
                                        <br />In the event any provision contained in these T&amp;Cs or in the Loan Agreement shall
                                        be declared void or invalid, such declaration shall not affect the validity of the
                                        other provisions.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Non-Waiver and Waiver</strong>
                                        <br />These T&amp;Cs have given both parties certain rights and powers, as well as certain
                                        obligations.</p>
                                    <p>Our failure to exercise any rights or powers shall not operate as a waiver of that right
                                        or power. Any partial or single exercise of any rights or powers shall not preclude
                                        the exercise of any other rights or powers provided here.
                                    </p>
                                    <p>Any waiver provided by ING shall be expressed in writing and signed by our duly authorized
                                        representative.</p>
                                    <p>You agree that ING may, without prior notice, assign part or all of its rights or obligations
                                        here or under any Loan transaction. In the event of such assignment, you irrevocably
                                        agree not to assert against the assignee set-off rights of any obligations that we
                                        may owe to you.</p>
                                    <p>You may not assign your rights and obligations under the Loan Agreement and these T&amp;Cs
                                        without ING’s prior written consent.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Amendments</strong>
                                        <br />To ensure that these T&amp;Cs are consistent with the services and operations of
                                        ING, you understand that we may revise the same from time to time. ING shall inform
                                        you of changes, to the extent feasible and necessary, through notices sent through
                                        the Mobile Banking App, email, text or SMS, ordinary mail, and in accordance with
                                        the notice requirements of applicable laws. You shall be deemed to have agreed to
                                        such changes when you continue to avail of the services of ING.</p>
                                    <p>Pursuant to the applicable regulations of the BSP, you shall be notified sixty (60) days
                                        prior to the implementation of any amendments to these T&amp;Cs by public notice.
                                        Individual notices through the means mentioned in the immediately preceding paragraph
                                        shall be sent if the amendments pertain to or will result in fees that are to be
                                        paid or charged on your account.</p>
                                    <p>If you disagree with the amendments to these T&amp;Cs, you shall have the right to terminate
                                        your agreement with ING pursuant to these T&amp;Cs without penalty, provided that
                                        notice is given to ING within thirty (30) days from issuance of the public notice,
                                        or, in cases where individual notices are required, from receipt of the individual
                                        notice.</p>
                                </li>
                                <li>
                                    <p class="inline">
                                        <strong>Customer Service</strong>
                                        <br />For inquiries, complaints, and other matters, you may contact us through the Mobile
                                        Banking App.</p>
                                    <p>We shall act on the request/ inquiry/ complaint to reach its prompt resolution and inform
                                        you of our findings. You agree to fully cooperate with any such inquiry and/ or investigation
                                        by providing necessary data and documents.
                                    </p>
                                </li>
                            </ol>
                        </li>
                    </ol>

                    <div class="page-break-avoid">
                    <table>
                      <tr>
                        <td width="50%">
                          <div class="stamp page-break-avoid">
                            <div class="copy">
                              <div class="header3">Document electronically signed by <br/>
                                <template th:text="${customerName}" />
                              </div>
                              <p> The issuance of this electronic stamp evidences your signature to and execution of this Loan Agreement, subject to the terms and conditions stated in this document.</p>
                            </div>
                            <div class="date">
                              <template th:text="${customerSignatureDate}" />
                            </div>
                          </div>
                        </td>
                        <td width="50%">
                          <div class="stamp bank page-break-avoid" th:if="${bankSignatureDate != null && bankSignatureDate != ''''}">
                            <div class="copy">
                              <div class="header3">Document electronically signed by <br/>
                                <template th:text="${creditorBusinessName}" />
                              </div>
                              <p> The issuance of this Loan Agreement and ING’s electronic stamp signifies ING Bank’s approval of your Loan, which Loan shall be governed by the terms and conditions stated in this document.</p>
                            </div>
                            <div class="date">
                              <template th:text="${bankSignatureDate}" />
                            </div>
                          </div>
                        </td>
                      </tr>

                    </table>
                    </div>
                </section>

            </main>
        </div>
    </template>
    <template id="template3" class="page-break-before">
            <header id="header3">
                <div class="header clear-float">
                    <div class="logo" style="margin-top: 20px;"></div>
                    <div class="loan-account-number align-right">
                        <div class="header3">Annex 2</div>
                        <div class="header3">Disclosure Statement
                        </div>
                        <p class="muted">(As Required Under R.A. No. 3765, Truth in Lending Act)
                        </p>
                    </div>
                </div>
            </header>
            <footer id="footer">
                <div class="footer clear-float">
                    <div class="export-details v-spacing">
                        <div class="font-light-bold grey-mid">This document is digitally generated <span th:if="${templateVersion != null && templateVersion != ''''}">| Version
                            <template th:text="${templateVersion}" /></span>
                        </div>
                    </div>
                    <div class="page grey-light font-subinfo">Page
                        <span id="pagenumber"></span> of
                        <span id="pagecount"></span>
                    </div>
                </div>
            </footer>
            <main id="content3">
                <section id="disclosure-statement" class="annex">
                    <header style="margin-top: 200px">
                        <div class="header3">Disclosure Statement</div>
                    </header>
                    <ol class="bordered-items page-break-after">
                        <li class="gray orange-border-top">
                            <div class="amount-container clear-fix">
                                <label>
                                    <strong>LOAN AMOUNT</strong> (amount to be disbursed)</label>
                                <span class="amount">PHP
                                    <u><template th:text="${loanAmount}" /></u>
                                </span>
                            </div>
                        </li>
                        <li>
                            <div class="amount-container clear-fix">
                                <label>
                                    <strong>OTHER BANK CHARGES COLLECTED</strong> (to be debited post disbursement)</label>
                            </div>
                            <ol class="bordered-items page-break-auto list-alpha">
                                <li>
                                    <div class="amount-container clear-fix">
                                        <label>Documentary Stamp Tax</label>
                                        <span class="amount">PHP
                                            <u><template th:text="${documentaryStampTax}" /></u>
                                        </span>
                                    </div>
                                </li>
                                <li>
                                    <div class="amount-container clear-fix">
                                        <label>Processing Fee</label>
                                        <span class="amount">PHP
                                            <u><template th:text="${processingFee}" /></u>
                                        </span>
                                    </div>
                                </li>
                            </ol>
                        </li>
                        <li class="gray">
                            <div class="amount-container clear-fix">
                                <label>
                                    <strong>Net Proceeds of Credit Transaction</strong> (Item 1 less Item 2)</label>
                                <span class="amount">PHP
                                    <u><template th:text="${netProceedsOfLoan}" /></u>
                                </span>
                            </div>
                        </li>
                        <li>
                            <div>
                                <label>
                                    <strong>Schedule of Payments</strong>
                                </label>
                            </div>
                             <ol class="bordered-items page-break-auto list-alpha separate" start="3">
                                <li>
                                    <div class="amount-container clear-fix">
                                        <label>Installment Payment (see attached Amortization Schedule)</label>
                                    </div>
                                </li>
                            </ol>
                        </li>
                        <li class="gray">
                          <div class="amount-container-two clear-fix"><label> <strong>Effective Interest Rate</strong> (Interest and Other
                          Charges)</label><span class="amount"><u><template th:text="${effectiveInterestRate}" /></u>%</span></div>
                          <div class="dark-gray">Explanation: The effective interest rate may be higher than the CONTRACTUAL INTEREST RATE of <span class="amount"><template th:text="${contractualInterestRate}" />%</span> because of charges listed in item 2 above.
                          </div>
                        </li>
                        <li>
                            <div class="clear-fix">
                                <label><strong>Conditional Charges that May be Imposed</strong> (if applicable).</label>
                                <div>Please specify manner of imposition:</div>
                            </div>
                            <table class="no-background">
                                <thead class="not-centered">
                                    <tr>
                                        <th>
                                            <strong>Description</strong>
                                        </th>
                                        <th>
                                            <strong>Formula/Percentage/Amount (in PHP)</strong>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="dark-gray">
                                    <tr>
                                        <td>Prepayment Processing Fee</td>
                                        <td>5% on the outstanding principal</td>
                                    </tr>
                                    <tr>
                                        <td>Late Payment Penalty Charge</td>
                                        <td><template th:text="${latePaymentInterestRate}" />% on the late principal</td>
                                    </tr>
                                </tbody>
                            </table>
                        </li>
                    </ol>
                    <br/><br/><br/>
                    <div class="annex page-break-after">
                        <div class="header3">Amortization Schedule <span>(For Informational Purposes Only)</span></div>

                      <p class="semi-muted">Disbursement date: <template th:text="${disbursementDate}" />
                        </p>

                        <table
                            class="align-center orange-border-top amort-sched-table"
                            th:classappend="${#arrays.length(amortizationSchedule) == 18}? margin-bottom-112 : margin-bottom-32"
                        >
                            <tr>
                              <th>Installment</th>
                              <th>Repayment Date</th>
                              <th>Loan</th>
                              <th> Principal</th>
                              <th>Interest</th>
                              <th>Total</th>
                              <th>O/S Balance</th>
                            </tr>
                            <tr>
                              <th>A</th>
                              <th></th>
                              <th>B</th>
                              <th>C</th>
                              <th>D</th>
                              <th>E</th>
                              <th>F</th>
                            </tr>
                            <tr>
                              <td></td>
                              <td></td>
                              <td>
                                <template th:text="${loanAmount}" />
                              </td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td><template th:text="${loanAmount}" /></td>
                            </tr>
                            <tr th:each="sched: ${amortizationSchedule}">
                              <td>
                                <template th:text="${schedStat.index + 1}" />
                              </td>
                              <td>
                                <template th:text="${sched.paymentDate}" />
                              </td>
                              <td></td>
                              <td>
                                <template th:text="${sched.principalMonthlyBreakdown}" />
                              </td>
                              <td>
                                <template th:text="${sched.interestMonthlyBreakdown}" />
                              </td>
                              <td>
                                <template th:text="${sched.monthlyPayment}" />
                              </td>
                              <td>
                                <template th:text="${sched.principalBalance}" />
                              </td>
                            </tr>
                            <tr>
                              <td></td>
                              <td></td>
                              <td><strong>Total</strong></td>
                              <td>
                                <strong><template th:text="${totalPrincipalMonthly}" /></strong>
                              </td>
                              <td>
                                <strong><template th:text="${totalInterestMonthly}" /></strong>
                              </td>
                              <td>
                                <strong><template th:text="${totalPaymentMonthly}" /></strong>
                              </td>
                              <td></td>
                            </tr>
                            <!-- Additional row/s below to avoid 23 and 24 total rows to avoid placing table to the next page -->
                            <tr
                                th:each="b: ${#arrays.length(amortizationSchedule) == 19
                                  ? #numbers.sequence( 0, 1/1)
                                  : #arrays.length(amortizationSchedule) == 18
                                    ? #numbers.sequence( 0, 2/1)
                                    : #numbers.sequence( 1, 1/1)}"
                                class="visibility-hidden"
                            >
                              <td>Hidden</td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                            </tr>
                        </table>

                        <fieldset class="legends">
                            <legend>Legend</legend>
                            <div><strong>A</strong> - Number of installment periods based on loan term</div>
                            <div><strong>B</strong> - Loan Amount</div>
                            <div><strong>C</strong> - Installment payment on the principal</div>
                            <div><strong>D</strong> - Installment payment on the interest</div>
                            <div><strong>E</strong> - Total amortization payment for the installment period</div>
                            <div><strong>F</strong> - Outstanding principal balance of the loan</div>
                        </fieldset>

                        <p>The amounts due that are indicated above are only informational. The figures may vary depending on
                            the Disbursement Date and the computed Interest.</p>

                        <p>
                            <strong>I CONSENT/CONFIRM THE CONTENTS OF THE STATEMENT AND I ACKNOWLEDGE RECEIPT OF A COPY OF THIS STATEMENT
                                PRIOR TO THE CONSUMMATION OF THE CREDIT TRANSACTION</strong>
                        </p>
                         <div class="page-break-avoid">
                          <table >
                            <tr>
                              <td width="50%">
                                <div class="stamp page-break-avoid">
                                  <div class="copy">
                                    <div class="header3">Document electronically signed by <br/>
                                      <template th:text="${customerName}" />
                                    </div>
                                    <p>The issuance of this electronic stamp evidences your signature to and execution of this Loan Agreement, subject to the terms and conditions stated in this document.</p>
                                  </div>
                                  <div class="date">
                                    <template th:text="${customerSignatureDate}" />
                                  </div>
                                </div>
                              </td>
                              <td width="50%">
                                <div class="stamp bank page-break-avoid" th:if="${bankSignatureDate != null && bankSignatureDate != ''''}">
                                  <div class="copy">
                                    <div class="header3">Document electronically signed by <br/>
                                      <template th:text="${creditorBusinessName}" />
                                    </div>
                                    <p>The issuance of this Loan Agreement and ING’s electronic stamp signifies ING Bank’s
                                              approval of your Loan, which Loan shall be governed by the terms and conditions
                                              stated in this document.</p>
                                  </div>
                                  <div class="date">
                                    <template th:text="${bankSignatureDate}" />
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </table>
                        </div>
                    </div>
                </section>
            </main>
    </template>
</body>

</html>', 'Loan Contract 1.0', '0.1');


INSERT INTO [rtb].[TEMPLATE](template_id, LOCATION_CODE, type, VERSION, CREATED_DATETIME, CREATED_BY, TEMPLATE)
	VALUES(NEWID(), 'PH', 2, '1.0.0', GETUTCDATE(), SUSER_NAME(),
	'<?xml version="1.0" encoding="utf-8"?>
     <!DOCTYPE html SYSTEM "http://www.thymeleaf.org/dtd/xhtml1-strict-thymeleaf-spring3-4.dtd">

     <html xmlns="http://www.w3.org/1999/xhtml" xmlns:th="http://www.thymeleaf.org">
     <head>
        <style type="text/css" media="print">
            body, template, header, footer, main, section { padding: 0; margin: 0; position: relative; }

            .sign-glen { height: 32px; background-size: auto 32px; background-repeat: no-repeat; background-image: url("data:image/jpg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wgARCADnA7wDASIAAhEBAxEB/8QAGgABAAMBAQEAAAAAAAAAAAAAAAQFBgMCAf/EABQBAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhADEAAAAr8AAAAAAAABy8ncAAAAAAAAAAAAAAAAAAAAAAAAAAAqSfxyFwaQAAAAAAAAAAAAAAAAAAAAAAAAAAAAHzO+bIrumggEO7o7wAAAAAAAAAAAAAAAAAAAAAAAAAEQj5TrdEHV/foAAAAAAAAAAAAAAAAAAAAAAAAAAAAhTcuddHw7jMXdcXXt4HnIWBpAAAD4ROWYuDQAAAAAAAAAAAAAAAAAprmjrjWw8/KOdTrKMurIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGQ1+PNg81RV6et5llmWhMhtcjtQAABVWuWIG0pb4AAAAAAAAAAAAAAAAAAHMzlvQ64AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVNt8MhEs7ozV1cfTzDnU5A09HeAAAHzC6+mNB1AAAAAAAAAAAAAAAAAABTXORLW559AAAAAAAAAAAVhZqq1AAAAAAAAAAAAAAAAAAGekCVPABSXdOfLmptgAAfCglZ7VE0ABAojWPn0AAAAAAAAAAAAAAPnw452XOLEADxX5o1c3GTjSgAOOVNV2wf03atsgACPmu10Z7W5nsaEABzqD3Z43VkwADOyaEk6iv5l0q6o0lJGuzObHn0AAAAAAFZ1rj7fOB3cuoApbqhJNrAngACosswQddVWBYgV1jkT3Hkzy59APJ4xveAbvpitCWgBGJLFezZKW6AAAAAAAKWr+yiFr83pQczpno9ed9ZEsTji7OsNhKjyBy8Zk4+e1+cc7MmnW7qLcAefUMzGzz+gM5Jsux6PJ6gVXwrvHaURNpldUCGTKav7lV7s7IzPW78C06AAAAAAABw6Zo6aTx7FXaDGXFjli4jWEwzlfuckaWUAApSBeVWiKVY5o1zzVFlkPWgKzS5C3Lh8gE/Lc7sq+UXWHbIbPPl31qLUZDtWHbT+5xj9hjNkfUatLsAAAADj28GY8RLshetRHKWBpZZWw7/yVsaP3OX3Q/CmeexTaaT9MfIueJw5aHMllwq5hZWNHeCDO+FHe5K3LZV1ReZ/voCD7sfBkOllblJG1IyXfTCDODK6agiEi3qdKAAAAAAAPn3OnK/4zgABw7jMaXhnzSZr1almABmtKPHsFTbDG2l8PPoPNLeDLSdAOHOWMvqAcO4xXrY/TLfLKWTgZmTcUhW3U2WAAAAAARpH0AAAAAAACjPlHoKw1FdaivsAA8VduKW16gAAAAAD5wkAAAAAAAAVZH6xtAAAAAOXUVdoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEOi8ac6ZHSU5owAAAAAAAAAAAAAAAAACCeaX7qD6AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABHkVxV6WnuCl6wL07gAAAAAAAAAAAAAAAAEUZzzqz39AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCm+Smu8tpDM6vKasAAAAAAAAAAAAAAAAEUZvxqj11AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACtzu05lbbAAAAAAAAAAAAAAAAByyOs5n2UAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH//aAAwDAQACAAMAAAAh88888888848888888888888888888888888884I88888888888888888888888888888ooc888888888888888888888888848c88888888888888888888888888888c0408884c88888888888888888U80888888888888888888888888888888o8wws8888U8888888888888888888g888888888888888888888888888888sME8U888Q8888888888888888888sU888888888888888888888888888888k88o0884s8800888888888888888Y88kY08w4888II88wk88k04sc888888s4084c88ko8ok84U884088888888Qc8ccA8kI4c880I84Is8wsE88888888ocsMEc0848g4MUwQ040408w888888sog4QYUkwos84U00cQ8McI888888884U88sIs8888ssc88M88ow8E8888888M88888888EE88sM888888888888884M88888M8888888888888888888888888888888Uc8888888888888888888Ic888888888888888888888888888888888888oU8888888888888888888cc8888888888888888888888888888888888888o8c88888888888888888o8888888888888888888888888888888888888888Mc8888888888888888Yc8888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888/9oADAMBAAIAAwAAABDzzzzzzzzzjzzzzzzzzzzzzzzzzzzzzzzzzzzzgjzzzzzzzzzzzzzzzzzzzzzzzzzzzzxBjTzzzzzzzzzzzzzzzzzzzzzzzzziizzzzzzzzzzzzzzzzzzzzzzzzzzzzyhTjjDzzzgjzzzzzzzzzzzzzzzzzjSRzzzzzzzzzzzzzzzzzzzzzzzzzzzzzyyhTyDzzygTzzzzzzzzzzzzzzzzzzwzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzyjBxxTzzzhzzzzzzzzzzzzzzzzzzyjTzzzzzzzzzzzTzzzzzzzzzzzzzzzzzyTzzzTzzyDzzDTzzzzzzzzzzzzzzSzzzCDTySzTzyjjzzSTzyBTjQTzzzzzzzzTyhzzyATywjzhxTzzDzzzzzzzyiTyRShyjADzzwzzjixjDzixzzzzzzzyRSxjizzyjTTjjjRzzjSgDjDzzzzzyhxxgzSDRhBhThTjwgjzxxATzzzzzzyDzzzxxzzwzyxzwyyxyzQjwTzzzzzzxzzzzzzzzgBxzxwzzzzzzyzzzzzzzzwzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzxDTzzzzzzzzzzzzzzzzzzyRzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzjSDzzzzzzzzzzzzzzzzzxDzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzyzSzzzzzzzzzzzzzzzzzzhzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzxjTzzzzzzzzzzzzzzzzjzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz/xAAUEQEAAAAAAAAAAAAAAAAAAACQ/9oACAECAQE/AGE//8QAFBEBAAAAAAAAAAAAAAAAAAAAkP/aAAgBAwEBPwBhP//EAEwQAAEDAgQDBAYGBggEBQUAAAECAwQFEQYHEiEAMUETIlFhCBQycYGREBUgQlChIzBAUmKxJDNgcoKiwdEWU4PwF0OSssI0RGNw4f/aAAgBAQABPwD+xmJMZ4fwiwHK1U2YylC6GblTqxvuEC5I2te1vPjCeauFsYzjBp8p1mbuUMSm9ClgdUkEg+69/L8dqGI6HSJAj1Ks0+E8pGsNyZSG1FPLVZRBtcHfy4TjfCa1BKcUUVRPICoNb/5vxjMzOeJhdUmjUQCVWUgoW6R+jiq8/wB5Q8OXj1HFWq9RrlRdn1SY7KlOG6nHTc+4eA8htxkHgaROrIxXKDrUSGSiNtbtnCLE36pAJHv9342++zFYckSHUNMNJK3HHFBKUJAuSSdgAOvGZmdVQmVRyj4PmqZhou25MYAK31H9w2ukDoobnmDa16JkFXsRQ0VXENdMOVJAcU240ZD1umslQsbdN7dd9hiD0dBGoqn6LWVPTmklakS0hCHLc7Eeyfff3jnxkHjqoVlqVhyqPOyVxGg7GeX3ilsEJKCfAEi1/EjoB+LZu5kuYGprESmhtVWmJUUFe4YRy16epvcDptvxIkPSpLkiQ4p151RWtazcqJ5k8ZdZS1bGchidMbXEol7qkK2U6B91A57/AL3LiDCj02CxCiNJajsIDbaE8kpAsB+N52ZgvV+rpwtQ5SnYDStEpDSCC9ICiNH8QFha2xPjYWynysj4Mhoq0/8ATVuSynVqTYRQRcoTzuroVeVhte/Gb+K28L4EloSpJmVEKiMIvuNQOpVr3sBffxI8ePR1wy5GpU7EjzjifWlGKy1ayShJBK79e9sPced9vxTG+YlEwPBUua8l6aR+ihNLT2qiRsSL7J8/58VSp1rGuI3JT/rE6oSl9xttJWq3RKUgcgOgHGV+SGns61i+L3r6mKc4AQPN0f8Ax+fgGWWo7KGWG0NtIGlCEJCUpHQADl+N5oYzawZg6TIS7aoSUliEgHvdoR7VvBPM/AdRx6PuEzOrMrEcuKw7EioLLC3e8oSLpVqSPJJ5/wAQt1t9GaFbczEzOgYdpaQ9HhvGK2QdluKI7RV/3RpA/wAJPXimUyFRqaxTqdGRHiMJ0ttI5JHP4m+9+v0VOqQqNT3p9RlNxojI1LdcVYAf7+XFFxFR8RRfWaPUo8xu1z2S7lP95PNPxH6nH+Y9Ky/hsrmNOypkgK7CM0QCqw5qJ9lN7C9id+R34y4zZhZgS5UL6uXT5rCO1DZd7VK0XAJCtI3BI2t199vwLDOb1RlZpTcM1iOy1EckuMxVBOlbKk8kqJO4Nj53/L6MTZm4UwqwtUyqMyJCF6FRIjiXXgrrdN+78bcYhzvxTieY9ScKw1xmnlkMKYZUuWtO+2xIB690XFufE9NTfq7zdREtypKd0upkai8V3tZWrfVfx34yly4j4Nobc6bHSa5LRd9xRCiyk7htPQdL25n4W/HM+sUtV/FzNGjtWbo+ttb1/bccCCRbwGkD338uMH4cZwlhWBRWVa/V2/0i/wB9ZN1H3XJt5W+jMzGTOC8HypYcR6++ksw2iqxUs7ah5JB1H3W6jj0ecLOtxZ+J5sdsmQoNQ3VpusWv2igT0JIFx4Ee/ir1in0GmP1KqSm4sRlOpbjh5eQHMk8gBuenGPMaz8Y4glyFy5S6b26lRIzq+62jkO6Ngbc/fzPHo50J97EVQrjkY+qMRyw28dh2qiDYePdvfwuPEfqJUlqHEelPuIbZaQVrWtWlKQBcknoOMXYnmYuxNMrExSruqs02TcNNj2UD4c/Mk9ePRxw/JRIqmIHWloYU0IrKlJ2cJUFKIPlpA+P4Hmdk7OmVdeJ8IqUJyll9+OHSlZcvfW2roetrjy8OI+ZWZ2H21092ZP1oUbidF7R1JvuCpaSr58SHM2swVssvN1l2M+nSmzJjRlJ53JAShQ8zfjDvo4zHHEO4kqzTLXMsQe8s+RWoWHyPFUp2GMpMF1SpUeC3DfU2UNuXLji3SLIF1k7X308tjtxlFhyTjXMFVUnyHnEQliZIf1gqW6VXSDfc3IJJ8un48lDFaz2LT7QdjSK+UrbO4UjtrWPlb6CbC54xnVpebOajNLpcha6eHRGhKUO6hO3aOWHMGxVfmUgeFuKHS0USg0+lNrC0w47bGsI069KQCq3S9r/HjFmMqJgumevVmV2YXcMsoTqceUBfSkf6mwFxci/FcxTijOLE8SkNpS2yt4+qw0X7NoH77h5qITzV77AXINRp66bV5dNcWhx2M+phRbNwopVpJB8LjbjBdDj4dwhTKbHjGOEMJU4hRurtFC69R6m5P6jPnEgo+BDTGlqTKqiw0NK9JDYIKzbqCLJP97jC2G5uK8QxKRAbWpbywHFpSSGkXsVq8ABxQ6LDw7RIlIp6CiLFbDaNR3PUk+ZJJPmfwfP3F5q2Jm6BEeKolO/rkpOynjz5c7CwseRvxk/gtnCmD2JC0Oio1FCH5Pao0qRcbItzAHn1J/HqlJThPOuVMfZWw1CrJkFtKbEtdpqFgfFJ29/EKbGqMJmZDfbfjPJC23WzdKgeoPGdOZDWHqQ7h+lSiKzKSA4ppVjGaPM36KPIDnY322vlFgOBgvDyMRVh+OJ81lLocdISmM2U30gqtYkHc7eHQk44z+p9LUqHhRDdQloc0rkPoJj6Re+khQKje2/LqCeKFhjGGcFdXPlSlusIWESJ8ggNsgi+lCBa5sPZSLbi9r34omEsO5X4ZqEyFGdWWI63pMhVlPOpQm5AOwHLkLD+fGA4Cq9mLRo7kf1pL05Dj7ahqCkBWpZPiLAk8AAAACwHIDp+oz+xKmr43bpTWks0pvQVW5uLspW99wAED3g8ejhh0oZqmJXFnv8A9CaSFbWGlayRb+5Y38fwet1eNQaJMqsskMRWi4oDmbcgPMmw+PGXlHOYWanbVKQoguLqD5sNTmlQOnlbckX8r8JASAkCwGwH49nNlk/i2KzWaMy2qqxUlLjQFlSW+gvf2k728b+7jBuYuIstnZcJEbUy5fXClpUkIcvbVbYg7WI69eQtVazPrVYkVaoSC9NkL1uOK6noB4AAAAdAOI8HG+ZM5pCG6hVltJshTirNMi3QqshFwke8jqeMD5CUmnQi9ixtqpTlkKSy04tLbNidrgjWTte4t035mFAh02KmLAiMRY6PZaYbDaE+4AAcZvTnaflXXXWlaVLaSyT/AAuLShQ+Sjx6PdFTPxu/UnErKKdGUpCh7PaL7oB/wlXy/USX0RYj0hxSUoaQVqUo7AAX34mSZGIsRvylIHrFQlKcKEAkBS1XsOtt+MOUOPhrDsCjRTdqI0G9VrajzUq3S5JNvP8AB/SIr5hYXg0ZpZDk57tHNK7EIR0I6gk/5ePR6wwzCwu/iFelUme4W0G26G0Ei3xNz8vx959qKw4++4hpltJW44tQSlKQLkk9Bxiqo1DOrMlilURINMihQYeUyUaGu72jq+tiQLDb7osCTxRcosE0aMy2KIxNdbBu9NHaqWfEg935DiLFjwoyI8VhphhsWQ20gJSkeAA2H0+kTODGBIcMPBC5M5N277rQlKidvAHT+XHo2QlIo9enFJCXX2mkm210pJP/ALx+ozUq6qLlrW5SU6lrY7BNlWsXCEA/DVf4cejpRjLxVUaq5HacZhxg2hxQBLbq1CxT56UrF/Pz/CM0akcaZqvMUl5yUgrbhxgVXSFCyTp8ElVz8b8UCkR6DQYNLit9mzGaS2BzOw3JPU36/s+ZmbUPBAVTYLYl1tSAoIUD2bAPIr3FyRyA+Ntr5bZzR8a1JFGqEFMGplrUhSHNTb5A7wSDuk8zbfYHfb8Hzfx/IxRVU4Fw2lx1PrIZlLTsX3b2DY/hCuZPMjwG+WOXEbAVGPa9m9WJI/pUhO4AvshFwLJHXxPuAH2PSSh68N0abov2MtTWq/LWkm3+T8uPRyeWcFVNgtKDaKgVJctsoltAIB8tI+f6j0j8QXNKw4hIsP6a6r5oSB/nv8OPR8on1fgN6pOMhDtRkqUlwKvraR3U7X2srtP+7fg+Oq4MOYJq1UClJcajqS2UEBQWrupI9xIPw4yMwzLrmOkVsqAjUwl1xSk37RagQEjz3J+Xj9qq1inUKAudVJrMSKjm48sJF+dh4nnsNzxTs28C1We1Ci4gaL7p0oDrDrSSfDUtIA+fAIIuDceP2ibC524RirDq5YiIr9LVJJsGRMbKz/hvfgEEXG4+3jfFcbBmFZVYkWUtA0MNH/zHT7Kfd1PkDxgTCtTzXxtIm1eU67GbUHZ0hau8oH2W0+FwCBbYAe4cY2p8XLrNwfUzTrMaG6xJZQpwnayVKTqJvbmPdxGfblRWZDS0uNuoC0rQbhQIuCD1H280M4J+CsTxqRS4MaQENJelqkIWCQTslBBAGw3V3hvbmDxhjEMbFOHYdahtutsSkFSUOgBSbEgg2v1B+1m5nEqc65h7C8tSIjarS6gysgvEfcbI+54qHtdO7uqJi3MXBr9MrUydVVQ5iC6w3UX1ONyGwRcWUTa4tvsbKBHMHjC+II2KcNQK1EAS3LaCyi9+zXyUgmwvpUCL26fTWsQ0jDkP1usVGPCZ30l5diu3MJHNR8gCeMX+kO45rjYSh9mmxCps1A1dRdCL28CCq/mkcYUxbi5zH8KdT5s2dU5UhKXGluFQkJvuhQ5BOm/SybXFrAj9fnFmuijxncOYfkpXU3gUSZDK7mML2KQR987jxT77WyWyycoLIxJW2FN1V5JTHYcSQqMg3BKgeSlb7dB7yB9n0jiP+AqeL7/WaNvH9E5x6OySMuZJItepOEef6Nv7cmSzDiuyZDiGmWkFa3FqCQlIFySTyHGNsTPYvxdPrDil9k65pYQr7jQ2SLXNjbcjxJ4ylS2jK2ghttSE9io2VzvrVc/E3P2cxc0aXgaEphC0yqw4hXYxkEKDZtspzfup3HmenUikZ6Y2h1Nt6ZUGZ0ZSu+w9HQlNj1BQARb3/PiHKbmw2JTJu0+2lxB8UqFx+X7c++zGZU9IdQ00gXUtxQSlI8yeXESZFnx0yIclmSwr2XWVhaT7iNuPSKxQ12EHDTDmp3V6zIAV7ItZAI8eZ+I4yUw45h/L2OZMZceZMWqQ6lYIVY7JuDy7oG32cyM4adg5tUClFioVq5SpvVduPbn2hHX+G9/G216vXsQ4wqPa1CVMqD6l9xsXUlJJ5IQNhv0HEbK/G81hx5rDM9LbQJUHUhtR9yVWKvgDxknjVeGcQSsO1+b6lCcB0ImXQGXgd03Ps3F+e1x4ndC0uIStCgpKhcKSbgj7GJ8U0nCFHcqdWkhtpI7jYsVuq/dQOp/l1sOMa5pYixjJdDkhyHS1EhqCwshOn+Mi2s7ddr8gOGKZMmqWIcOQ/p3V2bRVYWvc2vbYX+HH1tVPV2IxqUwMR1amG+3VpaPikX2Pu4yTxO9iPAaEzZEmTPhPLZfekK1KXc6km/M2SoDfw+1n/ic1TFrFDYd1xaaj9IlBBu8rnuOoFhY8jfjKjDCcMYCgMuRSxOkI7eVrFllatwFe4WFvLj0ioYYxvBlAG0iCnVfxSpQ/lbj0fcSVuXX5FEkVF96lswVPNsO94NqC0JGlR3AsT3b28vs1yv0rDVMXUaxNbiRUkJ1rudSjyCQN1HnsATsfDh30kKOipONN0KY5CTfRIDqQtX/TtsL/AMX+3GK8Sy8WYlmVmUpxKpDiuzQpQUGmvuoFgL2G17b8+MrqOuhZbUSEt0OLLHbkhNrdoouW+Gq3w+znPmm1R4T+GaK6hyoSWyiU+hQUI6DdKkbHZw+fIHxItgihjEmNKRSVpCmZElIdBVpu2nvLF/HSlXx49ICG2MtIwaDLSI05rSgWT3dK06Uj4g2HQeXGR2KKJTMujHqdap8NxqY7ZuTKS2oJOkg2URsSTy4qufmCKfpEZ6bUlKvf1WOUhNvEuFPPyvxWc8sbVuqBqirbpzTquzaixmUvOKudrqUkkq3t3QPdxQ8ncaY1muVGvOvU5K1d+RUSpx9zmDZFwdrfeKRvtfjC+VGFMOUZqE7S4dTfHedlTYyHFrV5XB0p8APzNyYlBo8Gb65DpMGPJ0dn2zMdCF6f3bgXtsNv1+cOYruDaSzApTmitTRdpwBCgygEXUUqvz3A28fCxydyqeRJYxdiRtwSdZdiRXk97V/zXL73vun3A+H2/SQW4MIUlsdn2ap9yCe9cNqtby3N/hx6PaFpy2cKkrAVUHSnUNiNKBt4i4P5/bz7xj9S4ZbocR9aJtSuHAjTswNlBV9xe9unXfa3FSw/UKTS6XUZbQRHqba3I5vuQlVjfw6fPjKh9cjK+gOOBIV2BT3eVgtQH5D7GbGZTeB6QIkJSV1qYg9gnYhlPIuKH8h1I8jxlzlnLx1JkV6vyno9ISouOyHCQ5JVuVEKO1hvqV//AG1cplMquZDlLwixqp7khDEZKFKWFWAClAkkkFVzfw4gRUQafGhoN0MNJaT7kgAfy+xibEEPC+H5dYnKKWY6L2A3Uo7JSPMmw4xNjSsYsr5qtQkLBSsKZYQtXZsDbZAJNuQJ8+KDLVUMPU2Y4rUt+K04o+JKQT+f7R6Q+I48bDsTD6HXRMlOpkKSjZPZJuO8etz08vdxlRmOrA9bLM5x1dFlCzzaCT2SujiU/kbc/gBxGjMZk5vltbzrMSqTXF3HeWlsAqsL+Qt5X4jsojx22WxZDaQhI8h9K1pbQpa1BKEi6lE2AHiTxmfncJTS6NhGQ82m9n6gglCjY8mzzA8T/wBnL/As7MDEa46XdEZkpdmPrVdQSTyHO6jvb3cUDC9EwxEEajU2PETpCVKQga3LcipXNR954xXiSHhPDkusTSChhHcb1WLqz7KR5k/lc9OK7Vna9XZ1WfbCHZjynlpTySVG9hxlwb5b4dN7/wBAa/8AaPpxJiSmYToj1Wqz4ajtbADdTijyQkdVH/c8gTxjrHdSx3XTNmq7OK2SmLESq6WU3/NR2urrboAAMGYWl41xTFo0ZZbC7ree03DTY5q/kB5kcY7VTMpsrjSsPt9hLnH1dDwALrht33FG25tt5aha1uDQp6sNfXzrK0QTIEdtxSSA4ogk2PW1jfj0bgRh+tCx/wDq07229gfZmy2YEGRNkK0sR2lOuK8EpBJPyHGD2H8VZq04vBMhyTUPWHtQ2WAouKv8AduALbceklN11+iwP+VGU9y/eURz/wAHHo50NqPhqoVtSXPWJcjsAVpsnQgXuk23upRuf4fL7GOs1qBgftYrizNq6UpUmC0SCAeWtdiE7b257jaxvxi3GddxpUBLrMsrSgq7BhI0tMpJ5JHyFzcmwuTbiJh+pS6HOrbMVw06EpKHXyLJClEAJv1O428x48Zd4UVjHG8GlKSr1VJ7aWfBpNir3XNk3/iHCQEpCRsBsB9jNLOWJQhLoFBV6xUygtvS219yKTsQCPaWBfwCTbmQQJOGKsnC6cTzWltRJEkNNrfvrfUoFWoX5jY78YXwDijFUJ2pYfhds3GeDZUH0NqC7X2KiOW3z4xDRMZU6ChVfiVdqE06UoMsrLaV8tidrm3Mcx48YHyqruPILs+nvQo8Np/sVuSHFAlQAJ0pSDewUOdufv4wx6PuHafH14gcdqspQIKErUy0nfawSQon3m2/Lil0Ok0RtTdKpsSChRuoRmUt6j52Av8AsOZWYkXANGQsNesVSXqTEYN9JItdSj+6Ljbmb223IypwHKxPVJ+McaRFSVSVhUduWg/pFXB12P3RYJA5W25D6MS4yw/hBuO5XaiiGmQohoFtayu1r2CQTtcb+Y4oGJqNimB67Rag1MYBsoouFJO47yTZSeR5jf7PpJ1MpjUGlpW0QtbshxO2tOkJSk+QOpfvt5cZOQHafldR0vKc1PJW8ELIshKlEgJ8ARZXvUftYlxDBwrh+XWaiViNGTchCbqUSbJSB4kkDw93FGp83OjNGVImqEFpbfbuhHf7JpFkpSkKO9zpv7ybdOPSQitxkYYbjtNtR2UPtobbASlA/R2AA5Cw4yOkB/K2nJD4d7Fx1spAt2feJ0nx53/xfYzrkPP5r1NEh5Sm2Q022L30I0JVYfFSj8eMYZmsvYVhYMwiHmKQ1HS0++4LOyD1SLHZJJ38b25c8jMupFGS/iGtU9TExzuQku3StCCCFKKT7JOwF97X+xUahGpNNk1Ca52caM2p11dr6UgXJtxmNmLOx9VSLqj0iMo+qxvH+NXio/lf3kniiVzGGEYTVVpcmoQ4DztkrsewdUnoQe6rjLrOOnYvUzTailMKsr2ShIPZPH+EnkfI/An7GPcVNYOwjNqqnGxISgojIXvrdPsi3M78/LhrH+KW8RN15ValuT0KuFOOEp0k3KdPIJPgNuMQZq4xxBPEl2syISUf1bEB1TCEfI3PvJPPjI7MWTXmHMPVZ2RJnsBTrcp5ZcLiL7gk73Hn+wV+ZLzNzibjttBkOSEx20E6tDaOZPQmwJ4z9whS6OunViGWo78gdiuO22EhwpG69uu4B49HRFJViaoqkWNUSwPVdX7l+/bz9n/u/wBNZrdNw9TnKhVpjUSKjYuOG1z4AcyduQ34zFzfqGNnk0WgsyItMWvRoH9dLJNgCByHgkXv1vsBiTDNSwpUEQKq0GpSmkulCTfSFC9r+I5HjJfDTFAy+hyEK1v1JIluqty1AaUj3C3x+jOTHMnFmJRhmlpLkGG/2YS0bmS9yvtsQDsPf524q9Jn0Wc9BqUZ2LKatracFiARcfC3GB0IawNQ0NtqbQmE0AhXMd0bH6MXY0ouCaambWJBT2hIZZbGpx4jmEjy2uTYC433HFRq+Jc6ccx4jaFpZ1EMMIuW4jV+8tR6m1rqPM2A6DjNKg0vCmII2H6YCv1OOkvPLtrcWvvb28iLcZQ4Ri4RwQ1NlxjFqMtvtpjkgaFISLkJN/ZAH+p4zSxcrHuNEs0xx2VT2imPAaQlQ1qNgVaedyrYbC4A8OM2KC3hLJ7DlBTJWtTUrUsG1lrKVFRHkCo28jx6O7Iby+kuAEdrPWok9bJSP9Ps5o1c0XLetSUtdopyOY4HQdp3CfgFcejnhqO8ajiV/Qt1lfqkdJG7ZsFLV8QpIB9/j9GI8FYdxaGvrylNS1NbIWVKQtI8NSSDbyvbin0+JSqexAgx0R4rCAhtpA2SB9E6dGpkF+dMeSzGjoLjriuSUgXJ4x5n5NnOSabhQeqw90fWCge2cHIlA+4D0J73XunYZa5TioxXcV4z7aLTGB6w2y7sX0p7xW5qB/R26c1b8ha+KJLWNseLawvTFNxX1JahxGmQggBIBOlOwGxPkOMzJsbCVAp2XNIlFxuKO3qjukAvPKIUAdunPmdikc08ZDYhptExu+zUlNsqnsdgw+s2CV6gdN+mq3zAH0E2Fzy4rGaeCqGdMnEEV1yxIbikvm46HRcA+8jjHWd1axIuTAoy1UykKukFIs+8n+JV+7fwT7iTxlbko3VIkXEGJg6llS+0Yp5Rp7RIOxcvvY87dRbfe3HpGVZCH6Jh5hKm0MtKlrSLJRpJ0IA8xpX8/lk5R10fLCkodQ2lyUgyzoHMOHUkk9TpKf5dOPSDlux8tkNtu6EyJ7Tbibf1iQlarfNIPw49HNKv+AqgtROlVUcsP+m3v/34fsWMMVwMG4ckVacpPcGlloqsXnCO6ge/8hc9OMA4aqObmMJWKcVa3KYyqwbAUlDh+60g9EJ5mxvyvuon6c6MvapjenU6RR1Nrl09Tn9GWQntUr030qOwIKRsedzvtY4VxriPLmrSEQgGlFWiXClNnSpSbiyhsUkX6Ef6cU30kaQ6hX1nQJ8dz7ojOIeCvG+rRb8+J3pJUdsD1CgT39t+3dQ1Y+G2riX6RuIVuFUOjUphtXsh9TjhA8yFJ8+nFQz5x1OcSqNIhwUgaSmNECgo+P6TUb8VWtVSvyvWqtPkTX0p0pW+4VFKbk2F+QuTt58Zc9v/AOHOH/WTd0Qmxyt3bd0fAWH2SQBcmwHjxnLjhONcSRaHQnVyoERehJaBIkPqNiUgHvAcgbdVWuCDxlrgKPgPDiYxUl6oyCHJb4SBdVh3AeelPS/W52vYekbTm3sJUyoaT2seZ2YI5BK0m/5pTx6OFSU/herU4kERZSXR4jtE2/8Ah9NfxJR8L04z61OaiR76QV3JWfBKRcqPuHGY2KIWMMaSqxAhrjMOJQgBz23NItqUASAeQ26Acej3TsPza/NeqCG11iMELgocVyHe1KSORUNvde45X+xKlx4ER2VLfbYjtJK3HXFBKUgcySeMzcyZ+YNYRQKEh40ntQhpptJ1zHL7KI8L8k/E72tWoETK3LmTQ5fqz2Ka2kB5KR2nq7HhfoeY25nle1+Mn8tzjGs/WFSjqVQoiv0lyUh5dtkAjn0J8veOJlGps6jOUh+Gyqnrb7Ix0p0oCeVgBy+HFehSstszXRGQAqBKD8ULCtKm76k7nci2xPiDxh2sN1/DtPqzQATKZS4QOQNtx8DcfRNmx6dBfmynA1HYQXHFnklIFyeMysxJmO60ooW61SGFf0aMTt/fUP3j+Q+PGE8K1TGFdZpVLaCnVd5bi/YaR1Uo+H8+IeUWHKbgSTQnIzch91pRdnFlPbFdtlJJvpt0HGU8x6k5pUtsP9gFvKju3A7yTcEG/Ll+vxVJXDwjWJDa1ocbhPKSpHNKtBsR7jxkLHbdzAenyuz7KLCcdU66oDQokd7fy1b8ZlYgczCzDDNMUHoyHEwoVuS991e4kk+7jEuR2KsOBiZR9dVShAccXFGh1pd+SU6tSt+RT8hxhzPPFWGCKbXYgqSI5KFJlFTUlBG1ire9v4kk+fFW9JKZIgONUqgIiSlpIS+9J7UIPiE6Bc+828jxBpWOs1qoHCuZUAFEKlSFFMdnlcA+ynnfSkX8uMu8nKbgmT9ZS5AqVUtZDhb0oY8dAud/4vDw3v6R1BcW1Sq+g3Qi8RwaeVyVJN/nt5cZR4/ok7AkGDMqEKFMp7YjrafkJQVJSNlgKIuCLXPjxm5nDGahuUDDExt915NpM6O5dLaT91CkncnqeX+mR2W7lQmMYwqZAisrV6o0bEurFwVK8ADy6339/pE4c7CowcQMR1aJKewkupBIC0+yVHkLjYeOnjK7N7D0PBUam4iqqo82CkoBdZUQtsHu6SkG5AsN99uvPjGHpB02CEM4UZRUnFC65EhC220eQSQFE/Ie/ik4VxrmnVHKmEuyQ45ZyfLc0st8zpTfmBy0oBttsOMC4EpeA6P6nBBdku2VJlrHfeUOXuSLmw6eZJJxsGqfnPU3a3HeVFRUu2dbTYqU0Vaha56ptb38Zm5yIxfTE0Wix5ESmKsqQuRYOPWsQiySQEg78zfblbfIzLhMOGxi6qtL9cdv6i0sFPZNm4KyOpUCbdLG/Xb0k56lVChU4AhLbTj9/HUQP/h+fGVdQpuFMmqbUKvJagx1F1xbjhtqJWoiw5kkAWAueK76RtLiS1M0SjvT20kjt33OxSrfmkWJty52PlxlfmgMwROZfpxhy4pCj2ZK21IVe3etsrY7fEdQPozeiOzcrK42y2txaW0OaUgk2StJUbDoACT7uPRuqaFQ67S9KAUOtyUnV3lBQKSLeA0Df+L7GMsz8OYMjuplS0yaiEktQWDqWpQ2soi4QPNXQGwJFuKviLHOclUMKFEecgtuakxIwsyze+kur2BNgbFR8bAXtxgbJGg4bajTKskVKro0OFaiexZWDfuJ2v03Ve+m4CeXGdlUl0rLKcYZ0mStEZxViSltV9VvC4Ft/E9bcZf40ZwJNqFS9QVKnPRCxEJWAhpRIJUra55Dl4EdbjKrCKsd457WqMuSaexrkTnHCqzqj7KSsfeKiDa+4SrjGXo9OuTfWsIyWUMKuVxJjhug32CFAG4ttZW+3M32OWWbVCQlmmvzCz4QKpoSPgVJ/lxJyyzRraw7Nps+Sq1gqXPQTb/G5fimejriWShpdQqVOhJWAVoSVOrR5EABJI8lW8+MG5T4Zwelh9uKmZVG02VNkC51cyUouUo35W38z9Gfs92TmW6wpASiLEaZQQPaB7/81kfDjD9OFIw5TKakkiJFaYBPM6Ugb/LjP7GSaxX2sOQndcOmnW+UkFK3yLWuP3QdPkoqHTjJ2iKoeW1OadYkMSJClyH25CChSVFRHsnkNKU2+fX9hqlUhUWmSKlUZKI8SOjW46s7Af6kmwAG5JtwuVUc8Mz22gJLNEZPdSf/ALZjbUbgWC12633IFyAOKXS4NFpjFOpsZuNEYTpbabGwH+pJ3J5km/2MX4BoGNILjVShNiUUaW5raAHm7crK5kXJ7p24xNgmRgXFTMDECHnKatYUmTGABfaBGoovsFAbWPI+IIJwjlXlzKgxq3ToaqnHfTraVLeLiU87gp2FwdiCDYjhrAuEmFlbWGKOlR2uITf+3EOFEp8dMeFFYjMJvpbZbCEjqbAbcV6PHxTnnIiNhtMeVVkRyUAWICghRHjexPnfhKUoSEpASlIsABYAfZzrzQTSY0nClIVee+3pmPW2ZbUPZH8RBG/QHx5ej9gdMuW/iqoR0rajnsoQWm93OanB7hYDbmfEfRmBhlWLsE1GjtrSh91AWypQ2C0kKSD5Eix9/GV+PXsu8RyGZ8d4wZJDUxgIAcbWkkBQBtuCSCNuZ8uHZ0SPCM16Uy3FCNZfW4EoCeerUdrefGNs+aNRA7Dw8lFVnAW7cH+joPvG6+mw2/i4iQ8Y5uYmCluPTnyQlb7g0sRU+dhZA25AXNup4wtkrhag0d2LUIrVXlvpUl2VIbtYHazabnRbxBvfryAxvgSt5Y4hanxHHfUA/qgT0kXChuEqtyUPkbEjqBgLPSk1iK1CxM83T6nq0dtpIYdHQ330nxvYefQImRnYvrTcllcfTq7VKwUW8b8rcYkznwdh5uzVQTVJBF0s08hwfFd9I+d/LivYlxfnFXmoUWEtbLZuzCjX7NoE21uKO197ajYeFr8ZeZZ07L6jrqtWEZ+sIQpxyR91hNvZQTa23M7f74wxG5jPGMyrFpaBJWEMsrc1dmkABIv08bcrnjL3DruFsEU2lSCDIbRrdtyClG5Hw5fD6PSRpCUvUWroS2CoLjuG3eV1Tv4Cyvnx6Plcjy8FO0lU0OTYkha+wUTqQ0q1iL9L35cr+fEybFp0NyXNkNR47SdTjrqwlKR4knjNHNSZjWW5SaXrZojS7AJ9qSQdlK8uoT8T5IaU48lpAutSgkDxJ4yrwIMD4XSzISj6zlEOS1JVqAP3UA+AH5k89uCARY8jxW0DD+a0vUlbQj1TtN0kEJK9XLwseGHkSI7b7ZuhxIWk+IIuOMcY0p+B6CuoTVFTq7ojspAKnF222uNh14y9zyn4mxQxRqxTI7frR0suwwoaVfxBSjt5j9ZVYX1lSJsHVp9ZYcZ1eGpJF/z4XLreD6lVaWzJdhvELhy0IUO8m+4J/wBR48ZEZdrhtjFtVYAddRaA2oA6UEbudbE8hyNr+P0VvAuFsR6zVaHDfcWdSnQ3ocJ81psr8+KZlVgalFZj4bhOFfP1oGRb3doVW+HEaKxDjNxorDbDDaQltppASlIHQAbAfRUadDq9PfgT46JEV9BQ40sXCh/316cYk9HquMVR9WH5EeVAPeaTId0Op39k7WNvHa/lxgf0f1w6iidi1yHKZSm6YTClkFW1ipW3LfbcHx4jx2YsdtiO0hpltIShtCQlKQOQAHIcVCnxKrAfgT47ciI+nQ404LhQ4q3o3RnZ5cpGIFxoqlf1MiP2hQOtlBQv7rD38Yc9H7DlJksyqpMkVV5pWrs1oS2wrwujcn/1W8uIkSNBitxYcdqPHbGlDTSAhKR4ADYfRj3KiiY8kNzX3n4VQbb7MSGACFjprSfatvaxB357C2EciKFhyexUKhOfqsuO5raCkBppJ6HRckkHf2reXHTj0hqxBqGLIEOJIZedhsKQ/wBmb6FlR7pPiLcul+MC5e4izDbZSJK2aJEcLZfecKktHYqS23fmbg9B58Zr0TCmAMMx6FTaWl2qTkhRnSO+4hCTuQehJ22A2vx6OFGdYotWrC9kSnUMti3MIBJN/C6rfD6ZcVmdDfiSUBxh9tTTiD95KhYj5HjENCr+TWO2ahAWTH1qXDfIKkOt3ILbmwF7cwPIjoeMO5/YUqUPVWVO0iUnm2ptbyFf3VIST8wPjxPz+wRDt2Ds+dckWjxim3me0KduMXZ24jxatunUJp6kMLUEhMV1SpDyr7DWkAjpsn5njBmQVZq5ZmYkdNMgrTqLCFXkq5WuLFKOfW5FrFPhhrDNKwlRWqVSI4Zjo3Uo7rdV1Ws9VHb5ACwAH0VSlw61S5NNqDKXoklBbcbV1B/kRzB6EDhPo2Uz6z7ReIZZgaiewDCQ6B0HaXIv56flxhzDlNwrRGKVSmA1HaG5NtbirbrUeqj4/wAhYfbz/wAFTGK0nFsRDj0N9KG5RJuGFpASk26JIsOu9+VwOKlnRjaoUdmm/WLcVKG+ycdjN6XXxyupW9jtzRp58ZO5UP1WpCu4kp7zNOj6Vxo76Sj1leygog7lsCx8FEjmAR+wvvsxY7kiQ6hplpJW444oJShIFySTyAHGPMY1DNnFMbDuGo7zlOacIaSFFPrKtruLHJKRY2vyBJNr2GDsJU/BmHmKVATcpGp54ga3VnckkDfwHgLfaxZhOl4yoblLqjV0q3adTbWyvopJ6H+fEOo4qyIxOqmykidRpSu0SncNvpFgVtn7rgFgRv0vcaTxAnxapBZnQZDciM8nU262oKSoe8cYirDGH8OVGrSNPZxGFu6VLCdZA2SCepNgPM8ZDUcVXMgTnHCPq+OuTa19ajZAF/8AHf4fZULpIBtcc/DheRWJJePrVBbb9Jfkqefnh4alIKrkEcws38CLnnbimUyFR6bHp1OjIjw46AhtpA2SP9T1JO5Jufpzdyofxm43WaM4gVVlsNKYcISl9IJIseihc89j5W4TlPjpdR9Q/wCHZaXb21qKeyH/AFL6fz4wT6PqWX1SsYLafSAOyhxHVWJ661WB+CT8enFOp0OkwGYNPjNRorKdLbTSdKUjny9+/wAfonQIlTgvQp0duRGeTpcacF0qHnxif0dYE2cJGHKj9XsqI1xZCVOpR5pVfV8DfnzHLg+jxjLt0oTJpWhRV3y+sBIHK40dfK/GH/Rvc7QOYiraQgf+TTk7n/Gsbf8ApPGFsIUXB1NMGjROxQohTrilFS3VWtdSjz93IX2A4zMoVRxHgGp0ylKImOJSpCArT2gSQSi/mBbfbfjKrKusTsXMza/R5MSmwVBxaJjSmy6v7qUhQ7wvz6W68vpxbhmHi3Dcyky0JPaoPZuFNy0vooeYPEuBivLHEja1iRTJzZJafRZSHQOZB3StPiD47jh+s41zPq0emuy5VTkKP6NhIS22n+IpSAkWH3jxi/L2n5dYFacqchMnEs90JaDLlkMIG6iBsVbbFVuZHvORuFWsQ41E2SX0s0tKZKShPdU4FDSlRI95tz2+nP8Aw29TcXN15tlHqs9ASpaf+akWN/Mi3y4wzn9QqXhSDDqUSqyKhHZDalIShSVkcjqKhbp0+fGMMYV3M/ETQRDcUE3REgRklZSPgLqPnxlFlKrC+iu1wJVVXEfoo/MRwfE9Vfy/W4jy/wAMYtmszK3S0yX2U6Er7VaDa97HSoX+PEaMxDitRozSGWGkhDbaBZKUjkAP2HN7NxTC3cNYZlLTISoCTOjuWKDz0IKd735ke7x4r9AnYemMx6iU9s80l+yVXISrlfz4w9S49Fw7TqZFKizGjoaQpQF1AAC5t1PPjOnLypYzgQp1G0OTYIUkxlEJLqFW9lR2uLcjzv4ixygwjVMHYNVCq5SmU9IU8WUrCg0CANNxtfa+3j9iq0mBXKc9T6nEblRHhZbTguD5jwPgRuOKz6PGFpxdcpkudTHFW7NAWHmkePdV3jf+/wD7cUv0cKJHklyp1qbMbFrNMtpZB8Qo94ke63FBwxRMMxRHo1Mjw0WAUptHfXb95R7yviT+teZakMuMvNodZcSULbWkKSpJFiCDzBHEPAuFKfUBOiYdpjMlJCkOIjJBQRyKdu6fMW/YeXGbWYz2Kqo1g7CklT0d1wMSFtaSmUtRTpShXMpB2PK/mOeWWXcfANEU06pqRVJCtUmShO1uiEkgHSLX35knyA+3jXBdMxxQlU6oJKVpJXHkJ9pldiAoeI33HX5EUyv4tyTxGKPUAp6llwuKji3ZyEkW1tqIuk8uXUWPGaubsTG1Ih0ujNTo0UOFyWiQlKe0ItoHdUbgG53tvbw4yRwknDuCUTpEdTdRqau2eKxuEAkNpHlbvf4vd+0zYEOpRzHnxGJTJ3Lb7YWk/Ai3EaLHhR0R4rDTDKBZLbSAlKfcBsOM58tMQYwqEGpUQpldi0WlxHHwjTvfUjVZO/XfoOfGVGCpGCcIJiTks/WEh0vSC2kXTsAEFQ9q2/lubeJ+jEmHKdimiv0qpsJdYdGxPNCuih5jgejSsSd8Uj1fx9R73u9u3x/LjCOXWHMGMI+rIKVS9NlzHu+8rx3+6PJNh+35zZrmmB3DFAkETDtMltL3ZHVtJH3vHw5c72yTy0FHgpxNWY6FT5aAqK06i6oyN+9e/tKFjyuB7yOMYvRK96QBZVHvGVVWIjrS+S9Kktr+BIUfjwkBKQBsBsB+EZ3Zmrha8JUN5xExWkzZDSiktg2IbSRvc7XPhtvc2yhyoi0CBExBW4jn16u622XthFSbgd0feI3N+V7WBB/VVvDtHxJD9UrNOjzWfuh1Nyk+KTzSfMEcJyBwSmc1I01EoQvUWDIGhYvfSe7qt02INhz4SkJSEpAAAsAOn4/mXjVnBOEpEpLyU1KQlTUFs21Fz94Ag3Cb3NxbkOvGU2X8jHlbdxHWJJchRpYW92g1rlO7KIVfpuCb3ve3mHnmokZx51aW2WkFa1E2CUgXJPkBxllS5GLM2orzzpcLUhU990m5VpVcH4qKfn+EZu5pIwZCNJpSkrrslu4URdMVBuNZ6FR6J+J2sFZOZWuy5DGM8RhSytReiR3gSpxRP9cu/nuPHY8rX/sXmfimTmLj5mnUtKnIrDvqcFsnT2iyqxWQTtc2322AvyPGG6JGw5h2DSIiAlqM0EbADUr7yjbqTcn38Zm1AUzLavSCvReKpkHTf2yEWt/i49G+ircrNWriipLbLIioGnZRUQpW/iNKdv4vwfNfMRjBNAXGjO3rc5tSYiE2PZDkXVX5Ab253ItawJGVmXk3HeIDW6wp5dMYeDrzz4KzMc1XKLk3N99R3+Z4bbQ02lttCUIQAlKUiwSByAHh/YvHNaew9ger1WObPsRz2Sv3VnupPwJB+HHo+4YNTxNKxJJC9EAaWSQbKdWCCb+Sb7fxfR6RtVEfClLpYQrXLlF3WDsA2mxBHmXB8uPR/paYOXCZlwVT5Ljp8QEnQB/kJ+P4NmRmPAwDSb9yRVn0n1WIVe/vr6hAI+J2HUjAuCq5mrileI8ROvGnB0OPPuoNpNlf1Le4smwIuNk8RoseFHRGiMNMMNiyGmkBCUjyA2H9jM8nn2srKgGSAlx1pDm33dQPw3A49HFJ/wCBqis9aioD3BtH+t/o9I2a5IxTR6YhKVBqKXEhO6ipayLfJA+fGDaV9SYNpFOMZEZxmKgONosQF2BUbjmSbknqfwXHuOadgTD650taVy3QpEOKPaect4dEi4KldB5kA4NwZX82sUSKxVHnDC7YKmzXLjV/+Jvz02FhskW8gYsViFFaixWUMsMpCG20JslKRsAB4f2Nzaortdy2qzDDiUOMN+td7koN94j5A287cejhUIysL1Snduj1tEwvdlfvaChAvbwuD9Ffcbxnn8lEIuSWHKg01+kITdDdgu3lZKiOtvPgCwAHIbfgmOcc0rAlEM+oK7R9y6YsRKrLfWOg8Ei4urpfqSAaZT8SZ1Y9cdkvhJI1Pv2u1DZB2SlN/E2Cb3JJJ+8rihUaHh2hw6RT0aIsRoNouBdVualWABUTck23JP8AY6owWqpTJdPkFQZlMrZcKDZWlSSk2PjY8YZbk5TZ1op01wGI8r1ZT6k6Q4y4RoXvsNwm/hZQ4xBVPqbDVSqiQhRixXHkBarJUUpJAJ8zYfHjIinoqWaCJLl7xIzslNuWo2Rb/Ofl+CY4xvTcDUFyoTFIdkkWjQw6EuPquAbX6C9ybGw+ANJpmI86sduyZTpDadJkv79nEZubIQPH2rJ6m5PU8Yfw7S8L0lum0iIiNGRvYbqWeqlHmo+Z/shm/lwcbUZuZT0pFZgpPZCwHboPNBPO43Kd7XJ8bidjfEiMIJwVLcLMKK6QtCkqS6bG/ZrJPsg9LbWHgOMhcJroeEHKrLj9lMqa9adQIUGRskEHlc6leYI/A8b45pWA6N69UVFx50lMaK2R2j6hzt4JFxdXS45kgF7/AIhzkzBcWy1Z587JKlFqGwnlc22A926jyubcYQwjTMF0FqlUxvug6nXle28vqpX+3T+yUuhUifMbmTKVBkymiC289HQtaLbiyiLjf8DxHiKnYVoUmr1R0txmBySLqWo8kpHUk7fzsATxVqjXs2ceh1qKVSZJSyyw1qUiO0DYXPRIuVKVyuSdr24wJgOl4DoxhQR20h06pMtabLePT3JHQf6kk/21xXhaBjHD71GqSnkR3VJXrYUErSUm4IJBHzHXjBGW9AwEmSqlIfekSLBcmUpKnNI+4CAAE335bnnewt/+7v/+AAMA/9k=") }



            .sign-diana { height: 32px; background-size: auto 23px; background-repeat: no-repeat; background-image: url("data:image/jpg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wgARCAFxBDsDASIAAhEBAxEB/8QAGgABAAMBAQEAAAAAAAAAAAAAAAQFBgMCAf/EABQBAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhADEAAAAr8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB5rizZ3maZlexpEeQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEPOGkpYd4ZydqPRRe7oVUe9GG0nXLG5Ud4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACnLLO1toVV9b9j59AAAcT7iZkA97TD68sAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4fUOvLxmxpFBPLB59AAAAAAAAAAAAAAAAAAAAAAAikqDQxDp7urYgzgAAAHAZD75Gu6dTMTfEM1IAAAAAAAAAAAAAAAAAAAAAAAAAAABxO0Wipy8qJN2Zf3uPZkLW6FNG0QxF3aZI2qhvgAAAAAAAAAAAAAAAAAAAeD3GpqMt6yTpyvufoAA50GgxBprTPaEEc9Y/58GwSACsotDlzbvn0AAAAAAAAAAAAAAAAAAAAAAAAAAI2YLOh+6Mz91efTz6AAABWWdeZfcYHdHQAAAAAAAAAAAAAAAAAArjtk+Uk4aWd3AAAAAB5PmNkQD5sOdiAARsfsMkbX78+gAAAAAAAAAAAAAAAAAAAAAAAA+H2qr6Y9TLC9PPUAAAAAFTbZspdzkdkfQAAAAAAAAAAAAAAAAAc8Rf5wmbCHPAAAAAB8PmU9Vh92HKyAAAI2O12SNx9AAAAAAAAAAAAAAAAAAAAAAAAcD7luXg86vrJAAAAAAAPmF1+NNLc8O4AAAAAAAAAAAAAAAAAPhkovbybL0AAAAAHzMdKY9a3xYgAAAEPJa7NGwAAAAAAAAAAOZ0UsM0zMQTX1ucll9ZZLWgAAADznpJdAAAEQ95DzZEDWd/YAAAAAAABmOPKWacAAAAAAAAAAAAAAAAAAGXg32ZN8gTwAAABQfc+fdUswAAAAfCPlpNSa6ZhZhs3j2AAOWeqTc+4E8Hw++KKjNr3yuqHmJmybys5R5nfPp8+ehX5HS5k1XGg5GtssXsDoAczpn4/0af59AABzPmQ98DtrucgAAAAAAAAAzni64lkAAAAAAAAAAAAAAAAAADlht7mjposXsT2AABQd8yfNF2twADnmp1Wa3159A4nzKdfRWWM29MfynVhprXFagnkU65njcmf7aaKWv35QkvP+NWU1XsMUXFpnLAjWVriSXcd7MAOWdLDL9NGVd7PGJ+bTPkiTl/hd0/e7It/9AAAHzJz8+e9jBuAAAAAAAAAAAAAAAAAAAAAAAAB8i5kv6ylnHnlc9Sk93PM5W+Zhm9Z+/PsSWMDofFGbxBnACpZo8aD3dgADn0oiluKHVFmVBKzHO9PF798FFd4/wBnONK8HzZ5CcW+b+acTkMo5uc+E/p61B46vhl6nt6J+o59DzitvFM5c0HA00GpsStsb2WR5AAAfH0AAAAIsrKFda1+0PYAAAAAAAAAAAAAAAB8PqDIOwAAAABzPeehwjxLt7sgWAAAfKi4GGnaTHm2+5fTH3K6v4YjV0EU21PHqjnpO84AAA442bWHva4rYETLSeJ70+Z+F7TefB9upVqcs7p4hi5d3bHGSCLKGGsdN6PPoAI3vsAAAAAAAAAAAABwIGX92pa2IAAAAAAAAAHz6AAAAAPkLLl5RdNUYmR3nGh+gAAABzyPeuO2t+SgAAAABFlDCaX3ljeIM454i5ryFouNebNlbYtHPoDyeqHxRH2zk15C++ZZ91frsefnsRsjdVRreoAAAAAAAAAAAAAAAAAAAAM3e4obKm0YAAAAAAAAApLHHn3ZZrVHoAhkxUW4AjyMyVMzhsRQK8bDlKAAAAFZY4sjaus04AAAAAAAy+oqDPya6WdNV66CNJGZqd54MP3u+RWRNH1MxorXoK6xFDeegA8+qMo9Jm9segAAAAAAAAAAAAAAAAAAADkUNJ0lmmkgAAAAAAAA8/cqRefLWEqQAjnnHdop32+c0gB8wu2wpoY1VLOWt+yAAAAAfCkofdwXnsAAAAAABUnXK/NGUnzZ481vWjvAAAAAAAADzjNJkjR3cWUAAAAAAAAAAAAAAAAAAAAIU3PFDp8zuTqAAAAAAAAUJwpQutLFlArDvkvN6VEbZZI10vn0BREvJe/R02eE1ZZgAPNOXTz6AEGdmCq3GX1gAAAAAA88coTaf3qjjbgqLeOZHZ4rQluAAAAAAB8+58qekLUlsAAAAAAAAAAAAAAAAAAAABk9XiD3tMnrQAAAAAAAUQovmuM1Fv8APG795iCXWd9aA5aAIWO3uMNBxzX0nxZ2iOM76MtVbumIltQxDUxKWaQNDNlAAHnF6zGGmt+HcAAAAAQ4GdPfuZqiPJAADM1uyxRufVNcgAAAAAinnHevpZ6fh3AAAAAAAAAAAAAAAAAAAAAPOF3eJJ2py2pAAAAAADznT1TfNOSZgQcfvuZhJms7EOaAD59ELrIAAAAAAAAFTl7apN37+fQAAARDvl4/A53s60AAAAGe0PkxGtzfI2rn0AAABBOmS88z3rPFiAAAAAAAAAAAAAAAAAAAAAAMRt8wc9XidsAAAAAPMPMEmB30wnAAAAAAAAAAAAAAABSZ2+ozc+ufQAAfImZLXPtIV2hkgAAAAADhjN1DM1rsT7Nsgyz2+eT2rq0mZn53Oeq7ygAAAAAAAAAAAAAAAAAAAAAABBnDAaPlQm/Z+/PoABVlnSU3E+WFtann2AAAAAAAAAAAAAAAAFZk9zizVWGTvCwU1UaehqbArLDQTiNJAAAAAAAACJldr5MH21FSQI1p1KXpprMzmh6AAAAAAAAAAAAAAAAAAAAAAAAAD5RXwwUrUUx07UXgvolVKOUe/tSi0PcAAAAAAAAAAAAAAAAAAIE8Y+LuvhjrLQCLKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//aAAwDAQACAAMAAAAh888888888888888888888888888888888888888888888884888888888888888888888888888888888888888804008888888888888888888888888888888888888888888888888888888888888808cMMY088888888888888888888888888888888s8888888888888888888888888844M8888Io8888888888888888888888888888888w40888888888888888888888888s8c8888QEo888888888888888888888888888840008soU88888888888888888888AMc88Y84sk8M888888888888888888888888888s0M88888M8888888888888888884Es8888s8U888Yc8888888888888888888888884sM888888QU888888888888888884cs888888ss888A0888888888888888888888884g08888888k888888888888888888sIc88884Qs8888Y8888888888848AY8888I8884Q888888884k8888888888888888888wc8884A088888II084sc4sUsMMsIoU88gM8880M88888888sE8888888488888884088YQ8880888s840ogs8AkYE4sYEc0EUsI00888YE888888888888888888888888wcgIU08E88kk88sg8kskYA4sQ0sokMw0cc88s8888wM88888888888888884w888888Ysc88socYM0k888s4AI4kcocs888c88Mc888888884gU888888888888888sU0c8884oc88888s0wMk8488IAEco088888888888888888888IU888888888kM88w88s4s8888s08888888s0M8McU0cM8sE88888888888888888888sw888888888kw88gc8Uw88888sUc8888884s4c88888888Ic88888888888888888888sA88888888oA08MI84cQ88w088E888888k4cs48888888o8c88888888888888888888g088888888Yc4MEAUQMsUkk88Ic88884k4c88Ic888888sU88888888888888888888848888888gU8ssc8sMc88s8888888884c8c888oY88888408888888888888888888888cY88888osc888888888888888gU88ww0888888Ik80wE888888888888888888888888sk88840U88888888888888888UYskIc888888884MYc888888888888888888888888888MY0c088888888888888888888Ms888888888888888888888888888888888888888888sc88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888/9oADAMBAAIAAwAAABBThQCBAwRBRwAAACBjCxwwzxwyQwhzyxSxwzyywzzxDDTzyCQQTyCAQAAADTzjzzzzjzzwgwABADjhjyigwihwzzCSDzTxyzzzTxDzzzzyzzzwwDzTxCjTxwgBAgAAACyzzzzzzzxiwBARBADzzQQSCRzzCzxwxizjzzzzzgjzzzzjTzzjiyzyhyijywwAywwDwzzzzzzzzzxDwgAgABjSjyzzzjDQiSzzygjjzzzzzzyzzzRAADShBzDzywjTwzzzzzjBTTTzzzzzzzxBABABTQByjTzzCSDhzzzyRygDzzzzzzjzzzwAAhxSAAhAzyyCABzzTChgzyBTzihjjzzgDywBTzzCTzyCCwzzzSygQTxjzzzzzxzzwTyAQCRgASxDTTDzTziiyTzzzyCjyTRwDwDzjwBRjjjTzyQARzzzxyBjzzyhzzzzzzjzhTxDzyhATgBADjzzzjwzzzzQgjwTzRyzTzzzzzxyzyjzyzTzzzzzyjATzzzDTzzzzzzyzzxzzjzzzyDBBSTxTBzzzywzhDDzTCzzzzzzjzxzzzzzygjTzzzySSzzzzzhTzzzzyzzzzziwxTzzzizzzDRwTzzTwDiATzxSgjzizDzzzzzzzzzyjhTzzzxQzzDzziwDTzjjTijCzzwyRTzzxxzzzzwzzzzTwQATBTwBBCBjSSzTzzzzzDTzxjDzzgxTzwzzhyQQzijTywThxxzjCwxgwzzziQizzzzzzzxxRzxSAQCwQizzzzyggRjhjzTzxTDzzhTgTRSiAhhxTxjQyyQRzyxBzzzwAjDzzTighTxzDjxzywCzzzzzzSRCzzzxxSwTjzzzgARCBiSzjzxjijzzwwjTzzTzzzziRzzzzzzwzzjSzzzzxwzzTzzyiDzzzzzyyDBRjDTACBzyiBzzzzzzzzzzzTjjzzzizTixjzzzzzzyzxgDzzjyzCiTzzzwAzzzzzzzwggSyjSwQxzyDDzzzzzyzzzzzzzzTzyjwRQBTzzzzzxzziRzjSzxzATzzzxQDzzzzzzzhzTTzyhzzzzhzzzzzzzzzzzjzzBzwDASgRTTzzzzzzzzhyzwiRzASzzzTyyBTzxzzzyChwwzzzzzzzzDDzzzzzzzzzzjzwgACAhCzwQTzzzzzzyAACgCziwhyhCQTzzTTzzzzCTBzygDzzzzzzwyzzzzjyzziAABzDwxCSBTzhzjzzzzzyjBxjzjCgBDjyjDzCxzzzzyCABTzzwyDzzzzyjzzzzzzywiwBBABTzASABDDwxzzzzzywzzzzzjzATQAAiDwShzzziyizzzzzzxhTDDAyzzzzzzCBgAAgBTAQDSwCQAzTjRDzzQCTzzzzzSSRTCAAASRCwDACyxzzzzzzzzwjSTjzzzzzzyTSiAABDADBDTiAAhTzzwhijSzzxDxTyzigARCCAAgzzxSTzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzyxzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz/xAAUEQEAAAAAAAAAAAAAAAAAAACg/9oACAECAQE/AEwf/8QAFBEBAAAAAAAAAAAAAAAAAAAAoP/aAAgBAwEBPwBMH//EAE4QAAEDAwEFBAYHBQYFAQcFAAECAwQFBhEABxIhMUETUWFxECAiMIGRCBQyQEKhwRUjM1KxJENQYoLRFiVyosLwNERTYJKy4WOEkNLx/9oACAEBAAE/AB73Gh6B6o9Tloejp78DHuMaHD0D0D1Rrr77Ohk8+Hq/H1hy9Tp6RrPo5+vnQ9I9YffR74Y6f/I2fnoa66HH9dAe4GuXpwfcD7jn1+GdD0+WuvvR6mMDWPRj1B9yz/gGPdD0D0D0+fqD1McdY9ONcvSPH08vSPug0PSPfjj6w9fOvjqdVIFMa7WdMjxkfzOuBI/PVb24WfS2lJjTlTnxwCY7SiB8Tgfnqq/SMlr3hS6WG/5S8QdJ+kRcH1Z5tVPjlxf8NwLwUfDHHStvV0rQ6nKQVjCSN32f+3Vv/SEqDKEM1iOl08i62gcPEgY1bN6Um6ITMiFJbJcz7BOCPh9wP3Ue88PcZ0OXLQ104666Ho6ax97H+B5AGVEDzOrg2k2nbPs1GsM9t0ZZy4v5Jzj46u36QdVmKMe2WRBZHOS8hK3F+STlKR55+GmIlyXlUD2Tc+qylHiolTmD4k8tULYPc1SSlVRaXTgf5uzVjzAXnUH6NsMEftCtvqGOP1dIH9QdH6N9C7JCRWagV7+VKwgZTjkBjnnrqLsCtNmKGHkPSFZ4vKdUlZ+AONXR9HqniKp63pklDqf7l4hYPkeGkKqlrVPCgtlxCvaTngrw1sx2oM3BT24c93EhpO6px1Y3j58O7rrn7/P+Ac/X6+jr6CcDQ9I9I+9j1OPp5e85+jGuXucavfaXQbGYKZrpkT1JBbhs/bUO8nkkeJ/PV47YLiuta2m1/s6CoD+zsq3jkdd/AOrF2YV2/XDJaIi09KsLmPgne7wgfiP5eOrc2C2tRX2pM1T9TeRxKH8dmT/0gcfjqFBh06MmNBisRY6fstMNhCR5AcPV5a2h7OaZdsFTyWQ3NQlW64hPE6rVIqNrVZcKQpTTyDkFJxkd+ti+1ET2mrbrUn+1JG5EdcP8QcfZz36BB5f4nn0j3A9A+/j71cV00W1IH12tz2orROEA5UtZ7kpHE/Aau/b5XayXI1BR+yoZ4dpwU8r48k/D56iwatcNQUI0eXUJjy8rKUqcUpSjzJ7zx4nWz3YOIbjNTusNOOA7wgDCkjwWeR8hphhmMyllhtDbaRhKEDAHkPcXLW2Ldt+ZVH/sMNKVjOMnoNVirSq7V5FTmqCpEhW8sgYHy1QJ7VMr8Gc+lZaYeStW4faGOo8Rz1a1ej3BTG5cc7yHEBYVjGfuHX3Xn7nr7v4+sP8ABMer5+jHu/j7vPoJAGSQAOZOr528UuhuuQLeabqcxPBUgq/cIPgR9s+XDx1VaxWrsq/1moypE+Y5wTvHO6OeEjkB4DhqxNhFSrC2Z1xEwoBG8GUn965//Uat61qNa0P6rR4LcZB+0QMqV5nmfc3Jc9JtOkqqdYlBhhJ3UgDKlqxwSkDmdbS9qEq/ZDTDTKotMYUVNtKOVKPerGm2nHlFLTa1qAzhIycacbW0socQpCxzSoYI+GtikOPH2Y0t1khS3krU4R39orh906enj6eejrp6o96PuD8hmM2XH3m2kD8S1AD89VrarZVCBEiux33B/dxCXz8SjIHxI1M+kjTg6oQ6LJUgE4U4pPtDocA8NOfSRrO+kt0SFujO8FLVk93lpP0ka4NzNDgHB9r94rj5d2ov0k08BLt9Y7y2+Ff1A1Qdslm1uMFuVVuA9yLMv2CPI8j8DqFOi1GKiTDfbfZWMpW2oKB+P3rrrPuOPqD3B9F87VKBY6Cy6v67UjgphMq9oA9VK4hI/Pw1d+065rxddRMnLjwFnhCjkoax3K6r/wBWfhqy9kdx3k2iW0hEKnE/+0yOG9g4ISnmTz8PHVk7Kbfs1pDoZRPqQOTMfaTlJ/yD8A/Px91d91QrOt6TV5pCkt4CGgcKcUeASNXpe9VvarKlT3lCOhSvq8fPstJPTxPAcdWjZtXvSrpp9KYKgMF59XBDKe9R/TmdWhYtEsukph06MguqSA/JWkFx495Pd4chr6QjTKbqp6mywHBG3VhIws+0SCfz19Hiu9vQJdHcSElhzfbI/EDz+7jXHXnocuOh6g9Xz1jQ1z9PXw9b4e8uHaHa9shQqNVZDqTgstHfXzx9kau36Qs2QSxbEYRm8YMiQkKX8ByGqxclZuCSuRVKi/JcXz31cB4ADgBoR3i4G0tLUs8khOSdN29WnVlDdJmqWOaQwrPyxqh7GL0rTg3qb9RZ6uS1bmP9PP8ALVM+jlQWmf8AmVUmyHSP7ndbSD8QdSPo42ytJ+r1SqNq6by0KH/2jVX+jfNZjqcpFcbkODky+1ub3+oE/wBNSGbl2f10sqck06Y2QcoUQlY7+5Q1Ye3mJKEam3K2Y72Nz64nihR6ZHTTbiHW0uNqCkKGUqScgj7qPU5a5/cc8dcc6vC/KHZMAPVWSA+tO8zEb9p1zpwHd4nA1dm3C57jQ5GhFFIhLPFEZRLqh4ucD8gNW3Zldu2WG6bDcUhROX1pIbB7t7v1s/2J0m20Nzq0luoVRKt5Oc9m14AdT4nQGB4eoOXq51c100u0aI5VKs+lptI9hvPtuq6JQOp/9HA1fV8VC+q4qfLT2LCfZjxkqylpPnwyT1OrMtd677oh0dtam0PLPaOhOdxIGSfy1btu0y1qO1S6TGSxGb4nHErV1Uo9SdHOdfSBoCH4LVaCP3rQS3nP4Qf/AM62AzJTd+GK0/uMPMK7RB/FgZGPf9fXx6QMeoPUH3MDx9UHOq/ddFtmIuRVJ7LIT+ArG+fIczraFtuqVbkmJbUiRT6eE7q3AQlx4/1SPjrOeJ1ZWy64LzWl+OwGacFYXKdUEjxAHMn4atfYJbdGX29WK6s90Q7wbT8Bz+OoNHptMaQ1BgRozaPspaaCceWBrA5+rdVm0i7qe5GqEZCnCnCHse0jy1elkVKyakiNNKXG3E77bqOR48vPWwzaQuS6zaNRTvOkKMV7PFWN9agr4cvc59+Pud137QLNjb9UnIS+oZbjoypxfwHIeJ1de3irVT91R0uQmt3BVvAbx6nHE/nqDTaxctTQzDjSZ0x9WBugqKj4k/rrZ9sJhU6N9cu1luVOKsojocJbbT4kY3j+WmI7MZlLTDSGm0jCUISEgDwA9I9FbrEShUp6oTnOzjt/aVjOqh9IyoIn/wDLaVGXFB4mQVbyx4YPDWz3bJBvSaabIgqhTsewkOb6XO/BwDw0DkZ9GNXHc1JtSlrqFWlJZaQPZHNSz3JHU6vO86pe9cXUak5hCcpjx0/YZRn7I8e89fkNWlas68K8zSoOErczvOKHsoAGcnVn2VSLKpSYdNZHaEDtn1fbdPef9vTtwhCTYz6lPbgbKVYPXjrZFI+q35DeSf3gO6jhzyCDoHI+78tA59x5a5+py0PQPcD11uIaQVuLCUgcSo4A1eu3uNFkSqdQY7jqkex9Z3glJPUg8eHw1WK7U6/MVLqcxyS8o5yo8B5DVuWTcF1rxSKct9AOC5kJSPMnVl/R+biyG5tzvpf3Rn6m39nP+Yg8dQoUenw2okRlLTDQ3UISOAHuduVFbqez2TJwntoJD6Ce7IB/I6s6tLt676XVUf8Au76Sod6TwUPkTppfaMoXgjeAPH1+fpHL1Ph7sD39TqkGjU52fUpTUWK0MrccUAB/+dX7t7M+NJpVtRt1hxO4qa99pQPPdR08z8tOOuPOKcdWpxxRypSjknzOrA2XVm+ni63/AGOmoPty3UnCj3IH4j+WrLsSkWRThHp6C4+oYckuAb6+OceA8PXqlNj1emSIMxCVsPIKFAjPDVbosukVqTAejOIWhxSUpKeJAJHDWw/ZvUo1XFzVeM5EbZSRFbcBStZIIKsZGBjoRxz6bxvOl2RRjUamtRClBDTLYypxXcPhk51eN4VO9a45Uqivh9llkH2WkdAP1OrTtSfd1YagQkkJKgHHSODYP/8Ah1Z9l0my6SmHTWN1agO2eJyp1XefU2sRTIsmetDSVupjPBJPMAo441YwcVe1JS2vdKpCQTjPDOmAQwgKOTjn96xrl6vLQz3eqOHP1s+556um96FZ8UPVac20tYy2wPacX5JHHHjq+dqVWvCYvsiqFBIASylWVHHeenkNUK3qrck9EKlQ3JDyjj2RwT5npqx9htFo8VD9wsNVKf8AynIbR8M8T4nTEdmKwlmOy2y0gYS22kJSB4Ae72yJDmzippTulW4FHJx7IUM6iupYlsOrSVJQtKiB1AOqDJ+uUCBIxjtGEKx8PU5e5z11n1x6ANdPRj3nTV67RKBY0UCpSFrmOJy1FYG86rx7gPEkeGdXTeNYu+pOTKnJJST7DCOCEDoAP11b1u1O6Ks3TKVHL0hYJxnASBzJPQasfYbRbacan1ZYqlQSkeytA7FtXelJ5+Z+Q0lIQkJSAAOQA5e4IzoJAOccfTV6vAoNKkVOpyEx4jCd5xxWeHHA4DmSSBjV93zUr4rS5Mt1QhtLX9Uj4wGkE8M96sYyfDVNp0qr1KNT4LRdlSXA20gdVHgNbObDYsehJjncXNc4vuJHNXh6t8tKXa8xecNNtLU7/wBONWnhV001olY7aQhnKOftKCf11DSlENlKElKQgYSenDl9+Hpzj1eXv9q21VFpwVU6krQqtuqGN5OQ03z3+4k8gP8AbVSqk6sT3J1RlOypTn2nXVbyjrZvs9nXjVkOdiP2eytJdcVxSefDn4aolv0y3oLcWnRGWUpSAVIQAVeJI9xn0Z9BwTx6a2+SOw2fvIS5hTshhBT3jKz+mmU7z7ad7dyoDPdx56ttztKBFJCQQkpwkYHAke+4e4HvzjW1HahFsaD9Ti4frb6MstY9lpPLfV+eB11UqlNq9Qen1CS5JlPK3nHXDkqP/rpqxNnNZvqelMVssU9KsPzVj2UeAH4j4DVrWjRrPpaIFIipbTgdo6ri46e9Sup/L3sybHp8NyVMebYYbGVrcUEgeZ1tV2nKvuaxEhtLZpERZW2lRwp5ZGN9Q6YGQB4nv1SaTOrlUYptNjrkS31brbaevn3Dx1sy2XQrFh/W5BRJrLycOv44NjJ9lHcOWT1x619081OzalG3lDLKlezz9n2v01Z7aEbRaAgrQpIqkfig+yf3iTgf000orRkjB7vej0D0D349THpHoAxj3UmS3Ea7V0hKAfaUpQSEjvJPTW0nbfMqMv8AZ1pS3o0JvIclpG6t5WfwdUp8eZ8OqESJ0tKEhx+S8vAAypS1E/mSdbNth6S63Vboa30JzuQlDgo96sH8tUylQaPDTEp8ZuOwnklAx8T3+956+kBdsedU27bilDn1ZTbshwH7LgSvCfk5nWzqzpN4XIzHSj+xtLH1h0jgjIUU58yk/LTLYZZQ2kAJSAAB6+PuA0Pe12sRqDRJdUlqAZjNKcPjjpqvVybcdblVWoOqcfkLKjk8EjPBI7gOWtnNhSL8rv1XtjHhtYVIeAyQO4eJ1SKTDodKj02A0GorCd1CR+vj7zPHUuVGgxHJMt5DLDQ3luLVuhI8TraptQkXvP8AqUJSmaLGWrs0gkdv3LWPhwHTOqdAk1WoR4EJouyZCw22gdSdbOtnVPsakpwy2uqvIxJkjJzxzujPIf19e/H3I9nVJxlhTriWVYSnu66t1RRc1OcbO6pMlCkZ7wcj89MAhhG9zxx/wkev1x6LhuWm2zA+tVGWwwn8Par3c+Wr/wBqlYvGU/GaeVHpJwlLCRjfA6qPn01bVrVa7aoKfSIqnncby1ZwlA7yTwGrK2W27ZqY8lmKl+qob3VzHMkk9SkE4Tnlw6e46+u8SGVEKCMA5Ueg79VyQmVXpz6HA4lb6yHB+Pj9r48/jr6PtCbi2iqrLTl6TIdCSU8QkbqcfNJ++dfTj1ieGdbfbuSzQm6AwpQXLUFO8PwJIP8AXGkIU4tKEJKlKOAAMk62S2y5bVlRmpCkLfe/eEpTjAJyBnr7195mMyp59xLbaBlS1HAGtr20w3hVTS6XIP7CjqGFAEdusfjI54HQfHUeO/LktxozLjz7qghtttJUpajyAA4k62WbL4tmUtqbOaDldfRl5ZOQyD+BPTh1PU+42ruFrZlXHME4ZHL/AKhq1lxm7opypat1gPDeJ6d35402ndbSnOcDGfu498PeXTdtLtGlqnVJ7dQFBO6nirj4av8AvaTfNwrnuo7KM3lEZo80ozwye/VrWlVLrqjUOAwohZ4uEeyB146si0IVnUBqDFZCXSAXl8CVK8T74ejajXRQdnlYkhzdccZMdojnvueyP65+Go0d6ZKajsILjzqwhCRzUonAGrQorVv2rApzSNwob33BnP7xR3l/9xP3rp7sgEbp4jOflrbPLbk7QpaG173Y+woY5Hn+urRbbfueDHcSpXbOpaSEnjlSgOHz1ToiIMBmO2SUoTjJPH3ZPHGnpDMaOt+Q6htpAypa1YAHeTrattgeuZbtEoLi2aMDuuvclSv1Cc9OvXu1Q6FU7iqjVPpMR2TJcUMBA4J4/aUeg8TrZ3sxpNj0xla2GZNZUMvTFIBKSRxS2T9lPTx69w9xtQGbAqaTu7qkgK3/ALON4c9WnDTPuimxljIclMp+biR/QnQOQD954AZ1Wrvt63WEvVarRoyFfZyreKvIJyTqufSEt2C4pmnQ5k5SeBUkoQg+ROc/LVgbYaZes805yOqFN3CtCFK3gsDng491kA41GqcGa+8xGlNPOsndcShQJSe4+5vK8qZZVGVUKi5zyGmUn23lfyp8fHpq8Lyqd51hc6epKEZ/dsI+y2OnmfE/lq1LFrt3yUIpkJSmSrdU+v2UJxz46sezYlnUVqK0hCpG5h1xI5nOffjWdbd7scqFZ/YDagWIzvaKx0ITgD81H462GQUzNp0JxbW+iO047n+U7uAfz9OMep4+kffHhvNLSDxKTraowpu8lOq4l9kLKh+JQUpJPzSdbOZdNh3jFVVUv/VlApCmT7SFcwr8sfHQ4j3Xnr+nfrbLtUFWfetqhupVBaWBIlNqz2qh+FPgD164+cGDJqU5iDCZU9KkLDbTaOalE8BrZPs4NhUqQ5KeDtRnBBfCfst7ucJB6/aPH3W0ltLtgVRKhlJQnI/1jWyWE3NvuIlxBUloh5JHRSFAjSfsj7rUa3TqVuiZJQ2pX2U8yfhq5vpDUimvri0OnO1FxCt0vOr7NrzHMn5DUW7NrV/pzS0PMx0cS4w12TaiOm8eflnX/C21qJSTLcrU1og5+rKmLKz8OI1Ju68p0gU5dTqLj6T2fYtuLUokcMYBOdVWn1WDI/5tGlsvr6SkqSs+e9x1a9mUWqUBVSqNWW08FHEZAA9kdcnWyO35svaExIjo3mYLn71STyyCNJG6nHX3BISCScAcydbY9qxkvG3bfmBTbZImSmx9pQ4biD3DqR8+edhFmVOnxnrnqrz6VTmwlhhajlSM/bVnv6eHn6w9F+35TLFo/wBZmEuyneEeMg4U4f0A79XLctSuytOVWqvByQtIThIwlKQMAAf+uetj2ypm6Aqt1tsmmoJQ0wQR2x/mz3A/mNUulwqLTmYFOjojxWU7qG0DAHvuXpPA5OOGtq7jzu0irOOqCt5Y3MdE4wNfR43BeUkHBWqOogHmAngT/wB3pHuQPvRGflrblEXTXaLTlne7H6w7kf8A6ikn9DrZ/NRT72gSFhJAS6gBRwCVNLSOPmRps5bTyz1x3+6KeOc8tbX9sCUpmWvbqwVHLUuclWQB1Q3jr0J6cQO8U+BKqlQYgwmVvSX1hDbaBkknWyvZWzZMMzamGZFadOe0RkhhOPspPU88n/b3d+MLmWnJiIJT26kpKh+EBQOfy1Z9Qatm53XXH2yw0vjIGcKKFAkJPXOo22S1VlCBPSpIGCrcUP01R7mpNdQlVPmNvBQynHUe4qNy0WlIWqZU4zZQMqR2gKvkOOqZV4NYjB+C+HWz4EH5H1arWqbRIqpNTmx4rI/E84E5+erfu+j3MFGlykvhI4lPL01KpQ6RAenTn0MR2klS1rUAANX1t7qFScXAtMLhxsgfW1J/euf9IP2R+flq2tkF3XxI/aNwSpMNk8C9P31vrGeQSrjjnzOrb2RWdbIC2qaJsnBBfnYdV8Ekbo+AzpKUoSEISEpAwABgAaejtSWlNvJ30K4FJ66iU2FAb3IkVllOQSEIAyeWdbXqVCkWXKnuwmnJEfdKHlDi2MjJ0p1xZypR/wBtbF6HSKXbTM+Oomoy2EuSN9eSOeSPD/bV5/SBh02WuDbUVM5bayhyU4rDRwfwYzvDnx4DuzrZptNVeZVGlNIRJSje9gEct3OR5q9YkJSSTgDidbW9r7yX3qBbrwSkoAflo58RxSnu4ddbJNlUmt1NisVmLuUtr20Nr4FxXTh3ddIQlptLaEhKEgJSkcgB09eu12Bb1NXOqD7bLSBklZ7tbRryXe11O1BO+mK2C3HSrogE8cdM8NbOLLXeFxtxno7yoaUqW4UeyDjpveeqBRY1Ao0enRUgNtJxw6nr9w6+gjeSQeWttOz2oNLk3WgtGM2EIeSDgjOAD8yPnr6O6O2vN/2TiPCeXnplSmgPyCvXz6nL1fl93272u3U7edrAKzIgo3kpSOG7vAKz8NNuFpwLSSCORGtlVyquG2yp14OuMkAkDp7niT+utrm2JtDb1u2xKcEhLhblzG+ATjIKEHqc8yPhpllx95DTSCtxZwlKRxOtkuzBqy6eajUUodrUlI3iR/7On+RJ7+8+pnjreA6j1pMliHHXIkvNsstjeW44oJSkd5J1tV2tLuh1yk0Nx5mlpOHHQrdMjwI6Jz8/QDngScasC6JFtXTDcRlyOtzcU0rJIB4cAOvHVIqSKrTm5TYI3uBB5g+q662w0p11aUNoGVKUcADvJ1tL201Kp1J2l21LXCprR3VyEDDjx68eaUjw4nT1SqU6ShyRNlyXs+ypx1S1Z8MnWzKmPQqP2jyHEqWkH2+Z6cv9I9MuZGgRXJUyQ1HjtjK3XVhKUjvJPLV+bfFBcmm2sgYHsfXyc58UD9dVGrVCsSjJqU1+W7/M84VfLu1sXrkqnXCy0GguMtZQo72MEg6ScpB79X9tIpFiQN6QpMmoOfwYaF4UrxP8o8TpU69trlfMXtnpW8rf7IEpjxx0JHIAd5yT46szZFQbBUK3WZzcuWyMh51IQ0ye8Ak8fE6hbT7RqFRVAiVZDklJUN0JVx3eeDjTTiH0BxCgpChwI6+p9IWRMatFhtD5RFdkJQ42B/EI9oZ8iPQ3cdWZpztPZnyERHcbzQdVj+vD0bP7wetC5I8w+3GOUuIJxgHhnVFq8auUmPUYiwtl5OUlJyD6lZrlNt+AqdVZjcWMk4K19/d462kbZqhczz1JoC3ItJVltSwP3kkHhx7knuHHv7tbI9mEmqVpFUq8ZbcaIsKS2sDBWOigePPppllthsNtpCUDkB69Yq8ShUt+oz3ksxWBla1HgNbRNocy9qikJccRT2x+7aUAOJxnl0yOHlq0bWm3bXmadEbWQo5cWkcEpHE6te0qda0FtiK2kupQEqdxxOB7zPpGuXpxraNbdTuy1pFGp8ttgvKSVFxOQoAg4z05DWyvZj/wDHkyJclEioygErU2DuoQDkJGfHn6R6enoHo6egfe7jpkeq0KbEfQhSXmFt+0OWRqYwY019gjHZuKR8jjX0eq2tFSqVMX2IbWhLqMn287x+Y4+45a2wbXno7z9tW68W1JyiZLTzB6oR3eJ+WuGOfHu1sX2VOQA3c1fjKRJOfqsR5vCmum+oHkT0GPVrdSTSqPKmq/uWyrGqFtOqk29FVSZ2zqFSBuNpVhDTfEY1DkolxUPNqCkqGQR6l23XT7OoTtUqCiUp9ltpJ9p1Z5JHjq87nqV5yHanVZLraUEfV4SUq7NsYwfidRmFSZCGU81HnjVH2OXBWmkvNN9mwsZS4oj+mrrsQ2mtDcqoNuOLHBtKfa1FU1AkN7iV75G+h1X4NWFtLt1mnogv1FoOrX7IUr2lKOoVSi1BpLkdzeChkcMZHpuK46Za1IcqVUfDTCCAO9RPIAdTq+tqlZvr+w01p+LAKhvtoOS4c+yCQPy1T7MuCp9oY1MeUhvitZGAnVj268/d8NEhpCkJdKFIWeZwdRWRHjNtDPsjHE59G0HbVSrReeplNa/aNXRlKk5w0yr/MeZP8AlHxI1Urhu/aBJLc6fJnYO8GEkJbB8G04BPkCdW79HyqSmWplcnNQ2sb64wTlZ8Cc4GrrgU+l3NOhUp9T8Jle624rmeAz+edfR+gyJleku7iDFjjfJUPxEY4a2m7VYNmQ1wIK0SK24nCGujII4LV0+HXVq7Ork2iTjVpj60xH3CXJ0hW8t0jgQkHiT07tVa/rW2RRH7YtynrkVBr2nFK+z2h/+IrOScY4D8tOVm79olQQzKmSpSBhJSgYSkeQwNbPdjIpraJlbbR2wJ3WyMqA8SOA022lptKEDCUjAHqbcbvozFmSaKmRHfqUlaAhjG8UJByV+HAYHn6NmWyuoXXUBLqEZcelNjPaOpwHT3AczqdshtWfREU5yHubnFLrR3FBXfq77Jq9m1JUeewoslR7J9IylY/Q6tm8q7aMxMikTnGh+JlRJbX5p5fHnq2/pDQ5aA3XaYIzoHByO6ClXwVjHzOnNt9pNoKu0eJ7gto/0Xqv/SOKmy1QaOUqP9/KXy8kj9Tqv3ZX7vlocq9QelrB/dt8AhPkkcBrZVsf3uwrlcQk/iajqH2fE/lpiOzFZSyw0htpPBKEDAHw9eTJZiMLefWENoTvKUeQGtq+0V67quuDCkqNIjrO5unAdP8AMe8d2qLSZNdrUOlwwC/KdDac8hnmT4AZJ8tWRYtOsmkNw4uXXhkrfVzWo8z4dOHh91Hqj1OXrD0cPf5GSO7QdSSRxGO8aS6hROCDj1nmUPtltxIKT01tq2eRbfd/b0BeG5T5DjXsgJJ6geetnlwf8N3U3NK0oRuEKUoZAAwr/wAdUeqMVimNTYyt5twcD62dbW9rSLdZVRaE+05VHBh5wcfqw7iOW8R06aAfmywEpW9IfcwABvKWsn8ySfz1sv2NR7Y7OsV4My6sQFNNAbzcby/mV49Onf623e8VwaSKNCd3XJB3HSk8k8yNbK6aupVdEYtJWw+8G3M9wSTqFFbhQ2o7QAQ2ndAHpum6KbaNEeqdSeCUIHsNg+04rolI79TrzqN83S3UKgEJbSlaY7Sx+7YR1Oep8dQtltxXZU4yI6AzD7PCpzp9gJ6AAHJPhp7ZfTdnz0B5yeahNku9mlKmt0KGPbAGT01TXEPwI7je7uqbChu8BrbJUXTtDmpfSg/VUIbaSR0Iz+unX1LbSntFK89WmqK3PDjzSXHUKBQCnOrAnibT2w1gHcB+zjhvH0XxfVLsajLmTVhyQoYYipVhTqu7wHjqfVLk2kVxp2quOv8AE9lGZSPYB/lR3cBx1aew+mxojD1Vcf7QhK1NJ9g7w7yCeHhq7U02z7AqTkMIhpbZV2QByVL6DjzOtjFCaTTHay/hct07p3kYKe/TzzUdlbz7iG2m0lS1rOEpA4kk9Bq/9u7Uth6kWit1pSyUrqa/Y3Ujn2Y58e848B1FEtaq3PVjCo0R2ovlWVOD2WwPxFSjwHnnj462f2FBseiIjoShyc4N6Q/jiVdwPPA1ftfatuz5s9x1Lat3s2yo4ypXAaeeL8hx5zipaipWPE51Tr8q1MhtxoZ7JTY3W1oUcp+Gtm+yOXdkldwXSt9MdSt9tBIKpB6knoNVRce2bVlvRW0oRFYUptA4DI5fnqVKkVKe9KkLU7IkOFa1HmpRPHWxehQIVqRqhFUpS3m8L3k4wrJz6lduWj21BMyrz2orOcArOSo9wA4nV/bdKlW1uwLd7SBT84Ejk84P/Eap9OqNfqiI0Vp2VLfVjqok95Otnmw+Fb62qlcHZTagn2kNDJbbP6nz0lKUJCUpCUjkAMAeio0uHVYxjzGEutk5wdX5sIeiOKmWyXH0OKyYpSMN+Rzy1ULZrVLceRLp0hHYq3FqCCUg+emqJVXnAhqmTFrPIJYUc/lq29k92XJILbUAw2knCnpeUJH5En5asfYfTLZkNzqnJTUZqeIHZ7rafIEnOkpShISkBKQOAA5eupQSkqJwAMk6257RFNQf+GKcps/XGkuSnEq9pCc/Yx0zjj4eemWXJDqWmkFa1HCUjrrZFspVbL4rtVAM/dKGUg/YB4E+eOH3Me5H3eRIZisqdfcS22kZKlHGNXPtstqgNFMdTk6UU5Q2hJSD5k6qH0h6o+7mJS0Mp6ZfP9MaqO0+66g+XBVpcdBVnsmZTu6R3HKzkaReFyNJKWa7UWkE53USVgZ+ek7RLsQncRXZqW93d7PtVFPngnTG1S7YrrTseqONLScqwchfmDkaoX0g5pWyirsDeBwtSd0IUO84GQdWztDt+6I7S4sxtDrg/hOLAUD3Y0DkZHL07QrZ/wCJ7QqENvJf7FSmgPxKHED5jTzK47ymlghST1GPI/LWwy9w9CcpU5YT2AQ2ggc8qVhR+ePVPActbWdqSbbZcoVHX2lWdR+8W2cmOOBOR3lOcd2c6f7VbqnH1qW64SpRUd5ROTkk9+c62JbMFsFu6K9DUh1JzCYdBBTjk4R88Z8/Wr1XZoVGkVB4ZS0BhPeScAauutvVuvOuvkrDK1A+1vb3tcT8eGti1DLsxmodnhkAuJV35Lg/8PTtC2kUywacFOhMmpPD9xDSvClD+ZR6J8euq1cNZ2gXGl+puuLLhIZZbHsoHckfDnqz9jQlvxqjUVrjxhhz6vuAZXx9k8eAGo0ZqJHQwygJbQkJSB0A1flzLnbWmYLT6nI8TcZUhCd7dBUO1Pny+WokuJTreEx95LUNlkuqcWN0IQBnj5DV9XMbvu+bVwgoadUEtIPMJAwPRb9KqNaqLcKnDDilJUV5xuAdT4atqhs0SnpYaThIASkk5JA6nx1tF2q0uxWvqzaRMq6xlEUKwEj+ZR6Dw66kOVi+a4uq1NTrz8h1IShtHA+CR0AA1YthsW4lUp5GZLnEbxypI7idLWG0FSuQ7tbbtoDlfuJdBgPEUynrKFqQf4zvDez4JIwPEE92rH2oWpbOz6KZs1Qk5OYiElTgOenh462gbU6xfTyox/slJCgUREHO9jkVnqfDl/XWzHZO/exRUZy1MUhOUlTZAW4faGB5EDVDt2kW3C+qUiAxEaPFXZoAKz3qPU+elKCElR5DW3S9Hq5cxoLXswaavPD+8cUkZJ8skfE+jYts6VcFRbr07Ap8ZzKEY/iKGfyB0hCG0BCEhKRyAHAaqcMT6c9GUAQ4nGD11dtuz7TuaRAmMhpSV9oyU8UqQSd0p8Onw1s42tzbKH1GY0uXSzxDaSAts+BPTUDb1Z0mIXZD70Z0Di0ppSj8CBx0/t8sdlIKJMx84+y1FP8A5Y1c30iX5UdTNvU5yMpWR20kpJHPkkZHd11NqNbuyqBUhcifLc+yhKSo/ADVk7CqtXE/Wa921NjZwG8DtFfA5xq2LHoNoRUM0qGELAwXlqKlq78n1eOlR2lc0gjuIGNfVI/E/V2snn7A46ACUgAYHuDq/bthWfbT06Uf3i8tsIIJ314yB+WqnUH6tVJVQknL0l1Tq8csk5wPDWw+zZFQuRNUlsKTEYQHW1EfbPHHuMep1+7ce70Z98NXltBodnQHHJkxBlbmWoyDlxZ6YT3eJ4au/apcd3OONuyDEgrx/ZWDgHzPM6QhbiwhCVKUeSUjJOqFskvGudm4ikuxo6/72SQjh5Hj+WoH0dQhQMyoFzHNKeR/odI+j3R3HQVvqaR1SkKOf+86Z+jvbragXZkt0Z4pCt3VT+jlBceW7TqvJZbP2WVtJXj47w1d2y24LSU666yZUJs5MhpBwlPeru+eokyXSpyJMV1yPJaOUqTwUk62d7dw2E0y6wo5VhucjkB/KpP66jyGZcdD8d1DrKxlK0KyFDwPp2zbLA2JNzUggIbQFSIoHEjOCpPl1GqVVpVGmplRF7q048jg5H562eX/ABLwpDJWUNTcFKmwr7WOo+XqbVdrrFsNPUShqS9WlDdW5jKI2eee9XcOnXu0greWZL4ekTZLmQoneKio8SepJOdbMti6Iq0V6644VNUoqZgYG613KVg8T4dP6DgMDl630grwbZgx7aiuZkOLDz+6eKEj7PxJP5aiqKXRupJWeCR3nWxWG4iyYjjzZSsb32uf2ln/AMvRtD24U221PUyghFQqqSULdJ/csK8T+NQ7hw7zwxqTUplerCqlVJTkqe+oKcUrdBVgAJA6A8MYA4a2N7N1wWE16pIwp1JDDahx3CT8hyOhwGBy1VKlFpFNfnTHkssMoKlrUeQGpd2zFXfNrsPebdelKeQFK30pyrIGqtdlw3DR4tIl1FxUMb7imkgBK8Hhk9df8HT5jjbFPQ5IkFO/2YbUNxvvP/rrquWlWLcLIqsdMdToylJWCfy1Z9wt2xU2KgttLqQ4O0TubysceWdXdt1rdbQ1Dt1DtLYGN53eCnXeHLOMJHlq17Qrd5VdH1P9+7vBx5x1zJHtYJOeJ1YOzWFZjZedeEyerk8UYDY7k+jaLcxtm2JUtJCXA0vsyf8A4m6dz89PvOyX3H3llx11ZWtaualE5JPx9GyLZm7dNURVKigopcc7wSR/GPQDwzqHDjU+KiLEYQyw3wQ22nAHkPQ+gOMqQocCMHV2092l3ZU4jyipaJCiVK5nJz+urNtp+67miUplKt1xX71aUk7iepOqBQ4duUWPS4LYQwwnAHeep9N62bAu+kGJJZb7RIUW3CjJQd1QBHxOrj2a3Fb05xlUNchhKgEvtYUk5OB+elW3XUN9oqi1FKP5jFXj541As+5am72cKg1F5QO6d2MrCT4nGB8dWx9HuvVJKH65LapjJ5tJ/eu/l7I+Z1aezm3bOTvU2JmQU4W+6d5Sv9vcD3S1pbQVrUEpSMkk8tbaL2cuW4/2Yy5mFAUQN3ktZAyfhy1ZVrTbtuWNT4jalJCgt9YTkIQDxJ1SaXEo1LjU6CylmPHQEIQkcAB6B906+8fksxwkur3cnA4aqW1uz6Y4UrqbbxScKDK0qIHlnjqh3TQ7kaU5SKixK3QFKCFe0kHkSOY97JksQ465El1DTLaSpa1nASO8nV+7fZT0lyn2klLTCDhU9xO8pz/oSRgDxOc9w1JkyJshciU+6++4crddWVKUe8k8TqxtnVYvecERkFiEk/vZS0+ynwA6nVmbIbetMiQpgTZgOUuyEhRR5cOGgAkYA4eq8y3IZWy82hxpwFK0LSFJUDzBB5jV7bB6LVmXplvf8tqBO8GclTCu8YwSn4cPDVftesWvM+rVWIplfNKgQpKh3gjWy3ajMtaUmmS19pT3ThO+rCWj38tRZTMxhDzDiVoUMgpPD0SorM2K7GkNpcZdSULQocCDzGtqmytyzlipU8hymOEAjq2fEd2rcuafbc1D8N5aAFbxAPhjWz3aHAvOmpQp5tFUaGH2OR4dR4ejaptcFCK6BbriXKu57Dj4IxHz3Z5q/pqLCkSJRT2TkmouKBS39tS1K7+862S7LU2vFbrNZRv1p0ZCFYIjA9B4kcz69zXFBtiiyKlPc3W20FQSOayOg1c1bXc9wzqw/lDsl0qCTyCeg+WqI12tbiIycb4P66tWOiLbcFtAwA0Pw7v5a27XpKty3o1MpsosTKgpQWpBwpLQ547sk4z6LZchN3BEcqCUmKFYWCrHTUfbPY8OAWxMU0iM2lKGksnKgOACRqr/AEjqa0lSaRSH5C8eyp9QQnPwydXTtBuK8H1/tGar6uogiM3wbT8OuqHRlVN5LeHDv8ko1Z2x+rrYYXUlIhoT/KcuFPdqh29CoEERoqVK/mccOVKPidbf/rKrjjlxBSwN4IPfwGsKJAIycDGrXsWu3DLaXEiuNtBYysgjHlqyrTj2nRURWypx5XtOOL+0o+fpv+31XFbMiEhvfWpKgAOfEYzqdbFXhzVx/wBnS1DfKUHsjx7vLVgbEqpWZjcq4GVRKbu727kb6+4c+GocKNT4rcaIyhllsYShAwAPSRkY1XrDoNxyWn6hBYcU2c8Wkne8+GqJa1EtxChSadHi74wotpwT8fVU2heN9CVY4jI0G2xyQkeQ0G0pAwM45FRJ/rrP3Pa5tGRbVMfp0Rw/tN4hLG6P4eMFSjnzwB46W4t51Ti1KW4slSlE5JJ6nWx6zGLYtZuUWyJ01AU+ojjwJwPz+4D1+XupEhmIwt59wIQhJUonoNX9t1iUoKgW1uSpoxvSFDLbfeMfiOq7d1yXY4o1KfJkozvdijg2n/SOGloU2tSFpKVJOCkjBB7tWTXn7duiJObWsNoXl1KVYBSAeJ8ueor6ZMRl9IIDiAoA+I93V6zAoNNeqFTkpjxWhlS1dPlz1tJ2pzL4e+qR21RqW2r2W8+053FX+2qRRKjXZyIdNiuSHlnACRwHmeQ1s92DopcxNTuhbMlxABaiNklCT3qPXy1GjMQ2EsRmUNNJ4JQgYA9zdFrUy7KM9TqkwlaVj2VjgpBHEEHV4WlPs2vvUyalSkpOWX93CXUnkR/trY/tFm0SZ+yZID0JZBSAPbSePI9dQ5jE+G1Kjr32nUhSVYxkH0SorE2M5GktJdZcSUrQoZCh3HW1nZoqz6kJtObzSXsAccltXUHw1Zl1qtSts1JKCtbZA4AfZ66u/b+mTRRDtxlxEx5vDklSd3sj13R1PjqhxW35hUEKmS9zfLiQteFq5Zx11s/sdig0xmZOjoVU3BkrUMqbB/Dn1yQBk8hrbZeouO7FU+DKLlOgDsxu/ZU5+I+PHh8NMsOPq3W05Pnqh7grMftN/G8eCefLSrvolt2jHqE+UhhgMgttH7Z4cAE886ve7pd63K/VpKezQfYZaB4NoHIefU6gU2XVJCWITJddPDdCgP66cs64GUFa6a4Ejmd5Jx+ehbdZUlK/2e7unkrhx/PSLFuV2OZDVKedaCtzeQAeOpVCqEGQqPJjlDgOOJ1shs2PApzVWdwt4I7NHDG6cnJ9N7WZHu+AmM6vcKVbwJRvaoX0f6NFfD9VlLlk/wB2lBbGfMKOqVRqfRIaYtOjIYZSOATxJ8yeJ9UQYva9r2CCv+YjJ9PP3mO/0Y+4XdcKLbtydUMpLzTC1toPUgcPzxqsVebXam9UJ76npDh4qV3DlrYxswj3GU3FVHMw47uGY6T/ABFDqo9AOHDSEJQgISMJHAD7mVY56MllKwguoClck54n4e82i7R6dYlPSHP31RfH7mOk8SOqj3DVwX9cdxuu/XapJ7Bzmwhe6jHiBjOrIsGpXjIxFQOzSoAuKI3U/wDUOeNW9aNGteiNwm2GVpQjC3HUJyrvzw5a2q1ajVG6Owoaf7LGTuKWFEhS+uM9BrY3s7gVJhNUqMftVDjhR5A5AGNABIAAwBwHuRqrVeDQqc9UKhISxGaSVKWrlw/XW0XaBOvquOOqcdbpbKz9UiqP2By3jjmo/ly1ZNnVG9a+1ToTS+yBCpL+PZZR3k954gDVpWNRLMg/V6VGIWo5W84d5az4n3l/WZGvS3JEBxKBKDalRnVfgc6fDv0tFVtqq7i0SIU5lXtIWN0g5I5dRrYvekeuUp+C/JR9caWVBsp3Tunl5+mu0+LUqS/GltoW0ocl8s9NVuEzTq3NiRnu2jNPrQy7/OgKIB+WhwOtgFPjLp6p8hTRf3lNspwnPDn4+vy1th2uGMty3bckkPoUUy5KPw/5Env7zqFEcmykMtoKt5QBx0GcauakQbPtVBZktGc+vcQ1zWkDmTpt5bTodQohYOQdSpkma5vyX3HCOW+oqx4Du1YFjVO9KsWIjaUxkJJeed+wnu8znVsWdTLYpzcaKyjeTzWBjOnadEeTuuMpUPHRpFPIAMRsjxGrmnwLYoEmctCW0JO8AOqumo1Wfn3GZTqO0S++FLbz9olWrbaS1b8IJj/V0llJDX8vDl70ffVLShO8o4Hfrblf7FVcbt6luZZQoLlLTyUR9lP6/DVMgOVKpR4bSSVOrCTjoOp+AzrZ/biLXtKNT0pKTkrUknOCT9026X9Ko7abep7hbfkN5ecSeIQeY+P66otw1ekVBuRAnPNOhWc53vyOrLrCq9aFLqLq0qeejoU7u/zY4+6vW52LRtSdV3uKmkbrSP5nDwSPn/TVWq86uVJ2fUpK5El0+0tZz5Adw1s42cy73nlalFqCypPaLx9rwHy1QLdplr0pEOAyhlpscVd/iTra5tdNZcXQrdkLRBbUQ/JR7JeI6J648eurAs1+9Ljap6DusgFbqs8d0d2rbt+NbVGZp0YlQQPbcPNaupPulKCPaJwNbZtoEi5rjkUaI9ijwHOzSlJ4OuJ4KWfDOQPAZ66plOkVeqRadESFSJLqWmweWSccfDVh2XDsa226XHUHniouSJG5ul1Z6nwAwAPD321/Z61dVuPVCIj/AJtBRvtHH8RsZJb/AFHiPHVLqUmjVNidFWUPsrCh/trZvf7F50tO8CmU2kBYxzOnXW2GluurS22gFSlqOAkDmSdbSNrDty9rRLaWtmnpUpEib1eHcjw5+eresOpXZuM0eKiQ23/Gf7UJA+ej9HirM06U8J0B6SpnLTBSsbqxxwFBQHHlk556eq91WSY9JfZfprrKhIbacyeefa3VZHf01am2Wq0OC2xKmyJS0ryUutJUnd/lzvAjVC2325ObT+0nhDWtQCCoEg5/pqNXqRMGY1TiPcM+w8k/rpK0rGUqBHgdEgc9Tp8OmwnJk6S1HitjK3nVhKUjxJ1tP23NzI5pFoyV9mo/v54SU5GPsoyM+Z4cuHfpll2VJQ02Ct1xWABxJJ1s+2R1BLKJ01xKCAFpSniFd6Tx1tUbqEa8nYk5tTaWUfuW/wAKUEkjHosSyKjedZbZjRlqiNqHbunglI7s6te2odr0VinxEJHZpwtaRjeV1Pz9T6RFf7Kl0ykMucJK1OuYP8nD+pPy1szokmsXdFEeOh0sq38LXujIBUMePs4+OkDCEjGMD7tn08tZ94PTkauisxqHbUqoSVoCUt5QFKxvK6DVVmGo1SRKKd3tFZA3t7AHAcfIa2CWiips1GryGt0JeabYdBwoBJKl4+PZ/LQAAAHIfc73vul2NSfrc3eceXlLLCPtLV+g1cdfl3NXJFVm7gefIJSgYSnhjA1sx2Xu3i61UH5RZhNrO8Ep9o47vjqBCap0FmIwkJbaSEpAHqX1tBpli09qRMy68/nsI6PtOY5+QGeZ79Wvt3pVdmCJLiGG8s/u0lRVvHuyBz0y6l9lDqDlC0hQPgfU+kFdaqhcbNvMLIYgJ3nx0U4oAj5D+urJt5V03XEpSSAHSSc9wGdUSkwrZoLMVpLbLTDe84ocBkDidbWNry6k87RLZlKRCxuSZbZwX/8AKk9B49f62lZFSuyW0mMn+zdoEuuA8UjPE41Zth0WzIqk02KEvOfbeX7TmM53d7u90SNbY73ctS322ohBmTAptAJ+ykpIKvhoDJAA462QbNY9qUZmq1CNmuSkZX2o4x0n8Ce44xk+/Izz1tt2fw7YqbVWpZCIkxWHI5P8JeOY8Dqh3jU7fXEVDUkCMpRHDid4gkZ+Gry2r1u+o4p7wRApaSFONMkkuYPDePXy5asm0598VEU+nxQ1EQd9+Ssew2N7h5nw1atrU60aIzS6aghtAypxX2nFdSfRdljUS82WU1WMFOsHLTyeCk94z3Hu1eOwer05a5dFWZzJ49kEBKk+QH6DUqDPprimpcaRHVyKXW1I/IjVMrM+kPdrCkuMqxjKFYI1A2nXlTl7zNekqH8ruHB8lA6qe129ar/ErC2RjH7hAR/QanVepVTd+v1CVL3fs9u8pePLJ8B8tUeh1Gv1BqDTYrj77pwkJHDzJ6asHYbTqU0xULhBkz0neDKVkIR545nTTTbDSGmkJQ2gBKUpGAB3Y1tK2ZsX02l5Cvq89pO62/je4dQRvAatX6PCWKgmRcc9EiOggiMwCkL81Zzjy1Ap8SlwmocCO3HjNDCGm04SkepUZjcGEuQ6rdQnmdXfX3LnuqdVVjAeXhtOc7qEjCR8hrYvZDNu223UpCP+YzUBThP4EnilPyIz77HH7yPTy49NbfbheRUmKQ07uhbaXFBB5t7vDPmoufDUeOuTIQy2MqWoJHhk446sS3o1s2jBpsYHcbBVvqOSsqOSo+effdfVnz4tMgvTZshDEZlJW44s4CR3nW0G7TeN1yakgOJjZKWELPEJ7yOhxj5DVsUCVcVaYhRmlrySVqA4JABPH5as22mLWoLcBlCUnJUrd6n1L5vKFZVAcqEpQLispZaz7Tiu4f11Wa3UbgqS6hU5K5ElYAKldABgADoNWfCXULtprKFLQUvdrvIHFIQCskf/AE6js9hHQ1ne3RjPf6ZclqFEdlPq3WmkFazjOAOeq7WHq9cE6ryEJDsx9TykJ5J3jndHly+Gvo9tUluLWZqN1EgqbRlxSctp3T17ic/LW1na4/XJEmgUJ/s6Wklp95PORjgQD/J/Xy1Zlm1C8au3EhhTbefbf3chHDOrLs2n2bQY9Pip33EAqcePNayBvHwzge65anS2KdAfmyVpbjx21OOLP4UgZJ1fN4Sr2uV6qyGw03jcZZH4EDl5nqdbC7BbuCsOV+pNb0GnrHYtrT7LzvH8k8D5kfcdvtSpbVoIgSnyJbzgUy2lO8Tg8T4D0bOLYTdt5wqa8FfVCSuQQfwAE4+OqLQqZbtORApUNuLHTx3UDme8nqfUxqo0mDVYios6Mh9pXNK+OqpsFpL0pT8ckIyMNADl/p3NK+j7Aku7qXp0QDqUoUk/95Oov0e6M2pJkPpdHUYcGfkvUbYTacdxlzslrU3zCyVBXmCdUihU+iRw1DYQg44qxxPpx6pOtvV8uQIibZh8HJTe8+4Fck55fHGrSt+Xc9zQqTCH751ROTySEgqJPwGoENqnwWIjIwhpAQPHA/wUerXpKIdGfkulwNtALX2YycA6uCsPV+vzao9kKkvKcCSc7gJJCR5a2N0WNWtokJuSpwJYSp8BCcglI4ZPQZ0OGAOn3KRJajNlbp3UjiTjlra5tJXdVRXSac6sUphXtk8O3WOv/SOg+PdpptTriUJBJJwABkk62RWGi2LZaky0f8wl/vHApO6UDJ3U8+g/r6l33lR7LpJnVaRu72UssoGXHVdyR+vLV9XtOvqvmoy09iyhO4xGCt5LSevmSeJP+3o2EWutytIrAcygMrCyn8J3kYQfMHPx9S520u2rV0LOEmE9k93sHSlqWreUoqPLJOolTmwY8liLKdZalICH0tqx2iR0Ph4as/ZlWbt7NxhHZMKIO+rH2OqtWlaFMtCktQ4DCErCQHHQOKz3n3fPnrb5fkmmpRakEIT9bj78twjJ3CcBI7s4OTq3KK9cNfh0xlDii84Ars05KU9Tjy1SKVEotLYp8FlDMdpOEoSOA+4bR9q9MshpUJlP1usLQShhPJvPJSz08tVetVCvVJ+fUpCpEl9W8pav0HTu1C2ZXdUKc5NYpDoQ2neLbv7twjvCVYJGrDuOdbV0RiwvcQ84GXUL5DeIGcdCDq2qymv0CLUUp3e1B3k9xBwfuVRkKiwHn0p3lITkDv1tBr3/ABDd8qXvpcDYSwHEjG/u8M/POvo+2u3Dpb1ecSS/JTuIJHJOeQ+X3we7z6OXo2n3H/w5Zc6W0vEgFKW/+o8vRsDtEUq2116S0pMqeSG948mwccvEjP3JSkoSVKOAOZ1tj2qftt4UOhSSILSlCS4kY7VX2cA93P5+jYdZaajN/asxkFtpQWgk8eRA4aAwMD07QNo9LsKnpXIBkz3v4ERCsFQ6knjgDv1X7gq121pdRqb65Ep04SkZwgdEpHQeGmdn1yu0tVSFMeEYDIURxVwzwGmm1OuobT9pZCR5nWzymxqXbLceKlwNoPZguc1bvs5/L1Npm1inWY27S4zYl1lSB+5Uk7jaVDgVH9PHRJUSSck889dWLHpsq64bNU3iwpWMJ6nVLpcSkxEx4jSUIHPA5+8WSGVKB5DV6VV+sXfVJMiQt7El1DalL3sIC1YA8OJ+evo82qA1KuSQ37RX2MckdADvH88fD7htU2vItMmkUUNv1RxveU6eKI4PLh1J7tKenVqqOOudrNnylkkkFS1qPXxOtnOxOmUuDGqdwNCXUt7tOxVxbaxyGOvfk6lshyC82lAJLakpBVu8xjn089bSaELbvFwMS0uKe/tG82koLSySd08eChwPx1sBupD1Ln0mW+EuCTvsJUfwlP2R5bv3E62w3W1bdkS2t/E2ajsYwA6k+0fgMnTDK5EhthsZW4oJSPE62e0Jdt2VAprn8RsKUoA8iVE/dToe8Hq49J4Ea+kbW956l0ZDZSQkyFr/AJgeAHzGmUlb7aAneJUBjv1bKFN2tS0rbQ2fqrZ3EJ3Up9kcAOn3LbRtV+r9va1Bfy6QUTpKT9jvbT4956cvL0WFSf2VbrTZYDKiSSlJyDx5+naTtdp9mx3INPKJdaUn2GwQpDPi5g93TmfDnqtV2o3LWHanV5a35LpG8sjgkdAAOAA7hrZbsnjiKxUaxC3pGd/LvEJ7gB+utolQYtvZvWH22MJRFLTe6OCVKw2g/AqHy1asduXdlIYdJCFy2wSP+oaosMwaSwwVEkDe49M8cfAcPh6FKCElSiABzJ1tB29piOO0y0Qh1wcF1BwZSk9yEnmfE8PA89BNQrdRWsl6XMeVvLWpW8pRPUk6m2xWYDSXX4DhaUneDjRDqcd5KCQNMvOR3kPNLKHEHKVDprZZtRiXbTEQZ7garDCSXU7uErTn7ST+nq1GpwaTCXMqMtmLGR9p15YSkfE6qv0h6KzVGo9PgSpUULw4+nCSof5UnifjjVPmIqEFqW2hxCHUhSUuJ3VAHvHp6+jaldzVqWlIeC8S3UluOnHNff8ADnqmQJFYq8SnRsKkzH0Mt7x5qUoAZPmdUKkx6HRY1NjICGY6d1AHQdPy99UalCpEFybUJLcaO39pxw4A1tL22v1wKpNsqdjQQr25ed1x3H8v8o/M+GmWXpchLTLbjzzhwlKQVKUfLrrZBsqXbMf9s1xpH7UeA7NojJjoxxBPLJ6+Xp232qmp0IzYaCZm8kdmlP2zn+uNWLW2KFc7EqWtSIykLacUkZICklI+GSD8NUiYio0eFObWFtyGEOoUPxJUAQfkfedfUkPJjtKdWtKUDmVavq8pl63G/UZBUmOFERmCeDSOA+ZwCdbJ6Qms7RaUw6kKZClqUD1w2tQH/bpCQhASOQGP8C5aGs+kek8tbcKqqftBlRlHhDPZpA6ApSdbOKdHqu0KjQ5KkJZW9lW9yOEkgfEjUdtLUZptsYQhASkdwA4fcCQBk8NbVtsojNyKDbT/APaSS3IloJBaweKU8OZ4jPTVGt+q1+QG6dCeke0ApSE8B5nV62E9ZUdgTZKTKeUChoDm2d8Z8/YB/wBQ1SGDJrMFhKy2XJCE76VYKcqHEHpqlh0UyOHlby9wcc5yOnHyxpSkoGVEAd5OtqG2xmnIeo1qyEuzTlD01PFLJ7k5GCrnx5DWZFQmbzji3X3Ve044Sok95PE62c7FguVCrVWdWlDWHUMFI/eH8J58By022hpsIQMJHIa2tU92qbMa9GaKQUxxI48yGlJcI+SdR33YslqQwstutLC0LHNKgcgj46tHbVbVWpTQqMlqnTUJ/eNPOEJ+C1cDqt/SJo8RH/Kaa7McC91SXnOzGO8EBQI1dm2C6LrhuwXXmocF4brjEZON8dxUeOPDhq3Lan3PURDgJTv4ySs4HkD36sTZbR7SpqA9Hak1BacPvKGQT3AHppcWO632a2GlI/lUgEfLW2PZzJoNQcrsYByJJcPaJQn7Bx9o+B0y85HdQ6y4ttxBylaFEFJ7wemrI28VShNNwa6wqpRAr+OFYeQP6K/Lz1G232E+wHHKwphXVtyM7kfJJ0rbhs/A9mtlX/7R8f8Ahq7fpDxIquwtiI3NUU5+tP76UJPduEAn5jU2fcN71gOy3pFRmuHdTnkPBIGAPIa2YbG4lvJj1mut9tV0KKmmyfYZ7jgcz19Xrr6QVwpqF1x6Oy6VNwEbzg6BawD/AEx89bDKLIqe0eJMbSewgJU66vuylSUj4k/l768b0pNk0gz6o6d5R3WWEcVuq7gP6nV6bSrgvZRZnSdyAlZW3FbSEpHdk81Hz1RKHULjqjNMpUVUiW6ThIPTqSegHfrZzslpllNJmS9yZWFJwp8j2Wx3IH6+peNENdt+RFbVuPnd3FjmMKB1eNCTb1zSYLZJY4OMkkHKTzHDuO8PhrYle71ZoDFHnFIXER2EdW8kFSW0oATjnyPP3/E9dbfb8acU3adNeJU2rfnLQrgOHBv9T8NJSpawlCSpROAAOJOti9gNUGit1mfHUmov8UIeRhUfgUqx5/0/wTr6evqS1KREeUj7QbUR541eckzL1rUhSwouTHVZHio62J0dupbQIT7yQpuM5vAH+fcWtJ/7D9wUoJSVE4A562tbW1U6S/QqI6266ppTUhwf3ROOXDicZ1RaPMr1VZgw2luuuqAwnn+etnVhs2dSyXezVOfSnti2MJTjPBPz19JFgKpFFf4bzchaD4BSSR/9h1Gkuw5Lchhe482reQodD36Z+kJW2qCzCFMjfW207hkhwgKA/wAuM58d7VwbQrouV7fqFVf7MfZaZPZoT8Bz+OdUmh1KuTGYtOiOPOOr3E7o4Z8T5a2bbGHKO59fr6W/rAUdxCFZ9nGOOkIS2ndQAB3D0SozcyK7GdSFNupKFg9QeerzsipWvckyCIchUVteWXd3IUg8jkfL0NxX3UBSGyUk4ByAM6tDY9VKxKYVMW20kpDm4U76QO5ZBGPIatSyKbasUNxm21OAk76W9zn4cfTU6ZDrEB2FOZD0dwYUg9dXN9HanSFrkW/UXYhPH6s8ntE8uSTkEce/OqrsZvSlBSjTkSEJVjeYdBzz44OO78xr/hmu9qloUaepxQyEojrUT8hpnZ/d7yQpNtVbdPImIsfpq39g9eqS0GoqMBCgM76ASnvyAdWts7ty0UNmnQgqSgEfWXTvL48+PT1qjNaptNkzXjhthtS1HwA1fdZZr94TajHQlLTgQEhI4cEAf1zr6PdLEeynqgpPtyX1JSf8qf8A8+9v3aNSbGp+9IcS/UFjLMNCvbUM8z3DxOrjuSp3VWXarVXy7Ic4ADglCRySkdANWjZVavSpCJSo+Up/iPucG2/M/pqyLGpVjUZMKnthb6wDJlKHtvKHf3AdB09bbxbshF0CpR4m6wIqO0WnkSCRnVp3FIta5IdWYKv3C95SAcbwxgg/PVPnNVGAxLayEPNpWAeYyOvvtol9RLFt1cxRQ5McO5GjE8XF+PcAOJP6kamTH6hOfmSVlb77inHFHqonJOtgFvuzbofqzkIOR4zRQh1XJtauo7zgEfHQ4DH3IaHoxrl5eqPR199NKkw3lISVKDasJHXhqsSPrVXlO+zxcIBTyIHAH8tbAIrz179uhRS0yMrGPtZbcA/M+/W4hpsrWoBI5k62t7X1TN6g26+ttCFkSJTZIKsfhT+p1RaPOuGrswIKA7KfXgBSsZPPJOtn9hwLLt+PGDLDk/7b8kI9pSj49wHD0bVLLVetpLisK3ZcZf1hj/MoJUN0+edPMrjvuMuoUhbailSVDBBHeOmkIUs4Skqx3DVsbNrmuWS19XpEgRCrCn3BuIA8z+mrB2fx7Mp6EKcS5JxhRbzuDyz6smHHmN9nJYQ6nuWnOqnsptiqOb7rDzZzvYaUkZPxSdUqxbdpCW/q9MjKW39lxTKAof8A0gabbQ2gIbQEJHAADAHrqabV9pCT5j3O0KoCmWTVpS05bRFXkd5PAD5nUVoTagy066Gw86EqcUOCcniTqz6PGoVsQ6fEU4WGgQjtDxxk+7KkoQVrUEpTxJPADW0vbi3S3P2ZaMmPJkj+NNADjbfgjoo+PEaqNRmVaoPT58hciU+recdcOSo62V7JpN5PoqtTSuPQ21c8YVJI5pT3AdVfAdcRIcaBHRHisNssoGEobSEgfAevcdDhV6jyYc1jtEONlORzHlqs01dIrMunuBW9HcKDvDB4d+tiV+w6nRYluvuPftKI2UgK4pW2CcEHwGB72/Lzi2PbblTfbDzu8EMsb26XFH9Bz1Xq9Ublq79Uqj5ekunJOMBI6JSOgGrat2ddVejUinpBffON5X2UgcSo+AGrQteJZ9uRaRE9oNJ/eOkYLijxKj93HL7odOJJbIz0551fDMePe9YYipAZbkqQAOWRwP5519HxD679cUhJLLcZZWd7gknAHDxx+WvD3s2fHp7BekubiAQMnW0/bOurBVJtxamY4OHZYPFfgnuHjqn0+XVpzcOEyt6Q6oAJSO88z3Dx1sp2WNWmyKjU2mXamr7Khx7PmOHw9PPVRosKqNJRJazuqC0qGMgjuznSLPtxCws0OnrWOSnI6FEeWRpppthpLTLaW20jCUIGAB4D1h6c+nHvdvVwt0uzxTQsh6oEoCR1SME6il1MplTBIdC0lBHRWeH56pZCqe0c54ZI/lzxx8M491Wq5TbdprlRqspMaKggKcUCeJ5cBz1tI2uVW65z8GnSFxKIDupbbOC93lZ6g93LSckgJBKs8Mc9bJ9jS5a01y64WIw4x4TvNw/zLHd3DrpttDTaW20JQhIwlKRgAeA9wRkYOtuGz+U5NeumIFLSvdD7Y/CMYzq2LimWrX41Xg7pdZJyhY9laSMFJ1s+vyDe9H7ZpaEzGuDzA5p7j5e7va+qVY1I+u1BRcdUQlmM2RvuHw7h46vG76helddqU87oPBplJylpPcP99W7blRuirs0ymNBb7hxlSsJT4k62d7OINi04grRKqLn8ST2e7w/lHh90HD1uvL1x6eWh7hYKhgfHV8x3I17VZLqFIUt8uYVzwr2v11sJq6KbtBRHd3tyYypsY/mHEfr8/ez6jGp0db8p5DTSBlSlnAA1tJ2sTLslOw6ctcelj2cDgXfE6pNHn1uYmLAjrecOM7o4J8Seg1s92cUqz6TGcMRpdVUgKekKSFKSo8wD0GuQ+68h7r6QSpT95xnFoV9XTGw2ccAAsg/mNRQsymg2cLK0hPnkY0yUKZQpvG4obwx48fcZ4Z1eu0WhWRGSag6pcpxJUzHaGVLx+QHidXxtAq18VDtJay1BbVmPEBylvpknqfHVGodRr01ESnx1POKUBw4AeZ1s72OUm1mkT6m0mbVSOBcGUM+CRyz465DWfcz4LFSgSIUlAcYkNqacSeqVDBHyOtpmz8WTVtxlS1xnSVtZOcI8fjw1Yt4yrLuBuoM7y2j7LzYON5OqNV4lbpUafEeQ42+2FgpOefub+2mUqx4SSoolzXDhEZDgyOGcnngctXPdFUu2sO1KqPlxxR9lA4JbT0AGocKTUJbcWGwt99w4Q2gZJ1sr2bN2TS/rE0NuVZ8ZcUn+7H8oP+AdfUPu9vVt/s+rwqwhQV9ZU6y6B+AhRU3nzSoj/RrZ/V0UO+aTNcWhDXbhtxS+SUr9kqPlnPw02tLjaVoOUqAIPh7rkNX1tLpdkRkqeH1iQpe6IyFYWepPgNXXflbuuW+qVLdbhuL3hFQshvhyyOp1Y1hVS86u0ywwURBlbj6wQjA6A9SeXDVk7M6RZzYU0ntpGd7fXx3Vd497jQ9Ye56+knGtuiIdMpb04lLkmYBFS2fwkjeKvkNQWVSJ0dhJILjgSCnmMnVP7MQGENDCEISgDuwB678huKwt55aW20DKlLOANbQdu8eM0unWotEmQoYXMIO4j/pB+0fHlqbOlVOY5LmPLfkOHK3FHJOrA2KVK6YrdSqbioNPcGW8jK3B346DVq2NRbShsswY4W62CA+4AV8efHp727LaiXNQn4b7KVudmoNqIyQT0z48NV2gzLfqLkKYjC0KUnPfg44jof8AfWzXaC9ZFaQt8vu01ZPasoWeoxkDlnlql1aDWYbcqBIQ8ysbwKT09fa1tYRbTTtEoz3/ADZXBxxP9yPiOepUyTOfU/KfcedUclS1EnVEos2u1JuHCjOvrUoAhtOSBrZnsugWVG+uvILtWdRurcUchsdyf9/uHhrHp+Pp6+uPX5ekeeseGscvW2p2ku6bJmxozSFzkEPs5OPaTjP/AG5Hx0ttTSyhaSlSTgg62O7WGJcVq3q/KKJiCERnl8nR3E9CNAgjI5e4fkMxWHH33UNMtJKnHFqwlIHEkk8hq7/pBwoTjkW2oomOJOPrT2Q0eXIcz1HTVUqcys1B2dPfU9IdOVKUfyHhrZnsxduqe2/NStERtQUsEcMceB88aptNi0mC1DhtJbZaTupAHvR7vrrpw0PcfSMZWiJSnF4O9IXuY6DcGc6obgZrkN5TgbDTocKj0CeJ/pqhP/WaPHkbgSHRvgDxPq8uer02k0GzIW/IktyJisbkRpYLivE9w8Tq+NptevlwNS3BGgJOURGThGe9R/EfPUKBKqU1qHCjuSJLqt1tptOVKPhrZ/sMh0hLc+5UtTJZTkRuO40fMHidJSlCQlCQlI4AAYA9/flhxbwpy21JSJJACVqGRkcj4deI7+urgtupWzUFxKlHU0oLUlJV+LdPMflq0b4q9o1Jl+FJX2KeC2sAhQ1Z+0+iXPBZ7V36nOVvJWy4CASnng8sadq0JlSEqfypz7KUJKyfgAdImR1oSpLqSFjKePMaVV6ahQSudHSojISpwA48tXBtstO35f1ZwypbnX6shKgB5lQ1eP0gpdQj/VbYjOwUqHtSZASXB4JSMgeZzp592S8p591brqzlS1qKio+JPPVpWXWLyqaIlMjkoJ/ePq4IbHUk6six6ZZNHTEhNIMhYH1iRj2nD/t4e66+jj6ufV+PqD08dAe6HoHuNtOzL6olVxUhlSmt4du2n8A7/LQ32nAQShaTkEcCDrZNthcVKFEuSSkMbgEaQrmFD8J8D+mo8liWwl+O8h1pYylaFZBHgfVUoJHHV+ba6PachVPgM/tSoAArShwJbbz0Urjx8Bq7L/uG83R+1Zn9mQctxGRuNI/09T4nJ1RKLMr1SagwkBbzigAkrSnPlvEasvYXRKM01LrO/OnYCigqwhs9wxz0yy3HaS20hKEJGAlIwB9xHp5ekD0/r7jGtuFBbqtivyRj6xE/etZOOA9pX/alegSOR1sdm/XLMIS+Hmmn1oQocsZ9GdKdQjO8oDHfqt3dQrdiGTUqkwygdCvKj5DmdbRduMitNrpdsLfiQzwclk7rjo7gOaR+elKelPlSi486s5JJKlK/31Z2yCv3O407IZXBhKVxccT7RHUgHVn2FQrJiKapUb985/FkOHecX5noPAfcr4siBdtKdbcjtmXgbrmOJA6Z1dlh1q0pCUzYyww59hw44+HA6S662U7q1pKeWCRjy1AvK5KbKbkRa3NS439jfdLiR/pVkflqVtFuyatC36y6pSORS2hPzwkZ1Ikvy31PSHnHnVfaW4oqJ+J9EC36rUy2YsJ1SFq3Q4Ruoz5nhq0tgs+YW3604WEE8UgY3fgR7XTu1RqNCoNMagQWg2w0MJA+5D09NY90fcgY9OMeu602+0pp1CVoUMKSoZBGr72CNPqk1K2pK0OkBQhPEqCldcLJyPjqVEkwJK40uO7HfQcLbdQUKT5g6t3aZc9stNswpoLCN0BtxAPsjkkHu1TPpJOISlNSt8L71sSMfkR+um/pHW6W95ylVNKs/YSlB/PeGnfpJ0kKwxb81ae9x5Kf6A6rf0g67OaKKXCbgKP94V9pw8BgYPz1UL5ueqB0S65MWl05cSlzcCvMJxpCFOLCEAqUTgAddbL9jz9wTDOuOG+1TEA7jZVuF1Xw441QbNt+2mkopdLjMrSMF4NJ7RXmrGffA59X4e6Ax6D6OXqXTR263bs2CsHK2FpSR+HeSUn8iRq4KSukVJTZbUhpftNg9AeOM9cAjWzfahJsxDcLs2naeoKLyV5BCzvEEH4JHx03tltFyCxI+voS6412i2CeLfgTjnqu7faEy0U0tp19YGTveyPLVy7Y7irhU3FX9QYPAJbOVY89A1StyN1Tj8lZyr21E45n/fVobD69cKW5M9Qp0RR47w3lkeA1bGym2LYjpS3DTKk81yHhkq+HQaSlKBhIAHcPuk6nx6jHVHlNpdaXzSsZHw1VdjVm1SKG10lth8c34q1NKz8SoH4g6rewww6upmG9WVRlq/drTAbfCR/mUl1JP/0DS9iFT7ZLbUuSQfxOQSjHzXqkfR8q70g/tCW0hsJzhORk6tzYjQKYtD85hLzyem8cajQIsRtKGWUJSnlhI4e/HEe9Hox6n9PR8dD1OvoA9HT3Vz7PLfuhtapcFlEpScCQlA3h/vqufR+qDC1OU2QhxrICUjmPE5P66qFjXFTHFIl0x5vCt3eKTg/HS7dq7SQpyA6hOM5VgcNMUyXIcaQ20VF1W6ndG9x8k5P5apWy24qwUfVkxsK4ZU4Rg9x4aoP0d87rlYnq7y2gYHlwOfz1Q9nFsUFhtuNS46lo4lxaN5RPfk6SlKUhKRgDp95Gho56H0ddDXx9A7tY9W+9llIvdCXHHFw5iTntmgDvcMYIOro2SXLbktxDEV6pRkjPbxmF8B4jHD5nX/DFb7NCxTJJC+Q3Dn5apGy26qypBYp6koWMpWogA6t/6Oq3Ch6t1Ps08yw0jJPmc8NUbZ9bdDiMx41ObWGvsqd9o579IQltAQhISkcgBy/+VcaW024ndWhKk9xGdJbQlISlCQByAHLQ/wALIBGCOGgy0OTafloAAcP/AOBr//4AAwD/2Q==") }



            .logo { height: 70px; background-size: auto 50px; background-repeat: no-repeat; background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAbAAAABsCAYAAAALxefKAAAAAXNSR0IArs4c6QAAQABJREFUeAHtnQncVVMXxpc0zwMaKaGkUdIsGSKkyRCSMs8hDcpQIalQKDJHmUMlpZDiK8qYJGWoRJqjuYRv/e9+d/fc8955eu/NWf3uPdM++5yz79teZ631rGcd8K+KeOKNgDcC3gh4I+CNQJaNQL4su1/vdr0R8EbAGwFvBLwR8I2Ap8C8PwRvBLwR2D9GYO9ukSl3iWxcvn88j/cUEUcgf8QWXgNvBLwR8EYg00bgn70ii2eIfDdTZOVnIje/L1KwqEi5qiJ3HCXSoKNI29tEqjYKvPONK0SKlhYpop+v3hD56AlVeLpv7x6RGieKXPSY9lMs8BxvK2NH4AAvBpaxv413Y94IeCMQbAR+/Vrk2W4iv33rP3pab5FzRohs2yBy68H+/Q3PEelwj8jW9SIz9fiP/xN5YJ1u62dwHZEdf/jb9pwuUrutyO6tItOGiOQvJHL0ySJHqWLzJCNHwFNgGfmzeDfljYA3AvtGYOFkkSXvGauqSn2R4qqgdv4p8vDpIsvn72smV70q0vBckWsO9O9j7YADRCxWDYV29USRF68x1pez5am3iGxZK7LoHdO/PXb2QJF2g+yWt8ygEfBciBn0Y3i34o2ANwKOEUBJPX+puvreMjs/HGOWpSqIVKotUriEo7GuvnS9yKHHiuTT0P4///iPWeXFnmPaGCtt4RT/cbv2/ki7ZpYly4tc9ZpaYK3MNpbZkg9E6rXTa3hTZ+Bg5c2WZ4Hlzbh7V/VGwBuBcCOwe5vIKFU2P38arlXuY0VKieza4re43C36fCTy1gDjSnQfc29XqGnciNs3GqX3l4JEkMObiFw3SaSkKlJP8nQEPAWWp8PvXdwbAW8Eco3Anh0ij54hskyVTbKlSj2RX79JvNfyChTpO9e4MxPvzeshzhHwFFicA+ed5o2ANwKpGIF/RUafbeJQ7u5xD7a+zlg+KxaIfKugi5VfaCs9J+micbPiBxnLK1T/9durJTY56Vf2Oox+BDwFFv1YeS29EfBGINUj8IHGoV7rFXiVymo1obhOuMoAMpxHt6l7b4Lu/+pN59741wsUEWlzq8hJN6ii1BgY1iBQ/aWzRYibuXPMLh6r93V1/NfzzkxoBDwFltDweSd7I+CNQNJGYMdmkQHVFAGoMSwrFz0ucqIiBq38/p3melUzOV9235qlIk9fKLLqK7snviUW3tWvixx8RPDzAYNMvVs/g/zHi5QUGfqL5pVp7M2TtI9AvrRf0bugNwLeCHgjEGwE9mwXOXuQH11Yo7Vfef22SGRIQ5FBij7sW1HkZUUcrlliegFscceXIi2vDNZrdPsKFRe5YapfeS2dJfJqT5GHThL5XpOkEeD4QOqbX2a2+UbZzs5BR/r3emtpGgHPAkvTQHuX8UbAG4EII7Bjk8LmVTl8TVxJlcVd34hUrqPJxmqZ3dNAZJNaOk5BoTQ6X6TbUyKFSij6UJGLdyq4YssaZ6vo1lteYfqh9Ws3i3zwcOB59TUud+6DIodo/8D77zgyJz6mzUocrFbYShHcj56kdQQ8Cyytw+1dzBsBbwSCjgAWFkrKp7y0xbGdjPKi8f9UQbmVF/tx6X32qsjwliJ//6WWm1pRFz+hykyX0QiUUcXKqa7UxOdGF5gzfvkit/LiyMK3jfW38nPjLjy9n/8KsHx8rvlinqR9BLxsvLQPuXdBbwS8Ecg1AoAwNq3y7wbhZ2X+i3Yt+BJYPC6/Y5SZg/Me2ap0UOqOJH/rp3ki36jy+eJ1zekqLNJKARd1zzK5XAVzLCYUIdYc8vUkswz2jZL85HnDr9j6ekNNBSUVgpJt1t2sZ+s3FjAvCtBrHVjAoDDLq3s2g8VTYBn843i35o3Af2YENvwc+Kjfq0JCIezdJbL628Bjzq1D1Wprq9ZQrVOde9UKK2Y+ZQ8TOV6tK3gS4TYsrhaXW6zyYj8xuDJVRN7oGwgmsefYuBvKzzJ8QBzcVLkZQSxCKJwtsv5Hk65AsviKz0TW/5T7zhm7K17S/TkKPneLPN3jKbA8HX7v4t4IeCPgGwHiSk7BIjtnuIGyt7hc5GO1cJxC3InYV/0Ozr2h10tXCn3MeQR3IrD4Gq1FHtO+QTg6xbJxbP5VY2DrzRGsv473Zr7y+vdvw2zyjYJVvpmiLwaK6AwnKON2d2mLHOX1nsYAYUg5o79aaAXDnZm2Yx6II21D7V3IGwFvBEKOwIgTctM7oUjIs0KwwlBqcxRWX76GWgUvi5QKo5SYrH/50sTDKtQyfdjvdT8YiwNr7Ijm2qaEPRK4BAwyrJnIhhX+/TZ5+YePldW+lX8//Iv1zjb3lWlgDhTtKz01n22GulUVEBNMIEk+7jxt857ID3P8LYgrAl5p3sMor94VRKo1Erle3bLED/NYPAWWxz+Ad3lvBP7zIzB/gimP4h4IrKH+8zXmdJz/CFD7AhrL4lgwgXCXXK1Px6tLT9v2UUVTRd2MTkGBTb9PZN44kcOOFemtE3YoJYbivFfb/L3X9ICLsd1Ac423demWE681NcXc+/N6e9FUkfFXivypStnKAap0iQeedKMhObb7F00TeeHyQDRnsbIGVMNLAWhPXiJuVmWHizYPxVNgeTj43qW9EfjPjwDMFoPqmPgRg3HKLYoCHOkfFkqnXK/urupN/ftCrf25WhGJLfwW0+WqGBt3Dd6a6s3kk2GRlDzE5IBVPT5429f1noDPH6F9w6X4y9dqfZ1o6oYFO6NNL+P+DKVkg52Tjn2/Lxa5r7F/rLkmtc7qtDUAGiy1SvpbkLYA+AW6rnCC9Qo5ch4+p6fAwv1A3jFvBLwRSO0IjG7n5z08605TRfnGYq5ragym+aUindRqgt4plCx+V+uDfWog9UXVYoASKpx8q5YGBS6xIo45TeSg6uFam2NL3hd58nwzyYdrTXVnFGhpBYRkksx7VnPt1LqKVQqXVNehKnjctrgiLfqy4xCNiQ2ItbektfcUWNKG0uvIGwFvBGIaASbB3g6FNEator17RG4KEZM6Ty2zU2+O6RJJa7xqoWHc+GScUZDRdIzb7dq3/PXEojkn5W3+Fbm/WWAh0EjXBMzR+gYRXjCIiS1Tl+vIU7XmmrpVgdv3U2utqsbF8kDUCeqJNwLeCHgjkAcjAHrPKVg394dxFVKHC/n3HxE4EX/7xvAfklxMZeafPzEWFS6wZAs8i+R6kQsWrWzfpFWj1bL7/oNoz0hDO7VmLxqjiid/4LW6PCzSc7pBGAJUoWCoTS8gPWDmcOOeJWkb65J8OoTxGKPglY0rfJvp/vIssHSPuHc9bwS8ETAjAKjgf09HPxrDV6sLS+NWyEvXGUSi2Qr8JqZ1q1oJFY4O3O/c2rpW5HV1MaI0sQSpsIw1wcTOku1L9N7qqosTAbwwxAEmMXuj+yavbJDGn3DDZYp8+KhROqQDgKhEIQFOcQpgF2J9f/7u30ti89mDtfJ1fcNMwssEAqjDVx/tILOdpm9PgaVpoL3LeCPgjYBrBO7SyXDtMtfOMJujdxoEom3y+SsiT11otwKXkWIzD59uyqQEnmW2iPV0vl+k5sn+oyvUyhuq++MVi16M9/xUn4cigrkEKi/AG78vMQoOYMw/OUrKeQ8AWsgJ+1Vdq1YYt5s0Dkn8MU2irxmeeCPgjYBzBHbt+ktW/rpeVqzSzy/rZMvWnbJ9xy7ZsWO3bN+5WzhetEhBKVGiqJQoVliXRaRk8SJSpVI5qXFERd/S2V8i66vXbJYBQ17a18Vzj1ynnh11A2W7/K2xrmDMD+GeC+QgEHor8BdS0HLmA2aPz3oqaFB24cAetKZYJfGc6hoPIvfJyiFHGmQdtFNOSdRFNusRkdN6a7KzG6DivEgerH/8hBkL3LM8M0TG0HBFkp/m5m4Bm8ew5sYVWe7w3MdTsGefAluy7DfZ+7cm/2WoHHJQKSl/cKmY727nrj2+CSjmE+M4oUjhglJSJ7NMlB068S79Ud+m0iT58x8odWsdlqarxX+ZzX9sl/lf/iDzvzAfxmjNuj+UJUiD3XFKEVVuR1arIEdVryi1alaR5sfXkCbHHaVKr1DMPX7z3Up5bdK8feeNGNRNDi6XQa6ofXcW4wrK6x/XfFO5rslLIofrj99yd0j8xV13C4ooiH/XqruL82cMM8S6oWp62V5BHv61S+SaNwxP4oblJukZVnq38uKcZbPtmfEtiYct0BeRREq+xHfl8GcBoydOBw8l+XZFS0enwEL1CnMJIBFK06QB2LFPgbU9/15Zv3FLqNvK8/39enaUgX3Oi/k+nh7/gfS7e0LM58VzQkl9I5/yYj9pfOyR8Zye0nO+XbJKWncYmNJrODsvU7qY/LboSeeujFn/9PNlMmn6Z/LuB1/Lsp+Sr9R37twji5b84vvIO/N9z41CP65edWnR9Ghp2eRoOalFbSlUSGMtEeTLhT8HtFi/Ycv+ocDcFE28sd+hQAlqawVTXozCKs2/wkJyS3V96+eDWCg8IIRwUvZQBSDs1Wvp7++s7xXsHBJ3F88wUHuqM+8TtYThV4SvMRr5VkESmabAiBMOUMvp5RtUkU+M5ikit9myVmRES5H295hUBhKmUySp6zlFN5zJ3W7ZukPadx0mC776MZNv8z95byitm29/To5odIOc3GmwPPLktJQor1CDu3fv3z5L76HH3pbO3UfIYQ2ulStuHivvzf5G/v47SIwhp6O3pmk8wiHrNvzp2MriVRKYnXJyTwVOHKgJtJ849/rXyT+y7PH+vbnXCqhCAcRBAnQ4KaFtkI0rzTLcN67JwRoTOtilPA+urrD+W8KdGXgMNCLQ80yTEuVFrnpd41eqpEEYJkPgjIQQGRCIm6g5Gf3n9KG/jJEypYtrrO5f4d8OfYPcpa63vJZiRQtL4Zy31HjcL9w/7hz6IYaRDrFKbMoEtcQauv7g03EDIa5RrGghqXdMVcGliqX9x59R+LlD9BVqdz7lg6tYvrSU0HjQwQflvZtrz5698vqUT+SxZ2fIV4tcE2aoh0jT/q3bdspLb3zs+xxUtoR0btdEzmvfTJo3rrkvxvXMi7Nk8ffq2nEIFth+IW5OPjtxAtkOJuyvfUawI4H7SEyuGMH64gxiYMia741lZbaCf9u42+rFgcdxWUJs+9HYyInNnEn1Zkq/HNYwsJ9M2SKZmw/0WdQ3I86F2xaGDnLBeIkoU1kTv6uKlNNP0TLGDctv89krubkseS5+j7vrmWoAJ16jO9RqTaKERCHyxkgQ+6tvlstb7yyQqe99IexLleB+u7BzCzn1xHrSoG41qXhIGcmXL3kPi3LerJP21zqRfarxjqkzvpCFi1ek6nE0FqbuxAxTYs6HBZjwmVqKuNEmTPxI/twSYuJwnhRknQn3gk4tpEXjo30AhgMPzHujfruCLbCwnnj+Pck2i6Vi+TLSpOFRsmHzVpk7//tcsbgRgy+R6y87PcgvkWW7Xr1JBGCDlRHqdsJyotJxKHBHr1mKDDzJnpF7SamToU1EGp4j0v253Mede5ikB6sCwuo7Re8FwtpwwiTdv5qfgZ62Z92lbrLBIk+cJ/JllO43crBOvC7clbL3GAwdU3RMlgd6DfY9UK1TzO9SRt23SZKQCszd/7Kffpfu149OyaR/rr55jr7/8rQDIN6fs0juuO9lIVCeCsl0JWafecOmrXLhVaN8E6bdF2nJsz018ho5+/Q4c2MiXSCO47ykjHvlQ7nngYmydn3irjasd+JVtWpUkepVy8uhlcv50IZF1ZolpgUqceu2XbJ6zSb5acVan0sSpcN4pkr63NBBBvc7P1Xdp6/fcd21OOQL/utd8qwIdbV6ldN9//r3O9cgngUc4BYshOlDjSW0Z6fI+SNVKSmaLpyAgiTuY8u03KnxNzfpr/P8V7W/WQ8794hcrUoLZfmIWobQWEUjTbqKXDYhmpbZ2wZy5lfVJey2snki0KHXTRI5vGlSni9qBcbVQGw1P/N2WamWWbKkwxnHy8tPRvhjS9bFgvQDOu/SGx+Tt2d8HuRo4ruyRYn99dffvheUSdNDvD05hqJShTIy4/U75Yhq+seYIfLBR4uk7+AJsmTZrwnd0dFHVZbTWteXNq3r+ZRXNEAL9wV5IZr9v8XyoX7+pwotme7rHheeJI8Nv8J9yezbflKtFidogGrKxJMeaRv+WaBmQtFZIcl2aGOdnPR3L1zClDNB0VnBbQfakDwn0g8oAeJkoaDG1cTe5lzicBRwhNDWKe+P0qRnvTe33L3UJFbfWSOQud3djm0SsLlXJvARukyyKy3YJfN0H8/64tUiC9/OfRvEKbGQj78w97EY98SkwOh75uyF0rHb8BgvE7w5sakfP3tUSpUsGrxBmvYSRD+x/V3ypbpLUyHZosR+U0uiTstesnv3X2GHAcur67knhG2TroO8gPS/5yV5avz7cV8St2eXji2kX88OPuh73B0FOZEXgynvfiZjNA4HkCRROatNQ3n92VsT7Sbvz4cQ94vX/fcB8wWksO/c7d8XbI3YFYwPMD8gU+7Uc+416xeOVs6+69XNt0Hh9DpHEcfZ5PKugIgDYg/DBsUagY3f20ARjgtNH3yjSM97yGyjGPtXUwUYJHxytLrEYLHAmosklFmB7WLhZJFGXfT+a0Y6Y/84TnyQWmRuCi7qp135qlqw5yb0nNpLbMLb6eFVD4ntpBCtu3RsnufKi1tjAntq5LW+ZYhbTWi3D9hxsaITv8xsdGLlCmXlUn3DDyfkdmWK8gLt2fT0AXErL0AnXTR+9+Ws4fL0qGuSrrwYxwIFDpRzzm4qs94aKPOmD5GLz2sVFXw+1G+QbTG9UM/hiz05D4LOi4ZWCuU0SoEG63L+L2FZkQdGTS+UF4JbcOaI3MqLY7SHIomSLUysSP8FIj3GGYAC287SLe/eH1x50Q5UYTTKi7afvmAsQeJm/xXlxXO3UuDGzTMVNKOWr1Ng93j2YhE3H6azTRTrMSsw+jy1Vb0ouo7c5LST6kdulKYWtWpUlpNaulwHSbx2tiixSL9JuwyJeT361HQ5ReHwPy5fE9evdEKzWvLFB8MEZgsSjtMhDepUkycfulp+WPCoXN29jYKUYv/vt25/QSECnnALtEXRCFbV1MGmZbtBmoz8ZiDjO0APkmjrdwjeG7lbPsmJtR1YUKRZd5E71Qq7+AmtTJwTY8RCnP1Y8D5i3Qu7Be5ROAh3/hHr2dndvkZr85JQwWV1ArV/rKPhmYzzCWP/H6QXqnvMYXFeLvC0+rWrBu7I4y3QdKkUlNjZXe/PaEuMSTacwCiRlwJQ46YBz/mS08PlT4W7x5uuPkumvTxAah5ZKVyzlB0DNj/y3h7y4eRBMbOV7BcwehQQ7O6xCiS7MGiQfGvrUbHPLVhQJOcCltinrByNrp2kxLwaLrj4ScdOXSU+dsJVxrojLvaUxsNCAUoCz4xua4cqLqy+vvp3N/mO6M7ZX1qRYH7rbP3tXEps11aRRxUEg1Uch8SlwA4/LHEXInxuVQ89OI5bTt0pjRqobzzFQv4PSgzqokyUCoeUFibYUHJc/dSPUahrb9u+Szr3GBG3y7C48hZOGNtTht5xUcrcxaHuPdj+4/XvDbfifbdfFDXNFDE/0gSyViiDMlg9Hat1GUnIM6Ki8uUvigz8Vic6tWKGqvIjqZik20gC16GbYR2CXioQH1QtdGL0fL0esa1ytCkW6SqxHwcpiWty86rYz83mM0pWUJTph7mV2JZ1Smd1elyWacwgDsaPWE6itERMJuu+fyajfg7y3MoedWlK893sA5Ps+/aLt2VUsrO9twat+wRlqSBWuHXFeNssrUsU/xldhsQNtCFu++a4PnlmdUUaLDgYOyg46hclEY4k380dKdWS8BIZ6TopOf7DR4adIVznEMue3k+k3tkGMQhn4s+fKnHv58byAoiBm/BoVUbEzsaeY0AClVUxdlLF4KYu+nC0Wj43mnjMOQruAK1oBWvQ0loVKZkb3g0nJsnOENX+qErta7XeiMOFklpttETLe6GOBu4nCbrjfYH7/gtbIBSHNcvNgtJUY2KXxja/6F9C7AKrQ6LCBJ5pQm5POOsjmfdrLbFMBHaUKF446KPmFVoU9pBOSr8UL0qU5OC8dBkGHUzXTtyZc6YMlkguXE5bl8Gcpa7Hyr0ZLPZlWx1woMiN00RuU2VVr51hd8CNd6t6auDWgyl9uk740xR1+NnL5ixAGbgRT7ohuPKilc05AiLvVF4cgxx47VKFyffyJ1ZjfT2oCvK57iJvDzQuRaD53Z7Soo46+d6koASY8Llft5z3oIGHR2O5ffWW++z/xjYpBddP0d+ieODzfqou3680nhmDxKXAChTIH8MlgjfNBMaGYHeWzvvKVCVWvFjwl4vSpVLgTgn2Izj2AUO/4MqRMm+BTjJxCKTCMKJkmrs62KNQbeG9N+6KCCbK6jgY1hHgFcrTt7gscBigKYLKaO5zCqiooQqkm0LhFWrtrrBMH5bNAQAGCcV1zsxtednesdwQilK6pUhpVX5qneGivOgxc5R2y2Yb5OA79yjQoL0q0YMMcweuP2D4V6oCHfKTSBO9R6cQc7viJZELHnHuzb1OkUsU538N0GFHonI94xp2A5kmXK1W9lrbKuJS/xI8cY5APMgw5/mxrmeiEgP6HUwsL2WwY6nad8Ntz/gIb+PpnzjruEdvkNpHHxrP6XlyDt6NV5662cf+EeoGshpKjwWGJdP+7tyuOJgbBh4j8oIqto0rcj9+IX1jJ9n4nh9MDlfuFv49oP6+fVdjTcNEJt1u9n8wSvPDRpjSK/6W/jWUGVJfFVbzS41lZ/aYb+inyDu7QxXYyFPNPZ5wpbOFWodDFPehbsdmPTTWUyvwmHPrlvfVXfaCJjevce79b63X03F2xyhxz46/Kupx8BSYa6jCWWCpeou3SixTgR12iNJdSHHcy7Nl/Gtz7OVjXl536ek+Ro2YT8zjE3CvT9Rk5XJlHLEaxz1ltQVWURWULV9C2Q2n7FZE2rplzj1mHeb4zsO1ztQqkS4PG6vlma4aS2ttilfaMwBHAMB4XPPCeqnFBLrtrdvUgttkWmz6ReTNviJ3qXV3f1OFtI8WoVSKU3Af/vyJSNexmuD8o8ktC1YfjBywB1uLPK/K1inke03QCfgvvRfcmqEEeH6Tiw2iMlSb/8J+ZXYKyLvjmReqe3H++KiePnFfYFSXyZ5G4RTYkNsvlPsfniTfaq2nZAtKrL0mO2cCsCNUMcd0KrCFi1dKr7uej3uYj9FCkvcOuCDu8/P6REAn40Zf70Osuu8lqxUYVhTy8zwtW/+dWQ/1DQM6YI5TNT5FvGSZvsxMvTsw+fWhkzUJWf9O4CLEvbdFLRpiYrj5Slc2DOolNIYGXJuikigzyIKXzzcfWDwg5KWQJaVVUH7bN2pM7FajvCiYeeYdJvaG0nEzcqxXJecWErKhyQpX/oV8MNIBYOhIpVBbbemHOYjHAwyVVZV6Ioc2CB7DS+W9BOubOOJlqqzu0ftxVoJ+q78mqJ9jWPCDnZezz1NgrsHJH4ZN/fe1f8j0V2+XMxUNR8HCZIu1xDJBiSX72WLpb9euv+Tiax9JqKTP8IHdEmK8iOV+U9X2lFZ1Ba7QyVp80ylrs70mGJWJx/XITS/kfEjYKohtgSwkf2r8lcrU8Yy2UPecU1BEA1URQEUFKvE4VUgwcxQr62yVe32zTuwo0SVqSVkAB2hHlBeCIsRdOFevidVHTKvpJca6iiaHjdhWuPgWbsaXrtOCmr+KdBhirpnMb6xZcs7mjQveK7XM2qiSxlVaoEjwNunaS521zvcrubLGIq3w+8BTSaw0jOQLc+w/eSicBbZk6a/q1iku01SJUVsrFWKVWF66E0NZYKl43mB9Dnt0kvwUJ8MG/THxn3yCTnz7gQwZcKEULKiTs0Oy2gLjOUATurnxHM8nxKJIREZ5AVsfpG5HH82US3k5zwFhSG5Yy8sjKy/OAzBy3HmazKyuwtu/MNYgoAq3bFyhII4OSnukyquS3kd/VZiRmO7dfYTb/n1JuKPxHQMEcd/xoZUXva7/WRXo9fo8Oo9F6a6L72aiPAtLlN/bKTOHRwR0eArMOWC6fqAbFeM4vmLVOt+WUWIDUqrEcCdmGsQ+HYqNsj0jx051jHrsq/fqpL+/SHVl/L+q26kBj7N+458B21m3EapopX0QXIAUkcSCwKVH3lAkwQKLV3jbjyRM8vc1Nu5HyrVcrlZkMmS3KwaXjD6f7ebPbYvUHwUrUc5PnOu3PiOdk4rjuBIZV6cQn5wy0Lkn17qnwFxDEs4C27BRzfIcKasVrHEn1q9dze5K6jITLDH3A6VDgUETRSXleKV1i9r6m6TGOo73nhI97yrlTXTKuiTUOnP2l/Z1yyTPhfMXzH15kGgjTjC8gbmPBt9DsnG8Em0tr98XG8tmwcsiR7YMfrWi6rokR6zdIK28fFzwNs69yVZg3ON37/mvQIpAPwWlwPNIknUo+fINBa0ca6D9odqkev/R+qJW98zAq2B5h/ltPQUWOFxaMkgDnSHEPYGTYzTtlQEpVWJYYul2J+KeDyah9gdrG8++2XMXy5x5+h8wAbmi2ykJnJ2Zpx55eAVpdrzGhHJkk9blgxMya4UcLmIwPacZEt1cD6LPRmwrFqH9huXqclKLAiSiU4JNgIveMS0glP3iNWfr8OsonGcuUveburyCSbmqJg/s7IHKefg/ZQw5OVgr/z5yzmDGd8f2/C1iW/vlK397YlzE7uCGBLjRY5wmew81ZWuOaOFvZ9c2rTIvDtHE+Ow5yV62vS2wR+KSvvEJ3G23PAVmRyLOpVVix9Y9PM4ewp9m0YnpVmLB7sqtwIO1SWQfCM9EBB7H9qc3SqSLjD33kvNb7bu3f7QURSqrPu+7UKpWqh2vDPL6xk89Ld78kyKq9F64XJky1DKCdsop5BUxEVphooZlA1Sir+zKL/ZI9EurAN1nMPm/qZPwyi+M5UByNLXHQgkK9LVeBpKfqOLYs10Vf86z44Ztf0/gVUtXEkFBdBwiQmFQyIvdwgsALCS/LXIfSc/2kWp5QyXmFF5IdgZ3m3sKzDlQca6jxN55ub/8F5RYnEMU8TQU9EeffBexXbgGnds1EejA9kehpljhwn53W1YnM5P7U6WBJhpPN0okWT8YcHHyyJwURXAY/jRXP/P8V1mxwMR7AGdAFRVOUASxCuCD+/RFCpccCElyxiLJso+U2UNdjk9fELv1CVSefLfbDlW36xhzJYAwC3TiH6EvPtcXVkSnTvU3lzEuUMAb8DWSOhBMUBajVenGwIgRrJu492E5OgV4/SfPO/fsW08g8rmvD29FRwCaJZRYu4uGxs3ZF24grSUGLVJelzQJd5/xHksUuMF1256sE8Z+KpBff/z23bJTUwyQZFSEyLuhUjc9cS54DSMJOVj4rmcMM8S9kdpznMmO8h21NKaCNQRfIjlkR+nbPcAAq1B+VBdfJKECdDeNwwC1D4ZS5HxiXXvVkoKpI5iQ1ByN8JyfvWo+FWtpteJzjDVyWEODrESZAjhZo8jFXxeaKtIscZE6LUyutU0tKVIPnAKsH1otPnPUMgwnJH2PUQXfRxUrdF3plAYdRcjdwxq0wv3CwuIST4G5BiSRTZTY1Jf6+5JPv1j4cyJdBT13f1Vim/7YJtM/+DroM0e7s1jRwtKqmf6n348lmyixIv4MsFUsV0sokjCpd7xXlYS+nICUs1KumuE/pGQ9CsopoBbp3ylMgOSfESfbu8t5JPw6faFABi3254s5z4D9vm0/k4QLK0cs8TRnP+514PUkWSdLqh5viIuJFZIjFo3QlsKhqchTC3d9FDVkznBiWqFiAC7WQwNfUvPZ494yOSNgldhx9asnp0NXL1aJZUJMzHVrcW9OnPKp/PXX3rjP58QTmx+TK18qoQ69k1M7ApGg9Pbqv31j1uAnxO1oZeMKk4/VX5UgRS4jCYoIyyVa5VXucH+PUEvB4Xj+KGX2qOjfzxpVm+eNMy7KZpeoxdQ08HhebxVXS+a6KZpXp+N0i7oNH9mibk1Vxlg50ciM4UqCrPG8dAukzm7B5ewST4G5BiQZm5QdwRJLVYHM/U2JvfxGFK6cCD9Mql4YIlzWOxzvCBzRPLozcf2RdMtbOZRD0EtZgam+qrrvLDO93Z+MZdfHjcVCXxbVCEIZ1ginMLk/f6kWZNQJl7iRBVE42zjXKbMCg32wStHOdslYh2HjLnUx1j87sDcSsikSWrF24P5gW3/ri+U4fb6/9wQ7mrp9AHzciPBvp+W6nqfAcg1JcnZYJXb8sUckp0NXL/uLEluz7g+Z/+UPrqeLffPYeofHfpJ3Rt6NQLQKbJdaDGN0AqZqL0wNWEFW3h9pQCBb9VgyBasFC8DmTVGjilpVyGm99UsVWTwC9+Hd6gq77AXD/kFRzlRK1UbGYoTjkXhY7/IiN+gLQD8FezzQWq+s7tloBERiMt2Z0VyT3wC+RqeALnWV1vEUmHOAkrxesgRVl/tL42Ndb21Jus7+oMQ+/kTdOkmQaApBJuEyXhfJGgGg0sGKWzbUONdRJwbW9oL094FWCqJQhCHlS6rnWG8Q806+0x/sL1zSEPjGeo8ldGK3pVQ4twbXVyVF7MsnOtE/p+5BuAshCe48LGd/jAvAFjzHuB6GGqtUpUCLMsbuIjYHdMK17qpproeiB1AC/+LKzyKTKTsv8O7Q0CAWZ7tkrrvdiABVvpsZcAVPgQUMR/I3fErspdukScOjkt+59pjtSixR6DyDShoDOWCeZNEIFCph3H/OWwYscLXGlHrPFjlnuPOImTyBpU/XiZQAv5WPnvCT5gLmuG+FFp+c7VA+tmHOsvYZgTso1dJrVuDbPooQofTLPlElNudxLWqpViAlWSJJ0TJKKtw5t4La8LNBSVKbDJh7tLFAYnJYJbEICgtEJghJFDTIzOrNDMv+tZM0Lva5//4oGROOjgtXoq2rFss9JNLWWsDOPlxuRE+BOQcnRevUd5ryosLfPSWWa4Q//lTfShOUKhXLJdiDd3qejEDttoGXtcUhcQ2+EURJMNlPGhA4kTrLm8CSQVwMC6pRl8C+2WrWXet8qRKyQjztJn2jJyaEe8+KdVPh4nPHvGybcMsGnUztMpK1By8xxTudFl64c0MdQzn3+dgwyMfiwgR00vE+TfD+zVSQ7jdP5MLRCuJQiDzxwza9TcLzqM0iQ1dq0vVZoe7AJJ2TQ5cuObxx7isBqHGIp8Acg5HK1X1K7DjPErPjvG37Lln202q7GfeySiVPgcU9eHl5Yu3TA6/+vVpCbw8ycHU3ND6gpVpDoWSiTsgwbbjjJ+Ry9Rinic4/+s8EGFI+5/8jdEtWvpthCISLqCUGK/5x59sj0S2/fksJchWoQRI1CElKguwrjlkouj7crTapciEWiMK5WZWu273mbs821tZw/f91Rn+/pcVLAHXNYCeZ+YApQXPKTYY8GaaO6yaHf17y6tIlWOlu1CdpEI5KBp4CS9ePoddBiVHrq2mjGim5ara5E39asTYp4+ApsKQMY/o7IQ5W1OH6fU8nVApWJiLU8XpYFaM7+dYqxEVT/b3DOAFpMLRP0D3BiI4wyT/Q2uQhweCBRVeklO9QwFe5asaqw8JxW2oosaGNNX+sjta5ukGTk18xVl4wt5i9bkDnQTbWKdhpVBuTC0XpmIsc1mSQ5gH5cau/0/paD6lCrq73c73GxJ5SK7ePobC6WX+DwXVN0jdcit2eDIwJOvuG7QQWj3SJk/iZa+LKpCBpjuS3K94yPSMAowJsGh26DZdPPlua9ItaJZYNjB2J1PxyDlxZrdHmSRaOABN3nTNNgjG3D0OEWy55VoRaXz+q+wzFFI2Q7/V4x8CW0ElR8PJjnZydApkutE81Wmu14kP8pVugpHrhMmfLwHUsK9yDlH1BcMcFuz/Y4fmEExCZsG68drO/FWNT9lBl3lDAxT86aVuB7YPr9PpAkx+vMflnoep5/aZtV+iYAsAASRlKUO70ywfGEyw3YoOhCnLOesSP0AzVZ7L2Q47sFsApOS7ffO5j3nbqR8AqseaNa6bkYlaJffq5/ifMYPkxgaKVzscqUrigc9Nbz6YRQDmFEiZxjhcsovRPs0K1Cr7fTf5K5eWRp4YGTSyb7VdewXsM3AvV0tMXGQYOjuDSo3JzLPEp2yPKEDeeE2BCbA/r4x79P9z1icBcN3LPHtVY1a6tpo3tx72E3Hfo8eGVl/sctokzocBDCQnF8C+mQ4IRDqPAcsSzwOxIpHlZrGghmTweS2yYzFvg/0GSdRsoMay8yeP7psxlmei9rl6zKdEufOdnmgIb9sgkcdaOS8pDxtlJ3WMOk0u6qAssU4U4GG7EHX/kvkPeslFev34TW22w3D0Z6Hiw/Ynsw014b0MTWzuimeHqA8H4whWaYqUKKFpB0SCNzhdZrMrBCpDx0Wdr3tY8k8jttAixKB9SizKYS9Ke71weoLYK5L18KtUx1hXW2VJ9MeDlgFgT3JHExSKR+AJnn/ecCDyVqZZiZXNfAVqpHMlvV7xl+kfAKrGOlwyXufO/T/oNZLoS275jd1KeuUiRzLLAJkz8WJLlHk10gDqd2TizFRixKuDmc5/N/ajUDCOBeUz7QMuJ8vMAJIK5HHP3ktieQsUVfn64mfRx9ZUsb0qxWIJeLJURLUUaX2QUAC6vpheHZE8PejNYNBAL28KaxNt2btGm/xr346s9Rbqrwti4XASEpi2CyfPjAg0n5dXLQ00wkpqdyoAXAxQWzwFhcaurc5bqlqSI5MRbc3NMOq+TLgVmUxqc1yYVIUc8BWZHIo+WRon1lY6XjJD/fbok6XeRyUpsR5IUWNIHzeswvSOAmzCYAoNuCdACCDwrIAKpsYU70C1YEU0vMXud+WHudna7xzhj2QDU4IOl57acWl6pRSDv88e6OJc6Yi/qRG+FGNL8CeZj98WyJE+LuNYeVSbIOSNMkvcLl5ttqKyo7dX+bgWN9FA4fENVcApAQSw4xWzl/v5rVyBikfpjT2i8zcdqry/NlhsS6D+KjFI0p2osDgVleShz92rovYjtRUNHFez8RPbZZ9c+PAWWyEAm6dyiRQrJpBf6SKfuIyRZzBTOW8tUJbZth/7nSoLs3LknCb0kr4s7e50jUGT9sWWH/Lllu6xZ+4cs+/l3+UE/e/bsTd6FXD1VPfRgqXP0ocISUmk+tY6q7GqVgZuAKwBQYG055cuJzi2TiHvRGFOKZenswGMk+kJWC1MG8S7ACJFkzljlBFTFg/WEQFUEU4YDpu2rBgysntwpS/2EtVKhltbg6q/nqOJLhjgTmkvrbwZtlhVAHLM0vnbuA/p8apV2uFfklRvt0fBLYnUoqzI5fwcAXOCWZOkUlCWKGhaUfPlEjmwRXoFxLpZjqhWY+4WC6xL7yxFPgdmRyOOlUWJ9pZNaYslgp3A/TiYqsb//1jfXJMiOnfpWmUFyfsfmQe8Gl+mMD7+WYVp5etESnViSJBTyvO2mTj7llaQu09sNYA0opMhPCiVlq4r01AkTKwEXl3Niq1Jf5MZpSiNVycCsgYc7BVJb3HIwTUCjZGW5KqwhjUyu1yFHKvquqWGnGHVaYBwIKiviTTC4N7/MuN5qqKLrN1c5EscblyLuvmRJmSoGtEHpEFul+aMnTT4Zz3HCVToGz6jF+HUUV9T7ur26KUdDLbRQiEjGgmcsV02ZTjTuRjmXSIICIy8tlQJs3i0UuMyRfHbFW+b9CABGeEstsROb107JzVgllinoxJLFiyblOXdkmAUW6qFwF3c+q4nMmz5EQim5UOeG2n/tpafJhMd7Zq/ysg8WDo0Iwq//fD/ijhImCPEzcrBINkZ54dp78nz/pE8bWNcf1QlvxO+GfYJ9TgEqTp0xXG1IlXpKZTUnEPVnjoh8PUnksfZKVXWQ5nfp/9E7axrARjKVF9eCMxEuxk5D7ZVNDa9Zj5rt/PrcbXqZdRRatca58978Z6pS32OqPK//UeON6j485RZT4wu3JC8OUExZ2bjCAGaWzbZ7Qi+J29lYYOhWiR3hN3WLg6XeU2DuwcnjbZTYm8/3ltYtUqfE2l88TDJBiZUsqW/GSZC163USyiI58MB88viIK6Vi+TIJ3fVBZUvI4H5dEuojY04mEdgxMe27L1yCWCJYXdBLgfqzhK7Nexj0HMi5sTox33aYKpm39p3qy+3CPUi/qxebPvxH/WtUNUaJWSQkVkiQ6r/7TsDdh1UGgCMVZUbgHMSN6XRlcnEAHLjPYIafoG5MBHAHyr2HLsNJ6xvUwtoocs1EZfR/SBGEA9Siu8NwT96tChNi4Vhl7x51My6K9azY2lPHzS0o8BzxFJgdiQxa+pTYuD4pU2JQOGWCEitVIjkW2MpVGzLo14vuVviNu3TSOEMCcmrrekJO4X4h7z2obsEgbjhYF4hnTdbJduaIQOuKpGRqccGPSKKuhaMzIHAPXqzHERTT450Nqa3Zk/t70TuqCKoaBdn7EMNSkbtVavfgSkWwlMjzwpp0Cuz7H442SbwWUci4oOhQ1KWrOFsHrmM9AqVHUIIwbgCjZx1KrVveD251mjNCfwN8SaXArOIWB8uKp8Dcg5Mh24ULF5A3VYmd1LJOSu4oE5RYshjkf/ltfUrGKNWdNkuQUqxZI3Vh7Q+yTX8/mN6TJUzIEN/Cc8gb/BPnhU/Mtdel9hgxJ5bplqrHGxCKvS50TU73nK0QTZzwOLUWYZIHIo8l+MHD5iyr1GwfziWxP5CbQ5sogXEpg2Qkyflm9QIQX6tYS3kQVcnFKlivqRTos9zieE5PgbkHJ4O2UWJvPNdbTmlVNyV3FUqJ4eJKh9SqGeaNMYYb+HX1Jtm7V5Mrs0yOPLxCQndcuWLZhM7PmJOxvpwovERv7Dx1tRHbeq67WlXVNFFXrYtMFkqZXPlyDp2V62+CsixYksTyEBQRBSpLaTvcq8g79xgrc8tasx3qG8Skj03eYekChsHCXaDXr9IgdisslS5EXiQg73UL6RI5kp6Zyl7NW8Y8Aiixic/emlYllizLKNLD1k6SAvvrr73yzXe/RLpcxh2njlkikq7fKZF7jHguSbnA2a0Q77ryVQMVJwfryBPC16my59kloIbpCuyApPfTF1ITo7LXStYS9CPKiFjdviKa2jkuxVtnmyKelnORa8LCgdhK1Ez01Bez2+Zo8O+aJxs2DlsUlFYkBj+jLsjBtYOfE27v5lXhjiZ2DOsumFsZwE6OeArMjkQGLwsVMkrs1BPrpeQu3ZbYEdXKp+Q67k4PrXyQj6HfvT+e7c+++jGe0/L0nML6uyYiRTOMgSSuZyFh1iam8mZ9/RRDqXTm7YYVvc9Hqow0DuKuHRbqYvT15+pQR3PvR2ECj4fANh4hZwtofyKCAtmmAAvEqYQAKwDvR0ocbJZ8wwiP/OmIDwHwiISGbHKxIQHu9pS6Ed/VMisDlKFD3Yg2pgT6MVaFFMnq891onF+u2l/7erGWp+7wFNi+UcnsFZTY68/0kjYauE+FOJVYbU2GTZe0SBKh8Wdf/ZSuW07adQoWzJ9QXwUKJHZ+QhdPxsmwSMBsbuXyl5RaoZDIsjkmz4mJGt694uVEbphqGDgSVRb2WnYJfP/atxSdpyAQrh2tABKBEWToLxpPUgV01l3xJ/WSbAwsH3osX1mXnGmZGNjkO80dkRtWsoJZh7sQBKBTUUcTtzvsOP/TFS6hKQhDNJa2QOQRBXKcq27ceIScrGS6f533sGiac8u/Tt5fjngKzI5EFixRYq893UtOO8n/Aybztq0SSyezRdtT9A04CTJ77rdJ6CW7uiiQX11M2SzU5nIWmKRgIwjAB1trwcUrTGJtb/UGvHiteUo4EAcpaCFc1WDneAAdh5apg07UV72mSciKWHQL8HwsD2JKLS5zH829TQ4Vbr0h+sLE/cBagTJoP1jvTf8GqWp8Wt/c50XaA4EuOU9nD9R7Hu5vbVMG2EP9NASLDSUWiUbKtPZ/w+IxsY8BbvQ71BS1RHli6ZGSEK9EIv+Np18saesqdZ/vKTD3iGTPtlVip5+kAdcUCErs+n5P6/9L/Y+ZBjnjlOQ8x+o1m2VBFroRExniYGlTifSX9nPfHxV4yWBv8ts3KkpurE68vU1bXGlwAoI0jCTkhOE2I+fpuPMMg4X7HFBusHG80U/kiBbuo4HbjbuaHCrcjd9/YJCTq742beAxhE+R0ijnDFMlpooiVuFZESf7hFNJOYltx3Y2baP+PkDk1Zu0qOUDBuACGISilhSyXD5fQSCbo+4pV0PrAs51IIEdX+gLh3McbFeUmHGUWEnPLGUv7i2TMgK4nl59+hZpe3JyJn/3TaHE/vnnH/fulGwTB6tfu1pS+p7yrkKLPcmOEaCe1A9zzL3C+N5L3YWPqVvsDlUIbftrzEctL6cAUhh/pULLdxugw2066R6ik1k44RpM9OR4LfvILIO1J39splo9z6qyCydNVIFRMZp8MXK0XrpO88bUg3DrwUorpS6+4aoAx19l3HtnqesPN2MsgnWESw6GCytOl6kT8eeE2Nu2YZf/KnpxRe4WuB4fOTMwnpa7Vfg9wRRN+DPCHyWvDSBOMDm2U8BeT4EFDEf2bKDEXnnqFjkjSS64vHzyq7qfmpTLv/H2pwpa0v+onmT+CEAHZV+SumgcrGZrdcepS/TQ+oZUFldck26Bz4G7r29FkbcHazt9ecPSiSQAAUa3U7fkiSLT7o3UOvzxR3Wif3ugkg47wBOcsW2DWjDq/kOwavpVVgj/JYHAC3M0/DcxrSXvmxigbYl78937TZzpphmq3G+zR2JbFi1reBxxpfZ4PhAUw70/1SW2/pytiVMmUz4Zp27SFcF7hDXfIfkd695qlo2AVWIXXjVKpr3/ZZbdvf92L+zUUu4c+ops2rzNvzOOtZWr1ss7730p7U5zBKvj6Mc7JQ0jgFWEVK6niqqrWkfTjCsLsEKLy7V8iQIqLtWJFgvkg5GmLd+4uqYOMst2qkzSJcXVyqIe2JEtdfI/XQSr8Qe16rA+sOCYcGENwapEocF84Rae6/NX/fW83MfZ/vBRw3toj4FKhPW+xCEmRmcRiPZ4NEtIjAHBUHTTSjNVsItVIfJSAOt/IhWWncTKtv94l1hf04YEPxv4/OGNA455CixgOLJvo0CBA+XlJ2+Wi64e5Zu8s+8JNAauuW6XXniSPPjY2wnf/phnZngKLOFRTHEHTPhM/gg1p25R68BJA4V1duUrpgAjvH0oDNyHTog35UWOOsH0kcpvcrGA9nMPWIhOodClWyAF/kb/jpmE3SwVKBIYQmB9DxVzIrYWTFAwn6hCJ14VqzBOVnlxf8DmiXHzTHxI+CZnLphQXgUGe5RyKIkmHhnqXPd+0ipI1A4mpDvIAQFH9Ck8yfYRQIm99MTNWT1x33xNO1/9qkR/iznzFstXi5Yn2o13fipHgDd/YOBWnMqLfdAoDVErGlg5wiQ7SCfRVtfohmMCezNOd5qv0yi/Gp6jqEd1HXLd5QuM+3KhKjQsBaohU4gTlyZ5WCAG4RsEMNLvE1N80nmZpbOM6xOXaawCxP/1W2M9y7RfOtsQHfcsqZZYEaWMKqCxwXP1pUGBJ8ipt5il+5u8PCw3EsrDSayxvlB9odRx0YYSW7fNcdyzwByDkc2rKLEXx94kF1/7iLw94/Ose5RyZYrLgFs6S99B4xO+99vueVFmvHZHwv14HaRoBJyM8SAKccfx5k1SrE3k3bhC5H51eZ10gybc9tccKAV1dH3cQN6XzTY3BultqgUUI8ANkJCWGb1gMZOfZqsZO+8B6qeL9D7hK4Qh/ke1uHAtIiAeqbN1TBuzHcs3fIcWpRjLebg+ccvaumKcC7LxqzdUAavionBlMPQn7QDTUKHZCSRhv1t45mQIKElncrazT9hKgqBEPQvMOUi6/s8//7r2ZM+mUWI9pX3bRtlz0447vbbHaVLzSPVzJyhUtZ78bs7be4J9eafHMQJ7dxuY+WcvG8UEkALKKATAwJdvmnWKQ4LWwwK46xuRYeomI8ZkhdgKrsL+1UQGHqMowW4iV7yk7XvZFqlfgjTEKrDKiytiMVrlhfJFoVnBinj6AgWb6N8x51qWC3uc2B/KmPNiEWfScrTnAenvv0CRnWopYhG6x+11HcfNvxpm+mB9kiOGuF2nZq/5JpejaGnnnvjWiQ1SHDSUnN436BHPAnMNSzj4eLpIbl23FNNmfk1upcAhlli2wcoZ3zHDrpDTz79XEq3W3P+el+SUE+ruP+VGYvoryKPGEOji1kNx7dwSeBMFi4q01gkdF5t9469U29AiHa5v1wXVtXVgToyIMh8TrvJbDSiLNWq50D9v++c9aGJBoRJdA6+c2Bb5UlaIh9VsbQpAAiiocaJRuMSAiBEtna1gFHW5ffWWsSSDMexbS4gK06GqI9vrJbJEccIpybjirsWCAaL//kP+XiH2xVULHZZT+K34jcgZA7gSitKJcziX2F4islJfNimLE0rI/arfIejRBK8ctM+s3rk3TJl7lEM2iFVil1w3WiZN1z/SLJLmSi11R69zZPCI1xO66xW/rJOeA56VZx/WSdOT1IwApTyY3HgLZ5IE7h0qAM+ESOFJp0zMielAwIurjlgLMPpq6kHgjfvpC52tjQvJktrCSpGoAmNyhk4Jiwg2ja3rTa4UtcUAkpBzZgUAAawelpvQ7rdL3Gy4Dfl0HWvg8AvUWkSZO2XLOrN1ULXUKjCqWJM2gMVHLOvupSJHn6wsHO8bpOPCyeY+cNlaty17jmpl2O8fOUPHYrnIuB6BZV3MWf5vBy+hf2cMa7hVx7RXhbkz9EnnqdK1tcxcrfR1yBPnCOze85dzM2A9XxZRH6DExj9+o3Q8o3HAM2TDRt8bO8jJJ9RJ+FZfeXOuvDjx44T78TpwjQDlSe5XBQJ/3wtX6Nvz5YbuKZTycp2eaxMmh9ljNCm4gUHorVpoIN7uhsC9bTKvjSu524Tbxhqp01bJe/Vtnlph1L+q0VoLRNYyxSB9xL6dFL4/Xi2TnxXirywVCBbWJc8Y5UXO01qddGcM1+Uyc5xvCkSOUqUBWpJE5HrtjLsT6imnoLiQZMWNTG+5v7EEbaoC7k8KYf6xWqTWKYb3MQggwtcJJMoVaopcpmMAcIVEZwAroSSUQg/V3rkflCZVA0LFvWjbQi2zMNRh+Z39eev6e+3SN8kQ8rdNvAxxPNN245JDiXW/frS8+c78TLu9kPdzgL4oPPvI9XJSx4GyfGXOG2vI1uEP3DTgOaHuVpPjdMLyJPERwDKh9EYo9gViWhWPMe6qV3v63YXuKxdSiwerzJ1DRJ4Tbq1G54tcoJMubra5z/ljThxnYrYWhLtf9zaWUbPupmIxCikY5BuFDEgCNyBxI5QayMdb9VojdcLfst7Es4D+Y0HZe6Yi9C0fiJSrquwgx+o5qhyxKj+doDEwVWJV9TnOfUBrbb3ot3KoYAyUPZnJv4A0Ot1nSrJAN7VaxwzrDyVm5yyqVk9S5YQVBvEwiE7auIX4JNYbY0Xs65+97haB27iB4xFqk1F1mmrZoaTsoeouHhnqqG9/XBbY/sx2sGVraFN2795/wg5mJh5EiT0/5gbp3E7fmLNIDjmopEx9sb8kWvNqx87d0qn7CFm05JcsevoMvVVykcZfEVp5nawKC1QhDO9AzG2syz4OcRmQbX3nqmLYpKCNX3PHX2iLgsD1hmsRxveLn7A9GDclE3E0gscEKwslcljD4MqLfrBOvtHJ/udPNdH4NaOsbj9CiXn1/wyKBgAFIAMsGVyYluYKKxB2DhQSQkI2Qsxu5gizTr5VSx0zC/8n7vRGXz8y0bSK/RtrEoQg7kFKo8BaQo2vSnVU+XfR555sqjYXKubo+18DroGVBJ8EZUoAAA8VSURBVLddMPlYx5p8M3dqQ7C27LMEw6GOB9sPz+HINuGVF8qz+3PmbyBYHzn74lJge7SAYKJCEcJME6r6wgMYSrbvCH0s1DmZsN+nxEZnnxI7vOohMnlCPylVsmhCw/jHn9ulfdf7ZfH3qxLq5z9/MhO9G5xhB4Vgfqf77ZZRFs7yJIccpblInxhLgdgTgI1IDBAgEBEUgwUaoEScBLemRfBv3GRO6DWuMHdyMWdiFQUTFNRv3/qPwL04XJX40BVqyZxi9hMHfLyz5oC9p4AJ/Tttf4+yu6uSQ+HhYsUdSpxt4CJ9ZlXgyGxVyhbMYfZE/gZ6f8v7Sr67RLkLt6ji3CHy8Fa9H1WuFfU6ToGTcWAtw+1Y4WhFIM411295ub8VgJhQAnpy1zaRSEwn/Ia4XaOVtUv1nk9THklVsO6XG3cfF43xj7H7mGM7LgW2a7f+ISQoO3cl3keCt5Dr9DXrwvyo2vrPLfpHk6Vildg5ZzfNqieoW+swmTy+n5TVPLFEZO36P+XE9gPl9ck6iXoS3wj88oX/PNxlTI5WzrzDIN7sdpdRInfq5I2A3oPHDyvIKa2vF7lQJyqnonMeX/m5SWbmbbzMoc4jkdehokJxILirAITcelAgCs8cFWmjbj/cVVaoP9a2nxIMz1Lrb6xxJ2LNrVsm8oBaL8S4zh6kca6zDSJx8XQzMaM4YKG/Xe8b6xHlRokY0H9A7f/eY66AhRkurmTvwy65n0tfMBM6Y4771S2gNCEYJgkcqwwORYA1PfXerGXW7WnDph8plu8D3Aw3lpj7Os7tg6qrRaqWYDjhZWPZbIMqvbueUfTh2nOMsT/h6kitfMdVhcYum/9Q7ZygYOlg8WQSsm/VbxvDPtWGTVt98G6UQTaKVWLEmCZOyZ6JvHHDI+WDNwdK+4uHyarfNsQ99LgTu98wWj7/+ie5746LJFt/x7gHIJETyQmylkqN1qYI5C61AO48ykzQuA0RyJTtBAkYAIFBPBjtEu2A1pNH9ExX09b9jbXSQa2aWCmUcGcCVUdIkAWajwRzeaFIqQUGAS9AB6ijbMmOmieZyRTOQAAaWHCj2hiLkNwqLBkmZgSACcoMxCI5bnA4Qn/FM0RrNZqeAr9xodpillzvHR0PlCPKsubJpu0r+rwQAROjRHAdwqJBIrMV7gFQCePCs6JYQwnPG0kAsdyvL8S8mIBG5INbkzHE3bxhuXHNOnPoIvXJ31GnoZFa7Tueb99aDCs/r1gXQ+vgTcm3Wq5Q50yS75b9GvZ2iP0t+UF/mCyWfPkOkHGPXi/ndWiWVU9BgvOHkwZJHbXIEpVHn54uZ1xwn6zboK6YPJRffo1fGaf1tmGAgL8Ppoyqx5sJ3hcL0smRIpEkH9tkVtxP43qYuJBPmR0o0lQnSysowh8+9oML2I+rL1RiL644wBKiijFaKVZW2TsGmNZYO1iHxOaw5EAcWiEeRTIvbbAkYGq/cZpRXigKACRW8RDHAqxhhQl6/gQDdihVye41sT+2gOVboRQMbeORphfrC8A5/jOhbQJsgkLf5x7VsbHjb1te8IgiLXNeINiHFYr1COLz2M6G4cS2TWTJfZDvRr22x/VFhdgW3Ipv6fh//JSJG0bbP5RdPcZpa32xiVLiUmALF6+Isvvwzb5elJx+wl8l+qPzv/ghYuPPs7B0vfuhUGLPKcrv/I7N3YcyertShTJqid2VFEDK/z5dIo3b3CbPvzI77SVYAArdft/L0rRtziSb0aOuNzdLJ0MLW7/8RTM5W+ACaDViWsg2VXRznzGuJ4AKPqSgTq41WpnjfBMvekC3+1TwWwvsR7kEE+peTY/+jdzXhbMWF+5LkmDhNERA7CG486j/BYfhGD3uYwrRiRPX37b1hvljUB1jYaDgELcVSR4arkCnO9BaNc7cKkAgq781fcTyjVsTJKYVy2aCwqzbzuF61fsmaRmEIQI9FBagFZKxx+rz4/okNoYF+d6D9mhmLFtdZV6MQrmTQ9xlzAoMhoSpM74I0V1su996R9+AMkR2a1xvxqyvI97Nxzrx7Q+CEiPJt0sn/WPPIilRvIiPaeTh+y5TFvuCCd35ug1/yrV9npKWOuHN+FBdQykWaMqenvCB1D2hl4x8fKrs2bM3xVdMUvdOih9rWRBT4o0eAlubL0V1YjuZk9f1Wi8TJ0MpIAvfVgslZ+5ASRBDQXC9havqGwnKbXrxfxObsoIlRYI18SkQhVhnCJYD+VwIsPz7Gpl1vmGSt24vCIVxhSFWgZgtk6v2QGuj8Ow+XIYoabgTExXcg3bsuEeLHNy6Vq2rGoG9k+iLNYxgbToFAIx1NfJcuBpDpUE4z0vHOm5kUgC6qpuUl40YRZ86Nnl83EzZuHlrbCeFaP32zM/li4U/hzia3t3PvDRL1m/cEvGiE7Vo4q+rN0Zslw0NUGLPjLpWLuicXUqMsb2y2ykyZ8pgqVUj5406gQGHvb7TJcOl0an95IVX54RFosZzmU0aM0Zh1VHF1bP/s1H9nUW6ToM61aRkiaKRmiXnuNOaAHmGoKzIi8LFV66ab9e+SZ8tXG8wOVirhXjZKzeadnzzpl1FY0colecv8+9PxhoQcyvwJ1JPy+YbbciZb0AMOgXr0YoTqYjCs7G0zb/ZFmaJYsU15xRiUE6yYuexmNfVerWy+F1DuzV1sLFcbR4ZicYg+wCYYFWRx2aVFb8B4A5ccj3GmeRt218mLPkNLlPXKqkVcUpMCgzrY+Aw/YNNkmDNXXrjGIH2Jy/lpxVrZcSjk6O6BeD/fQdNSJirL6qLpaGRVWIXdm6Zhqsl9xIgFOfPuE/u6X+BFC2iE2KC8t3SX+Wa3k/KYQ2ula5XPyyvTZonq9dsjqvX7Tt2y/tzFsmVt4yVIxrd4HMZJuPvvN4xVeUlrf82b/qQhNMLon4wC8rgBFsGxVI6sW8fzY9jwmU/YtGD468S2bTS7OO7Sn0Dtad0PGjDZArJvFbsRG+3SfJFLCzfbBnwgV3fuMKuGdejL/lZn+3g6v796Viz1izXKnGwueLbgwzE3TLTY/EB4b+zpnmpIAnZCgjIB08yVFA8Q6SyKPa8VC95CWp1tTKv/GjinwlcL+d1KnwPQJCfeP49eWDMFB9yMHzr2I7+uHyNtGx3p9x567nS9dwT0k6+yiRzxc2Pa0Bfg5tRCvyCXa4YKY/ef7lULF86yrMytxmoxKdHXaM17g7IOuolUKy3Xne2dNF4Xh8txTJ5urp8EhTYWN6atsD3oatqhx0iDesd7mP0OKJaBV9ydfFihaVYsUK+6gWgcjf/sV2wtH746XeZu+B7Wbh4ZVJfcho1OEL69ewoZ7VpmODTxXE6LsKfPjEnYslAZOsssWHh4U5WdnsZwAUwPnz+it1jlhVrGZciE3KyBVefBYVAG/XtdP8VrAID1YdSgP8Qse2xqjapUrCyzx2pVkyf/ymacYFh7cDScioY2z6ZS+vGpM9qjQN73r7JbLsVNIwgCK5aqlwjgClAZVoaLrM3/d+8CDU816Q3kBeYBNmnwJYs+03gAdyhb45bFeK+Sd2E32ri58JvV8jHn34vqUw8ppT8LXeM85WVb9H4aGlQt5ocfWRlKV26mJQqUUQnisK+SePgco43qxgefumPq2Xrtl2+Z9iybafP4vtJFedULT8f71vxtPe/lBlNvpbTWteXZsfXkOpVy0vlimV9aQFMqgAO4r3fGB4taU1RYk8+dLUioA+QCa+rayjLpEqlcr7K1Likh6s1PXXmF0kDZ/A3Eu/fSSLDyG/RpnU9ufGKM+SUVqpE8kpI2rUKDCuq0jGBk/dKnSxBIpJ75BbcRAA63AIEG0oqi/JzH09km4KTJ6jFh0ASPOUuQwHFNmwbVoDUfzPVbNnYHhaNVQr5C6o7Ti0YEnBBIJKgjCIByNL2NkMzZRWg7TOZS+J0MGLwYgDJbhGd/2wiuXXrul2h5IAh9rlYnzncAG/cxMIcS7WgtGDCb9DJoB8TJf913e8BCg332f1V1W0STQzIdX7aNiF4HdT3/LiuR+zhZ3UTplPu6n2e3HZTx3ReMinX4s/hmt5PyfjX5uTq7+ijKsuXs/Q/QxYI7sAHHpsiAIUA6GSTAFTpdn4ruUbro8HjmOfCpD7gcDOxM0Fe8bJC5S81MS5urlYbkzwbrCz9wUcqglFdRemUg6opY4UqU4toAxkJ6TACtdPw39X6OsSUC5nYx+yH6eKmmSbORMoAAvFvl4eV8kpjxCARqyrQA+YJ3HdYYFaZmNap+T6tt2HBp/fXb1HU5ChzHSzYQd8ZjsXe5f3X7jdPFUYzkdFn+S0w/9HkrGF9U/MNS9eoD9MvbkpicMQ9+ZAfBgLUKtXkXD2gl30WWMBeb+M/OwK89Y994EpfLiqAhmyVY2pW8aEsR917qbw5db689Ob/ZO7875NmlSV7XAoUyC+nqpVFLPKs0xpKkQQRlkm9P+JYuKCAnOPWerB1YPewP4SSdCsv7mPDCpPs2+Fec1eQ+U6+Q+99jSphBTbMeUxpkgaZel6mhd+FCPDECoTCY881eVfsI9bEJ51C/a6mCkSpXE9zt240KQ08A4UofeKzP/x3hLIgT2zxDP++ZK2hNEmetmhHcvNQYgB0sKS5dhxIwkRub58Cw/1VqJBq0AyV0iXVjI5TSuobbelS8Z8fz2ULZ/BYRnoelNjjI67Ul9V88uqkub44D4AbYmTZJiXVBd3jwta+D+jRmbMXyuy538mcuYvz3OOAi/lkVVptTqwnp5/cQMolSJeV0t8GZYALy7Kbp/RiSeicvDLrfqPgIpRVICcRS8WEhdDuLmNFgIhEcHGdpcoOgVUfFhE+eSnE5FBgpB3wHDBdIMTrsDJxZ2IRAaxBiYBMtM9gWsb3DTgHsAvXBbbvBr6AbmQs7XjGd5WEztrnQkyoF+9kbwSycAQg9/1ME9O/W7pKYGHB7RiJDzPex8QtCJvIsXUP932Oa1BdQFF64o2ANwLxj4CnwOIfO+/M/XAEYK4HOr92/R+ybv0Ws9T8wJ3Ko7h7916ByBqwk01CLqCAnQPz55MC+fMLVnepUkWljFr7WPwHqYV1WOWDFMV4sJQtXXw/HC3vkbwRyNsR8BRY3o6/d3VvBLwR8EbAG4E4R0CdnJ54I+CNgDcC3gh4I5B9I/B/l7/WykLGwiQAAAAASUVORK5CYI"); }

            template#template { position: relative; display: block; background: white; color: rgb(51, 51, 51); font-size: 11px;
                 font-family: "ING Me", ING Me, INGMe, "Roboto", "Noto", helvetica, sans-serif; font-smoothing: antialiased; }

            .clear-float:after { content: ""; display: block; clear: both; }
            .grey-light { color: #adadad; }
            .grey-mid { color: #767676; }
            .grey-dark { color: #545454; }
            .greyed_row { background-color: #f4f4f4; }
            .font-light-bold { font-weight: 500; }
            .font-title-main { font-size: 1.25em; }
            .font-title { font-size: 1.15em; }
            .font-subinfo { font-size: 0.85em; }
            .v-spacing { padding-bottom: 3px; }
            .capitalise { text-transform: capitalize; }
            .h2 { display: block; font-weight: bold; font-size: 1.25em; }
            .h3 { display: block; font-weight: bold; font-size: 1.15em; }

            .header { }
            .header .logo { float: left; width: 35%; }
            .header .header-text { float: right; width: 65%; text-align: right; }
            .footer .export-details { float: left; width: 50%; }
            .footer .page { float: right; width: 50%; text-align: right; }

            .heading { display: block; margin-top: 40px; }
            .heading .heading-details { float: left; width: 50%; }

            .section-part { display: block; margin-top: 40px; }
            .section-part .interest-label { float: left; width: 75%; text-align: left; }
            .section-part .interest-amount { float: right; width: 22%; text-align: right; }

            .section-part .section-floating { float: left; width: 45%; }

            header#header { display: block; position: running(header); }
            footer#footer { display: block; position: running(footer); }
            main#content { display: block; }
            #pagenumber:before { content: counter(page); }
            #pagecount:before { content: counter(pages); }

            #footnote { display: block; margin-top: 40px; }

            @page { @top-center { content: element(header) } }
            @page { @bottom-center { content: element(footer) } }
            @page { margin: 170px 50px 100px; size: A4 portrait; }
            @media print {
            .page-break-avoid { page-break-inside: avoid; }
            }
            .footnote > div > div { border: solid 1px #fff; }
        </style>
     </head>
     <body>

     <template id="template">
         <div>
             <header id="header">
                 <div class="header clear-float">
                     <div class="logo" style="margin-top: 20px;"></div>

                     <div class="header-text" style="line-height: 1.75;">
                         <div class="h3">Bank Deposit Certification</div>
                         <div>
                             <div class="capitalise grey-mid">
                                 Reference No.:
                                 <template th:text="${data.metaData.referenceNumber}" />
                             </div>
                         </div>
                     </div>
                 </div>
             </header>

             <footer id="footer">
                <div class="footer clear-float">
                    <div class="export-details v-spacing grey-light font-subinfo">This document is digitally generated</div>
                    <div class="page grey-light font-subinfo">Page <span id="pagenumber"></span> of <span id="pagecount"></span></div>
                </div>
             </footer>


             <main id="content">
                 <section class="heading clear-float">
                     <div class="heading-details">
                         <div class="address grey-dark">
                             <div class="v-spacing"><template th:text="${data.date}"/></div>
                         </div>

                        <template th:if="${!data.hasSalutation}">
                            <div class="h3" style="margin-top: 40px;"><template th:text="${data.addressee.addressee}"/></div>
                            <div class="address grey-dark" style="width: 60%;">
                                <div class="v-spacing"><template th:text="${data.addressee.address}"/></div>
                                <div class="v-spacing"><template th:text="${data.addressee.addressExtra}"/></div>
                            </div>
                        </template>
                     </div>
                 </section>

                 <section class="section-part body-content clear-float">
                    <template th:if="${data.hasSalutation}">
                        <div class="address grey-dark" style="margin-bottom: 20px;">To Whom It May Concern:</div>
                    </template>
                     <div class="grey-dark">
                         <span>This is to certify that</span>
                         <span class="font-light-bold"><template th:text="${data.name}"/></span>
                         <span>has an account with</span> <span class="font-light-bold">ING Bank N.V., Manila Branch,</span>
                         <span>
                             a banking corporation duly organized and existing under and by virtue of the laws of
                             The Kingdom of The Netherlands, duly authorized to operate as a universal bank by
                             the Bangko Sentral ng Pilipinas, with the following account(s) and corresponding balance(s)
                             excluding uncleared funds and restrictions as of
                             <span class="font-light-bold"><template th:text="${data.prevDate}"/></span>:
                         </span>
                     </div>
                 </section>


                 <section class="section-part clear-float">
                     <div class="section-part-header h2">Account Details</div>

                     <div class="section-part-list" style="border-top: solid 1px rgb(255, 98, 0); padding: 0 0 10px;">
                         <table cellpadding="0" cellspacing="0" width="100%">
                             <thead>
                             <tr style="height: 12px;">
                                 <th style="text-align: left; padding: 8px 12px 8px 12px; width: 80px;">Account Type</th>
                                 <th style="text-align: left; padding: 8px 12px 8px 12px; width: 80px;">Account Opened</th>
                                 <th style="text-align: left; padding: 8px 12px 8px 12px;">Account Name</th>
                                 <th style="text-align: left; padding: 8px 12px 8px 12px; width: 120px;">Account Number</th>
                                 <th style="text-align: right; padding: 8px 25px 8px 12px; width: 140px;">Balance</th>
                             </tr>
                             </thead>
                             <tbody>
                             <template th:each="byCurrency, iterStat : ${data.accountsByCurrency}">
                             <template th:each="account, iterStat : ${byCurrency.accounts}">
                                 <tr style="vertical-align: text-top;" class="page-break-avoid">
                                     <td style="padding: 16px 12px;" class="page-break" th:class="${iterStat.even} ? '''' : ''greyed_row''">
                                         <span class="capitalise"><template th:text="${account.accountType}"/></span>
                                     </td>
                                     <td style="padding: 16px 12px;" class="page-break" th:class="${iterStat.even} ? '''' : ''greyed_row''">
                                         <template th:text="${account.dateOpened}"/>
                                     </td>
                                     <td style="padding: 16px 12px; text-align: left;" class="page-break" th:class="${iterStat.even} ? '''' : ''greyed_row''">
                                         <template th:text="${account.accountName}"/>
                                     </td>
                                     <td style="padding: 16px 12px; text-align: left;" class="page-break" th:class="${iterStat.even} ? '''' : ''greyed_row''">
                                         <template th:text="${account.accountNumber}"/>
                                     </td>
                                     <td style="padding: 16px 25px 16px 12px; text-align: right;" class="page-break" th:class="${iterStat.even} ? '''' : ''greyed_row''">
                                         <template th:text="${account.currency}"/> <template th:text="${account.prevDayAvailableBal}"/>
                                     </td>
                                 </tr>
                             </template>
                             <tr style="vertical-align: text-top;" class="page-break-avoid">
                                <td style="padding: 16px 12px;" class="page-break"></td>
                                <td style="padding: 16px 12px; page-break: avoid;" class="page-break"></td>
                                <td style="padding: 16px 12px; text-align: left;" class="page-break"></td>
                                <td style="padding: 16px 12px; text-align: left;" class="page-break font-title">Total Balance:</td>
                                <td style="padding: 16px 25px 16px 12px; text-align: right;" class="page-break font-title">
                                    <template th:text="${byCurrency.accountCurrency}"/> <template th:text="${byCurrency.accountTotalBal}"/>
                                </td>
                             </tr>
                             </template>
                             </tbody>
                         </table>
                     </div>
                 </section>


                 <section class="page-break-avoid">
                     <section class="section-part body-content clear-float">
                         <div class="grey-dark">
                             <span>This certificate is issued upon the request of the above-named Account Holder</span>
                             <template th:if="${!data.otherPurpose}">
                                <span> for</span>
                                <span class="font-light-bold"><template th:text="${data.purpose}"/></span>
                                <span>purposes</span>
                             </template>
                             <span>.</span>
                         </div>
                         <div class="grey-dark" style="margin-top: 20px;">
                             <span>Should you require further confirmation of the authenticity of this certification, please feel
                             free to contact us at askus@asia.ing.com</span>
                         </div>
                     </section>

                     <section class="section-part body-content clear-float">
                         <div class="section-floating">
                             <div class="sign-glen"></div>
                             <div class="font-light-bold">Glenn G. Lagcao</div>
                             <div class="font-subinfo grey-dark">Head of Client Services Delivery</div>
                         </div>
                         <div class="section-floating">
                             <div class="sign-diana"></div>
                             <div class="font-light-bold">Diana Rose U. Cue</div>
                             <div class="font-subinfo grey-dark">Retail Business Implementation Lead</div>
                         </div>
                     </section>
                 </section>
             </main>

            <section id="footnote" class="page-break-avoid">
                <div class="font-subinfo grey-light">
                    <div>ING Office Address: 22F Arthaland Century Pacific Tower, 5th ave. cor. 30th Street, Bonifacio Global City, 1634 Taguig City</div>
                    <div>www.ing.com.ph</div>
                    <div style="margin-top: 20px;">
                        Member: PDIC. Maximum Deposit Insurance for Each Depositor P500,000. ING Bank N.V. Manila Branch is supervised by
                        the Bangko Sentral ng Pilipinas. You can contact the Bangko Sentral ng Pilipinas through the following: Financial
                        Consumer Protection Department, Central Supervisory Support Subsector, Supervision and Examination Sector with
                        address: 5th floor Multi-Storey Building, BSP Complex, Ermita 1800 Manila.<br/>
                        Consumer Assistance Direct Line: 708-7087 and Facsimile: 708-7088. Email Address: consumeraffairs@bsp.gov.ph
                    </div>
                </div>
            </section>
         </div>
     </template>

     </body>
     </html>');



INSERT INTO [rtb].[TEMPLATE](template_id, LOCATION_CODE, type, VERSION, CREATED_DATETIME, CREATED_BY, TEMPLATE)
	VALUES(NEWID(), 'PH', 3, '1.0.0', GETUTCDATE(), SUSER_NAME(),
	'<?xml version="1.0" encoding="utf-8"?>
     <!DOCTYPE html SYSTEM "http://www.thymeleaf.org/dtd/xhtml1-strict-thymeleaf-spring3-4.dtd">

     <html xmlns="http://www.w3.org/1999/xhtml" xmlns:th="http://www.thymeleaf.org">
     <head>
        <style type="text/css" media="print">
             body, template, header, footer, main, section { padding: 0; margin: 0; position: relative; }

                  .logo { height: 70px; background-size: auto 50px; background-repeat: no-repeat; background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAbAAAABsCAYAAAALxefKAAAAAXNSR0IArs4c6QAAQABJREFUeAHtnQncVVMXxpc0zwMaKaGkUdIsGSKkyRCSMs8hDcpQIalQKDJHmUMlpZDiK8qYJGWoRJqjuYRv/e9+d/fc8955eu/NWf3uPdM++5yz79teZ631rGcd8K+KeOKNgDcC3gh4I+CNQJaNQL4su1/vdr0R8EbAGwFvBLwR8I2Ap8C8PwRvBLwR2D9GYO9ukSl3iWxcvn88j/cUEUcgf8QWXgNvBLwR8EYg00bgn70ii2eIfDdTZOVnIje/L1KwqEi5qiJ3HCXSoKNI29tEqjYKvPONK0SKlhYpop+v3hD56AlVeLpv7x6RGieKXPSY9lMs8BxvK2NH4AAvBpaxv413Y94IeCMQbAR+/Vrk2W4iv33rP3pab5FzRohs2yBy68H+/Q3PEelwj8jW9SIz9fiP/xN5YJ1u62dwHZEdf/jb9pwuUrutyO6tItOGiOQvJHL0ySJHqWLzJCNHwFNgGfmzeDfljYA3AvtGYOFkkSXvGauqSn2R4qqgdv4p8vDpIsvn72smV70q0vBckWsO9O9j7YADRCxWDYV29USRF68x1pez5am3iGxZK7LoHdO/PXb2QJF2g+yWt8ygEfBciBn0Y3i34o2ANwKOEUBJPX+puvreMjs/HGOWpSqIVKotUriEo7GuvnS9yKHHiuTT0P4///iPWeXFnmPaGCtt4RT/cbv2/ki7ZpYly4tc9ZpaYK3MNpbZkg9E6rXTa3hTZ+Bg5c2WZ4Hlzbh7V/VGwBuBcCOwe5vIKFU2P38arlXuY0VKieza4re43C36fCTy1gDjSnQfc29XqGnciNs3GqX3l4JEkMObiFw3SaSkKlJP8nQEPAWWp8PvXdwbAW8Eco3Anh0ij54hskyVTbKlSj2RX79JvNfyChTpO9e4MxPvzeshzhHwFFicA+ed5o2ANwKpGIF/RUafbeJQ7u5xD7a+zlg+KxaIfKugi5VfaCs9J+micbPiBxnLK1T/9durJTY56Vf2Oox+BDwFFv1YeS29EfBGINUj8IHGoV7rFXiVymo1obhOuMoAMpxHt6l7b4Lu/+pN59741wsUEWlzq8hJN6ii1BgY1iBQ/aWzRYibuXPMLh6r93V1/NfzzkxoBDwFltDweSd7I+CNQNJGYMdmkQHVFAGoMSwrFz0ucqIiBq38/p3melUzOV9235qlIk9fKLLqK7snviUW3tWvixx8RPDzAYNMvVs/g/zHi5QUGfqL5pVp7M2TtI9AvrRf0bugNwLeCHgjEGwE9mwXOXuQH11Yo7Vfef22SGRIQ5FBij7sW1HkZUUcrlliegFscceXIi2vDNZrdPsKFRe5YapfeS2dJfJqT5GHThL5XpOkEeD4QOqbX2a2+UbZzs5BR/r3emtpGgHPAkvTQHuX8UbAG4EII7Bjk8LmVTl8TVxJlcVd34hUrqPJxmqZ3dNAZJNaOk5BoTQ6X6TbUyKFSij6UJGLdyq4YssaZ6vo1lteYfqh9Ws3i3zwcOB59TUud+6DIodo/8D77zgyJz6mzUocrFbYShHcj56kdQQ8Cyytw+1dzBsBbwSCjgAWFkrKp7y0xbGdjPKi8f9UQbmVF/tx6X32qsjwliJ//6WWm1pRFz+hykyX0QiUUcXKqa7UxOdGF5gzfvkit/LiyMK3jfW38nPjLjy9n/8KsHx8rvlinqR9BLxsvLQPuXdBbwS8Ecg1AoAwNq3y7wbhZ2X+i3Yt+BJYPC6/Y5SZg/Me2ap0UOqOJH/rp3ki36jy+eJ1zekqLNJKARd1zzK5XAVzLCYUIdYc8vUkswz2jZL85HnDr9j6ekNNBSUVgpJt1t2sZ+s3FjAvCtBrHVjAoDDLq3s2g8VTYBn843i35o3Af2YENvwc+Kjfq0JCIezdJbL628Bjzq1D1Wprq9ZQrVOde9UKK2Y+ZQ8TOV6tK3gS4TYsrhaXW6zyYj8xuDJVRN7oGwgmsefYuBvKzzJ8QBzcVLkZQSxCKJwtsv5Hk65AsviKz0TW/5T7zhm7K17S/TkKPneLPN3jKbA8HX7v4t4IeCPgGwHiSk7BIjtnuIGyt7hc5GO1cJxC3InYV/0Ozr2h10tXCn3MeQR3IrD4Gq1FHtO+QTg6xbJxbP5VY2DrzRGsv473Zr7y+vdvw2zyjYJVvpmiLwaK6AwnKON2d2mLHOX1nsYAYUg5o79aaAXDnZm2Yx6II21D7V3IGwFvBEKOwIgTctM7oUjIs0KwwlBqcxRWX76GWgUvi5QKo5SYrH/50sTDKtQyfdjvdT8YiwNr7Ijm2qaEPRK4BAwyrJnIhhX+/TZ5+YePldW+lX8//Iv1zjb3lWlgDhTtKz01n22GulUVEBNMIEk+7jxt857ID3P8LYgrAl5p3sMor94VRKo1Erle3bLED/NYPAWWxz+Ad3lvBP7zIzB/gimP4h4IrKH+8zXmdJz/CFD7AhrL4lgwgXCXXK1Px6tLT9v2UUVTRd2MTkGBTb9PZN44kcOOFemtE3YoJYbivFfb/L3X9ICLsd1Ac423demWE681NcXc+/N6e9FUkfFXivypStnKAap0iQeedKMhObb7F00TeeHyQDRnsbIGVMNLAWhPXiJuVmWHizYPxVNgeTj43qW9EfjPjwDMFoPqmPgRg3HKLYoCHOkfFkqnXK/urupN/ftCrf25WhGJLfwW0+WqGBt3Dd6a6s3kk2GRlDzE5IBVPT5429f1noDPH6F9w6X4y9dqfZ1o6oYFO6NNL+P+DKVkg52Tjn2/Lxa5r7F/rLkmtc7qtDUAGiy1SvpbkLYA+AW6rnCC9Qo5ch4+p6fAwv1A3jFvBLwRSO0IjG7n5z08605TRfnGYq5ragym+aUindRqgt4plCx+V+uDfWog9UXVYoASKpx8q5YGBS6xIo45TeSg6uFam2NL3hd58nwzyYdrTXVnFGhpBYRkksx7VnPt1LqKVQqXVNehKnjctrgiLfqy4xCNiQ2ItbektfcUWNKG0uvIGwFvBGIaASbB3g6FNEator17RG4KEZM6Ty2zU2+O6RJJa7xqoWHc+GScUZDRdIzb7dq3/PXEojkn5W3+Fbm/WWAh0EjXBMzR+gYRXjCIiS1Tl+vIU7XmmrpVgdv3U2utqsbF8kDUCeqJNwLeCHgjkAcjAHrPKVg394dxFVKHC/n3HxE4EX/7xvAfklxMZeafPzEWFS6wZAs8i+R6kQsWrWzfpFWj1bL7/oNoz0hDO7VmLxqjiid/4LW6PCzSc7pBGAJUoWCoTS8gPWDmcOOeJWkb65J8OoTxGKPglY0rfJvp/vIssHSPuHc9bwS8ETAjAKjgf09HPxrDV6sLS+NWyEvXGUSi2Qr8JqZ1q1oJFY4O3O/c2rpW5HV1MaI0sQSpsIw1wcTOku1L9N7qqosTAbwwxAEmMXuj+yavbJDGn3DDZYp8+KhROqQDgKhEIQFOcQpgF2J9f/7u30ti89mDtfJ1fcNMwssEAqjDVx/tILOdpm9PgaVpoL3LeCPgjYBrBO7SyXDtMtfOMJujdxoEom3y+SsiT11otwKXkWIzD59uyqQEnmW2iPV0vl+k5sn+oyvUyhuq++MVi16M9/xUn4cigrkEKi/AG78vMQoOYMw/OUrKeQ8AWsgJ+1Vdq1YYt5s0Dkn8MU2irxmeeCPgjYBzBHbt+ktW/rpeVqzSzy/rZMvWnbJ9xy7ZsWO3bN+5WzhetEhBKVGiqJQoVliXRaRk8SJSpVI5qXFERd/S2V8i66vXbJYBQ17a18Vzj1ynnh11A2W7/K2xrmDMD+GeC+QgEHor8BdS0HLmA2aPz3oqaFB24cAetKZYJfGc6hoPIvfJyiFHGmQdtFNOSdRFNusRkdN6a7KzG6DivEgerH/8hBkL3LM8M0TG0HBFkp/m5m4Bm8ew5sYVWe7w3MdTsGefAluy7DfZ+7cm/2WoHHJQKSl/cKmY727nrj2+CSjmE+M4oUjhglJSJ7NMlB068S79Ud+m0iT58x8odWsdlqarxX+ZzX9sl/lf/iDzvzAfxmjNuj+UJUiD3XFKEVVuR1arIEdVryi1alaR5sfXkCbHHaVKr1DMPX7z3Up5bdK8feeNGNRNDi6XQa6ofXcW4wrK6x/XfFO5rslLIofrj99yd0j8xV13C4ooiH/XqruL82cMM8S6oWp62V5BHv61S+SaNwxP4oblJukZVnq38uKcZbPtmfEtiYct0BeRREq+xHfl8GcBoydOBw8l+XZFS0enwEL1CnMJIBFK06QB2LFPgbU9/15Zv3FLqNvK8/39enaUgX3Oi/k+nh7/gfS7e0LM58VzQkl9I5/yYj9pfOyR8Zye0nO+XbJKWncYmNJrODsvU7qY/LboSeeujFn/9PNlMmn6Z/LuB1/Lsp+Sr9R37twji5b84vvIO/N9z41CP65edWnR9Ghp2eRoOalFbSlUSGMtEeTLhT8HtFi/Ycv+ocDcFE28sd+hQAlqawVTXozCKs2/wkJyS3V96+eDWCg8IIRwUvZQBSDs1Wvp7++s7xXsHBJ3F88wUHuqM+8TtYThV4SvMRr5VkESmabAiBMOUMvp5RtUkU+M5ikit9myVmRES5H295hUBhKmUySp6zlFN5zJ3W7ZukPadx0mC776MZNv8z95byitm29/To5odIOc3GmwPPLktJQor1CDu3fv3z5L76HH3pbO3UfIYQ2ulStuHivvzf5G/v47SIwhp6O3pmk8wiHrNvzp2MriVRKYnXJyTwVOHKgJtJ849/rXyT+y7PH+vbnXCqhCAcRBAnQ4KaFtkI0rzTLcN67JwRoTOtilPA+urrD+W8KdGXgMNCLQ80yTEuVFrnpd41eqpEEYJkPgjIQQGRCIm6g5Gf3n9KG/jJEypYtrrO5f4d8OfYPcpa63vJZiRQtL4Zy31HjcL9w/7hz6IYaRDrFKbMoEtcQauv7g03EDIa5RrGghqXdMVcGliqX9x59R+LlD9BVqdz7lg6tYvrSU0HjQwQflvZtrz5698vqUT+SxZ2fIV4tcE2aoh0jT/q3bdspLb3zs+xxUtoR0btdEzmvfTJo3rrkvxvXMi7Nk8ffq2nEIFth+IW5OPjtxAtkOJuyvfUawI4H7SEyuGMH64gxiYMia741lZbaCf9u42+rFgcdxWUJs+9HYyInNnEn1Zkq/HNYwsJ9M2SKZmw/0WdQ3I86F2xaGDnLBeIkoU1kTv6uKlNNP0TLGDctv89krubkseS5+j7vrmWoAJ16jO9RqTaKERCHyxkgQ+6tvlstb7yyQqe99IexLleB+u7BzCzn1xHrSoG41qXhIGcmXL3kPi3LerJP21zqRfarxjqkzvpCFi1ek6nE0FqbuxAxTYs6HBZjwmVqKuNEmTPxI/twSYuJwnhRknQn3gk4tpEXjo30AhgMPzHujfruCLbCwnnj+Pck2i6Vi+TLSpOFRsmHzVpk7//tcsbgRgy+R6y87PcgvkWW7Xr1JBGCDlRHqdsJyotJxKHBHr1mKDDzJnpF7SamToU1EGp4j0v253Mede5ikB6sCwuo7Re8FwtpwwiTdv5qfgZ62Z92lbrLBIk+cJ/JllO43crBOvC7clbL3GAwdU3RMlgd6DfY9UK1TzO9SRt23SZKQCszd/7Kffpfu149OyaR/rr55jr7/8rQDIN6fs0juuO9lIVCeCsl0JWafecOmrXLhVaN8E6bdF2nJsz018ho5+/Q4c2MiXSCO47ykjHvlQ7nngYmydn3irjasd+JVtWpUkepVy8uhlcv50IZF1ZolpgUqceu2XbJ6zSb5acVan0sSpcN4pkr63NBBBvc7P1Xdp6/fcd21OOQL/utd8qwIdbV6ldN9//r3O9cgngUc4BYshOlDjSW0Z6fI+SNVKSmaLpyAgiTuY8u03KnxNzfpr/P8V7W/WQ8794hcrUoLZfmIWobQWEUjTbqKXDYhmpbZ2wZy5lfVJey2snki0KHXTRI5vGlSni9qBcbVQGw1P/N2WamWWbKkwxnHy8tPRvhjS9bFgvQDOu/SGx+Tt2d8HuRo4ruyRYn99dffvheUSdNDvD05hqJShTIy4/U75Yhq+seYIfLBR4uk7+AJsmTZrwnd0dFHVZbTWteXNq3r+ZRXNEAL9wV5IZr9v8XyoX7+pwotme7rHheeJI8Nv8J9yezbflKtFidogGrKxJMeaRv+WaBmQtFZIcl2aGOdnPR3L1zClDNB0VnBbQfakDwn0g8oAeJkoaDG1cTe5lzicBRwhNDWKe+P0qRnvTe33L3UJFbfWSOQud3djm0SsLlXJvARukyyKy3YJfN0H8/64tUiC9/OfRvEKbGQj78w97EY98SkwOh75uyF0rHb8BgvE7w5sakfP3tUSpUsGrxBmvYSRD+x/V3ypbpLUyHZosR+U0uiTstesnv3X2GHAcur67knhG2TroO8gPS/5yV5avz7cV8St2eXji2kX88OPuh73B0FOZEXgynvfiZjNA4HkCRROatNQ3n92VsT7Sbvz4cQ94vX/fcB8wWksO/c7d8XbI3YFYwPMD8gU+7Uc+416xeOVs6+69XNt0Hh9DpHEcfZ5PKugIgDYg/DBsUagY3f20ARjgtNH3yjSM97yGyjGPtXUwUYJHxytLrEYLHAmosklFmB7WLhZJFGXfT+a0Y6Y/84TnyQWmRuCi7qp135qlqw5yb0nNpLbMLb6eFVD4ntpBCtu3RsnufKi1tjAntq5LW+ZYhbTWi3D9hxsaITv8xsdGLlCmXlUn3DDyfkdmWK8gLt2fT0AXErL0AnXTR+9+Ws4fL0qGuSrrwYxwIFDpRzzm4qs94aKPOmD5GLz2sVFXw+1G+QbTG9UM/hiz05D4LOi4ZWCuU0SoEG63L+L2FZkQdGTS+UF4JbcOaI3MqLY7SHIomSLUysSP8FIj3GGYAC287SLe/eH1x50Q5UYTTKi7afvmAsQeJm/xXlxXO3UuDGzTMVNKOWr1Ng93j2YhE3H6azTRTrMSsw+jy1Vb0ouo7c5LST6kdulKYWtWpUlpNaulwHSbx2tiixSL9JuwyJeT361HQ5ReHwPy5fE9evdEKzWvLFB8MEZgsSjtMhDepUkycfulp+WPCoXN29jYKUYv/vt25/QSECnnALtEXRCFbV1MGmZbtBmoz8ZiDjO0APkmjrdwjeG7lbPsmJtR1YUKRZd5E71Qq7+AmtTJwTY8RCnP1Y8D5i3Qu7Be5ROAh3/hHr2dndvkZr85JQwWV1ArV/rKPhmYzzCWP/H6QXqnvMYXFeLvC0+rWrBu7I4y3QdKkUlNjZXe/PaEuMSTacwCiRlwJQ46YBz/mS08PlT4W7x5uuPkumvTxAah5ZKVyzlB0DNj/y3h7y4eRBMbOV7BcwehQQ7O6xCiS7MGiQfGvrUbHPLVhQJOcCltinrByNrp2kxLwaLrj4ScdOXSU+dsJVxrojLvaUxsNCAUoCz4xua4cqLqy+vvp3N/mO6M7ZX1qRYH7rbP3tXEps11aRRxUEg1Uch8SlwA4/LHEXInxuVQ89OI5bTt0pjRqobzzFQv4PSgzqokyUCoeUFibYUHJc/dSPUahrb9u+Szr3GBG3y7C48hZOGNtTht5xUcrcxaHuPdj+4/XvDbfifbdfFDXNFDE/0gSyViiDMlg9Hat1GUnIM6Ki8uUvigz8Vic6tWKGqvIjqZik20gC16GbYR2CXioQH1QtdGL0fL0esa1ytCkW6SqxHwcpiWty86rYz83mM0pWUJTph7mV2JZ1Smd1elyWacwgDsaPWE6itERMJuu+fyajfg7y3MoedWlK893sA5Ps+/aLt2VUsrO9twat+wRlqSBWuHXFeNssrUsU/xldhsQNtCFu++a4PnlmdUUaLDgYOyg46hclEY4k380dKdWS8BIZ6TopOf7DR4adIVznEMue3k+k3tkGMQhn4s+fKnHv58byAoiBm/BoVUbEzsaeY0AClVUxdlLF4KYu+nC0Wj43mnjMOQruAK1oBWvQ0loVKZkb3g0nJsnOENX+qErta7XeiMOFklpttETLe6GOBu4nCbrjfYH7/gtbIBSHNcvNgtJUY2KXxja/6F9C7AKrQ6LCBJ5pQm5POOsjmfdrLbFMBHaUKF446KPmFVoU9pBOSr8UL0qU5OC8dBkGHUzXTtyZc6YMlkguXE5bl8Gcpa7Hyr0ZLPZlWx1woMiN00RuU2VVr51hd8CNd6t6auDWgyl9uk740xR1+NnL5ixAGbgRT7ohuPKilc05AiLvVF4cgxx47VKFyffyJ1ZjfT2oCvK57iJvDzQuRaD53Z7Soo46+d6koASY8Llft5z3oIGHR2O5ffWW++z/xjYpBddP0d+ieODzfqou3680nhmDxKXAChTIH8MlgjfNBMaGYHeWzvvKVCVWvFjwl4vSpVLgTgn2Izj2AUO/4MqRMm+BTjJxCKTCMKJkmrs62KNQbeG9N+6KCCbK6jgY1hHgFcrTt7gscBigKYLKaO5zCqiooQqkm0LhFWrtrrBMH5bNAQAGCcV1zsxtednesdwQilK6pUhpVX5qneGivOgxc5R2y2Yb5OA79yjQoL0q0YMMcweuP2D4V6oCHfKTSBO9R6cQc7viJZELHnHuzb1OkUsU538N0GFHonI94xp2A5kmXK1W9lrbKuJS/xI8cY5APMgw5/mxrmeiEgP6HUwsL2WwY6nad8Ntz/gIb+PpnzjruEdvkNpHHxrP6XlyDt6NV5662cf+EeoGshpKjwWGJdP+7tyuOJgbBh4j8oIqto0rcj9+IX1jJ9n4nh9MDlfuFv49oP6+fVdjTcNEJt1u9n8wSvPDRpjSK/6W/jWUGVJfFVbzS41lZ/aYb+inyDu7QxXYyFPNPZ5wpbOFWodDFPehbsdmPTTWUyvwmHPrlvfVXfaCJjevce79b63X03F2xyhxz46/Kupx8BSYa6jCWWCpeou3SixTgR12iNJdSHHcy7Nl/Gtz7OVjXl536ek+Ro2YT8zjE3CvT9Rk5XJlHLEaxz1ltQVWURWULV9C2Q2n7FZE2rplzj1mHeb4zsO1ztQqkS4PG6vlma4aS2ttilfaMwBHAMB4XPPCeqnFBLrtrdvUgttkWmz6ReTNviJ3qXV3f1OFtI8WoVSKU3Af/vyJSNexmuD8o8ktC1YfjBywB1uLPK/K1inke03QCfgvvRfcmqEEeH6Tiw2iMlSb/8J+ZXYKyLvjmReqe3H++KiePnFfYFSXyZ5G4RTYkNsvlPsfniTfaq2nZAtKrL0mO2cCsCNUMcd0KrCFi1dKr7uej3uYj9FCkvcOuCDu8/P6REAn40Zf70Osuu8lqxUYVhTy8zwtW/+dWQ/1DQM6YI5TNT5FvGSZvsxMvTsw+fWhkzUJWf9O4CLEvbdFLRpiYrj5Slc2DOolNIYGXJuikigzyIKXzzcfWDwg5KWQJaVVUH7bN2pM7FajvCiYeeYdJvaG0nEzcqxXJecWErKhyQpX/oV8MNIBYOhIpVBbbemHOYjHAwyVVZV6Ioc2CB7DS+W9BOubOOJlqqzu0ftxVoJ+q78mqJ9jWPCDnZezz1NgrsHJH4ZN/fe1f8j0V2+XMxUNR8HCZIu1xDJBiSX72WLpb9euv+Tiax9JqKTP8IHdEmK8iOV+U9X2lFZ1Ba7QyVp80ylrs70mGJWJx/XITS/kfEjYKohtgSwkf2r8lcrU8Yy2UPecU1BEA1URQEUFKvE4VUgwcxQr62yVe32zTuwo0SVqSVkAB2hHlBeCIsRdOFevidVHTKvpJca6iiaHjdhWuPgWbsaXrtOCmr+KdBhirpnMb6xZcs7mjQveK7XM2qiSxlVaoEjwNunaS521zvcrubLGIq3w+8BTSaw0jOQLc+w/eSicBbZk6a/q1iku01SJUVsrFWKVWF66E0NZYKl43mB9Dnt0kvwUJ8MG/THxn3yCTnz7gQwZcKEULKiTs0Oy2gLjOUATurnxHM8nxKJIREZ5AVsfpG5HH82US3k5zwFhSG5Yy8sjKy/OAzBy3HmazKyuwtu/MNYgoAq3bFyhII4OSnukyquS3kd/VZiRmO7dfYTb/n1JuKPxHQMEcd/xoZUXva7/WRXo9fo8Oo9F6a6L72aiPAtLlN/bKTOHRwR0eArMOWC6fqAbFeM4vmLVOt+WUWIDUqrEcCdmGsQ+HYqNsj0jx051jHrsq/fqpL+/SHVl/L+q26kBj7N+458B21m3EapopX0QXIAUkcSCwKVH3lAkwQKLV3jbjyRM8vc1Nu5HyrVcrlZkMmS3KwaXjD6f7ebPbYvUHwUrUc5PnOu3PiOdk4rjuBIZV6cQn5wy0Lkn17qnwFxDEs4C27BRzfIcKasVrHEn1q9dze5K6jITLDH3A6VDgUETRSXleKV1i9r6m6TGOo73nhI97yrlTXTKuiTUOnP2l/Z1yyTPhfMXzH15kGgjTjC8gbmPBt9DsnG8Em0tr98XG8tmwcsiR7YMfrWi6rokR6zdIK28fFzwNs69yVZg3ON37/mvQIpAPwWlwPNIknUo+fINBa0ca6D9odqkev/R+qJW98zAq2B5h/ltPQUWOFxaMkgDnSHEPYGTYzTtlQEpVWJYYul2J+KeDyah9gdrG8++2XMXy5x5+h8wAbmi2ykJnJ2Zpx55eAVpdrzGhHJkk9blgxMya4UcLmIwPacZEt1cD6LPRmwrFqH9huXqclKLAiSiU4JNgIveMS0glP3iNWfr8OsonGcuUveburyCSbmqJg/s7IHKefg/ZQw5OVgr/z5yzmDGd8f2/C1iW/vlK397YlzE7uCGBLjRY5wmew81ZWuOaOFvZ9c2rTIvDtHE+Ow5yV62vS2wR+KSvvEJ3G23PAVmRyLOpVVix9Y9PM4ewp9m0YnpVmLB7sqtwIO1SWQfCM9EBB7H9qc3SqSLjD33kvNb7bu3f7QURSqrPu+7UKpWqh2vDPL6xk89Ld78kyKq9F64XJky1DKCdsop5BUxEVphooZlA1Sir+zKL/ZI9EurAN1nMPm/qZPwyi+M5UByNLXHQgkK9LVeBpKfqOLYs10Vf86z44Ztf0/gVUtXEkFBdBwiQmFQyIvdwgsALCS/LXIfSc/2kWp5QyXmFF5IdgZ3m3sKzDlQca6jxN55ub/8F5RYnEMU8TQU9EeffBexXbgGnds1EejA9kehpljhwn53W1YnM5P7U6WBJhpPN0okWT8YcHHyyJwURXAY/jRXP/P8V1mxwMR7AGdAFRVOUASxCuCD+/RFCpccCElyxiLJso+U2UNdjk9fELv1CVSefLfbDlW36xhzJYAwC3TiH6EvPtcXVkSnTvU3lzEuUMAb8DWSOhBMUBajVenGwIgRrJu492E5OgV4/SfPO/fsW08g8rmvD29FRwCaJZRYu4uGxs3ZF24grSUGLVJelzQJd5/xHksUuMF1256sE8Z+KpBff/z23bJTUwyQZFSEyLuhUjc9cS54DSMJOVj4rmcMM8S9kdpznMmO8h21NKaCNQRfIjlkR+nbPcAAq1B+VBdfJKECdDeNwwC1D4ZS5HxiXXvVkoKpI5iQ1ByN8JyfvWo+FWtpteJzjDVyWEODrESZAjhZo8jFXxeaKtIscZE6LUyutU0tKVIPnAKsH1otPnPUMgwnJH2PUQXfRxUrdF3plAYdRcjdwxq0wv3CwuIST4G5BiSRTZTY1Jf6+5JPv1j4cyJdBT13f1Vim/7YJtM/+DroM0e7s1jRwtKqmf6n348lmyixIv4MsFUsV0sokjCpd7xXlYS+nICUs1KumuE/pGQ9CsopoBbp3ylMgOSfESfbu8t5JPw6faFABi3254s5z4D9vm0/k4QLK0cs8TRnP+514PUkWSdLqh5viIuJFZIjFo3QlsKhqchTC3d9FDVkznBiWqFiAC7WQwNfUvPZ494yOSNgldhx9asnp0NXL1aJZUJMzHVrcW9OnPKp/PXX3rjP58QTmx+TK18qoQ69k1M7ApGg9Pbqv31j1uAnxO1oZeMKk4/VX5UgRS4jCYoIyyVa5VXucH+PUEvB4Xj+KGX2qOjfzxpVm+eNMy7KZpeoxdQ08HhebxVXS+a6KZpXp+N0i7oNH9mibk1Vxlg50ciM4UqCrPG8dAukzm7B5ewST4G5BiQZm5QdwRJLVYHM/U2JvfxGFK6cCD9Mql4YIlzWOxzvCBzRPLozcf2RdMtbOZRD0EtZgam+qrrvLDO93Z+MZdfHjcVCXxbVCEIZ1ginMLk/f6kWZNQJl7iRBVE42zjXKbMCg32wStHOdslYh2HjLnUx1j87sDcSsikSWrF24P5gW3/ri+U4fb6/9wQ7mrp9AHzciPBvp+W6nqfAcg1JcnZYJXb8sUckp0NXL/uLEluz7g+Z/+UPrqeLffPYeofHfpJ3Rt6NQLQKbJdaDGN0AqZqL0wNWEFW3h9pQCBb9VgyBasFC8DmTVGjilpVyGm99UsVWTwC9+Hd6gq77AXD/kFRzlRK1UbGYoTjkXhY7/IiN+gLQD8FezzQWq+s7tloBERiMt2Z0VyT3wC+RqeALnWV1vEUmHOAkrxesgRVl/tL42Ndb21Jus7+oMQ+/kTdOkmQaApBJuEyXhfJGgGg0sGKWzbUONdRJwbW9oL094FWCqJQhCHlS6rnWG8Q806+0x/sL1zSEPjGeo8ldGK3pVQ4twbXVyVF7MsnOtE/p+5BuAshCe48LGd/jAvAFjzHuB6GGqtUpUCLMsbuIjYHdMK17qpproeiB1AC/+LKzyKTKTsv8O7Q0CAWZ7tkrrvdiABVvpsZcAVPgQUMR/I3fErspdukScOjkt+59pjtSixR6DyDShoDOWCeZNEIFCph3H/OWwYscLXGlHrPFjlnuPOImTyBpU/XiZQAv5WPnvCT5gLmuG+FFp+c7VA+tmHOsvYZgTso1dJrVuDbPooQofTLPlElNudxLWqpViAlWSJJ0TJKKtw5t4La8LNBSVKbDJh7tLFAYnJYJbEICgtEJghJFDTIzOrNDMv+tZM0Lva5//4oGROOjgtXoq2rFss9JNLWWsDOPlxuRE+BOQcnRevUd5ryosLfPSWWa4Q//lTfShOUKhXLJdiDd3qejEDttoGXtcUhcQ2+EURJMNlPGhA4kTrLm8CSQVwMC6pRl8C+2WrWXet8qRKyQjztJn2jJyaEe8+KdVPh4nPHvGybcMsGnUztMpK1By8xxTudFl64c0MdQzn3+dgwyMfiwgR00vE+TfD+zVSQ7jdP5MLRCuJQiDzxwza9TcLzqM0iQ1dq0vVZoe7AJJ2TQ5cuObxx7isBqHGIp8Acg5HK1X1K7DjPErPjvG37Lln202q7GfeySiVPgcU9eHl5Yu3TA6/+vVpCbw8ycHU3ND6gpVpDoWSiTsgwbbjjJ+Ry9Rinic4/+s8EGFI+5/8jdEtWvpthCISLqCUGK/5x59sj0S2/fksJchWoQRI1CElKguwrjlkouj7crTapciEWiMK5WZWu273mbs821tZw/f91Rn+/pcVLAHXNYCeZ+YApQXPKTYY8GaaO6yaHf17y6tIlWOlu1CdpEI5KBp4CS9ePoddBiVHrq2mjGim5ara5E39asTYp4+ApsKQMY/o7IQ5W1OH6fU8nVApWJiLU8XpYFaM7+dYqxEVT/b3DOAFpMLRP0D3BiI4wyT/Q2uQhweCBRVeklO9QwFe5asaqw8JxW2oosaGNNX+sjta5ukGTk18xVl4wt5i9bkDnQTbWKdhpVBuTC0XpmIsc1mSQ5gH5cau/0/paD6lCrq73c73GxJ5SK7ePobC6WX+DwXVN0jdcit2eDIwJOvuG7QQWj3SJk/iZa+LKpCBpjuS3K94yPSMAowJsGh26DZdPPlua9ItaJZYNjB2J1PxyDlxZrdHmSRaOABN3nTNNgjG3D0OEWy55VoRaXz+q+wzFFI2Q7/V4x8CW0ElR8PJjnZydApkutE81Wmu14kP8pVugpHrhMmfLwHUsK9yDlH1BcMcFuz/Y4fmEExCZsG68drO/FWNT9lBl3lDAxT86aVuB7YPr9PpAkx+vMflnoep5/aZtV+iYAsAASRlKUO70ywfGEyw3YoOhCnLOesSP0AzVZ7L2Q47sFsApOS7ffO5j3nbqR8AqseaNa6bkYlaJffq5/ifMYPkxgaKVzscqUrigc9Nbz6YRQDmFEiZxjhcsovRPs0K1Cr7fTf5K5eWRp4YGTSyb7VdewXsM3AvV0tMXGQYOjuDSo3JzLPEp2yPKEDeeE2BCbA/r4x79P9z1icBcN3LPHtVY1a6tpo3tx72E3Hfo8eGVl/sctokzocBDCQnF8C+mQ4IRDqPAcsSzwOxIpHlZrGghmTweS2yYzFvg/0GSdRsoMay8yeP7psxlmei9rl6zKdEufOdnmgIb9sgkcdaOS8pDxtlJ3WMOk0u6qAssU4U4GG7EHX/kvkPeslFev34TW22w3D0Z6Hiw/Ynsw014b0MTWzuimeHqA8H4whWaYqUKKFpB0SCNzhdZrMrBCpDx0Wdr3tY8k8jttAixKB9SizKYS9Ke71weoLYK5L18KtUx1hXW2VJ9MeDlgFgT3JHExSKR+AJnn/ecCDyVqZZiZXNfAVqpHMlvV7xl+kfAKrGOlwyXufO/T/oNZLoS275jd1KeuUiRzLLAJkz8WJLlHk10gDqd2TizFRixKuDmc5/N/ajUDCOBeUz7QMuJ8vMAJIK5HHP3ktieQsUVfn64mfRx9ZUsb0qxWIJeLJURLUUaX2QUAC6vpheHZE8PejNYNBAL28KaxNt2btGm/xr346s9Rbqrwti4XASEpi2CyfPjAg0n5dXLQ00wkpqdyoAXAxQWzwFhcaurc5bqlqSI5MRbc3NMOq+TLgVmUxqc1yYVIUc8BWZHIo+WRon1lY6XjJD/fbok6XeRyUpsR5IUWNIHzeswvSOAmzCYAoNuCdACCDwrIAKpsYU70C1YEU0vMXud+WHudna7xzhj2QDU4IOl57acWl6pRSDv88e6OJc6Yi/qRG+FGNL8CeZj98WyJE+LuNYeVSbIOSNMkvcLl5ttqKyo7dX+bgWN9FA4fENVcApAQSw4xWzl/v5rVyBikfpjT2i8zcdqry/NlhsS6D+KjFI0p2osDgVleShz92rovYjtRUNHFez8RPbZZ9c+PAWWyEAm6dyiRQrJpBf6SKfuIyRZzBTOW8tUJbZth/7nSoLs3LknCb0kr4s7e50jUGT9sWWH/Lllu6xZ+4cs+/l3+UE/e/bsTd6FXD1VPfRgqXP0ocISUmk+tY6q7GqVgZuAKwBQYG055cuJzi2TiHvRGFOKZenswGMk+kJWC1MG8S7ACJFkzljlBFTFg/WEQFUEU4YDpu2rBgysntwpS/2EtVKhltbg6q/nqOJLhjgTmkvrbwZtlhVAHLM0vnbuA/p8apV2uFfklRvt0fBLYnUoqzI5fwcAXOCWZOkUlCWKGhaUfPlEjmwRXoFxLpZjqhWY+4WC6xL7yxFPgdmRyOOlUWJ9pZNaYslgp3A/TiYqsb//1jfXJMiOnfpWmUFyfsfmQe8Gl+mMD7+WYVp5etESnViSJBTyvO2mTj7llaQu09sNYA0opMhPCiVlq4r01AkTKwEXl3Niq1Jf5MZpSiNVycCsgYc7BVJb3HIwTUCjZGW5KqwhjUyu1yFHKvquqWGnGHVaYBwIKiviTTC4N7/MuN5qqKLrN1c5EscblyLuvmRJmSoGtEHpEFul+aMnTT4Zz3HCVToGz6jF+HUUV9T7ur26KUdDLbRQiEjGgmcsV02ZTjTuRjmXSIICIy8tlQJs3i0UuMyRfHbFW+b9CABGeEstsROb107JzVgllinoxJLFiyblOXdkmAUW6qFwF3c+q4nMmz5EQim5UOeG2n/tpafJhMd7Zq/ysg8WDo0Iwq//fD/ijhImCPEzcrBINkZ54dp78nz/pE8bWNcf1QlvxO+GfYJ9TgEqTp0xXG1IlXpKZTUnEPVnjoh8PUnksfZKVXWQ5nfp/9E7axrARjKVF9eCMxEuxk5D7ZVNDa9Zj5rt/PrcbXqZdRRatca58978Z6pS32OqPK//UeON6j485RZT4wu3JC8OUExZ2bjCAGaWzbZ7Qi+J29lYYOhWiR3hN3WLg6XeU2DuwcnjbZTYm8/3ltYtUqfE2l88TDJBiZUsqW/GSZC163USyiI58MB88viIK6Vi+TIJ3fVBZUvI4H5dEuojY04mEdgxMe27L1yCWCJYXdBLgfqzhK7Nexj0HMi5sTox33aYKpm39p3qy+3CPUi/qxebPvxH/WtUNUaJWSQkVkiQ6r/7TsDdh1UGgCMVZUbgHMSN6XRlcnEAHLjPYIafoG5MBHAHyr2HLsNJ6xvUwtoocs1EZfR/SBGEA9Siu8NwT96tChNi4Vhl7x51My6K9azY2lPHzS0o8BzxFJgdiQxa+pTYuD4pU2JQOGWCEitVIjkW2MpVGzLo14vuVviNu3TSOEMCcmrrekJO4X4h7z2obsEgbjhYF4hnTdbJduaIQOuKpGRqccGPSKKuhaMzIHAPXqzHERTT450Nqa3Zk/t70TuqCKoaBdn7EMNSkbtVavfgSkWwlMjzwpp0Cuz7H442SbwWUci4oOhQ1KWrOFsHrmM9AqVHUIIwbgCjZx1KrVveD251mjNCfwN8SaXArOIWB8uKp8Dcg5Mh24ULF5A3VYmd1LJOSu4oE5RYshjkf/ltfUrGKNWdNkuQUqxZI3Vh7Q+yTX8/mN6TJUzIEN/Cc8gb/BPnhU/Mtdel9hgxJ5bplqrHGxCKvS50TU73nK0QTZzwOLUWYZIHIo8l+MHD5iyr1GwfziWxP5CbQ5sogXEpg2Qkyflm9QIQX6tYS3kQVcnFKlivqRTos9zieE5PgbkHJ4O2UWJvPNdbTmlVNyV3FUqJ4eJKh9SqGeaNMYYb+HX1Jtm7V5Mrs0yOPLxCQndcuWLZhM7PmJOxvpwovERv7Dx1tRHbeq67WlXVNFFXrYtMFkqZXPlyDp2V62+CsixYksTyEBQRBSpLaTvcq8g79xgrc8tasx3qG8Skj03eYekChsHCXaDXr9IgdisslS5EXiQg73UL6RI5kp6Zyl7NW8Y8Aiixic/emlYllizLKNLD1k6SAvvrr73yzXe/RLpcxh2njlkikq7fKZF7jHguSbnA2a0Q77ryVQMVJwfryBPC16my59kloIbpCuyApPfTF1ITo7LXStYS9CPKiFjdviKa2jkuxVtnmyKelnORa8LCgdhK1Ez01Bez2+Zo8O+aJxs2DlsUlFYkBj+jLsjBtYOfE27v5lXhjiZ2DOsumFsZwE6OeArMjkQGLwsVMkrs1BPrpeQu3ZbYEdXKp+Q67k4PrXyQj6HfvT+e7c+++jGe0/L0nML6uyYiRTOMgSSuZyFh1iam8mZ9/RRDqXTm7YYVvc9Hqow0DuKuHRbqYvT15+pQR3PvR2ECj4fANh4hZwtofyKCAtmmAAvEqYQAKwDvR0ocbJZ8wwiP/OmIDwHwiISGbHKxIQHu9pS6Ed/VMisDlKFD3Yg2pgT6MVaFFMnq891onF+u2l/7erGWp+7wFNi+UcnsFZTY68/0kjYauE+FOJVYbU2GTZe0SBKh8Wdf/ZSuW07adQoWzJ9QXwUKJHZ+QhdPxsmwSMBsbuXyl5RaoZDIsjkmz4mJGt694uVEbphqGDgSVRb2WnYJfP/atxSdpyAQrh2tABKBEWToLxpPUgV01l3xJ/WSbAwsH3osX1mXnGmZGNjkO80dkRtWsoJZh7sQBKBTUUcTtzvsOP/TFS6hKQhDNJa2QOQRBXKcq27ceIScrGS6f533sGiac8u/Tt5fjngKzI5EFixRYq893UtOO8n/Aybztq0SSyezRdtT9A04CTJ77rdJ6CW7uiiQX11M2SzU5nIWmKRgIwjAB1trwcUrTGJtb/UGvHiteUo4EAcpaCFc1WDneAAdh5apg07UV72mSciKWHQL8HwsD2JKLS5zH829TQ4Vbr0h+sLE/cBagTJoP1jvTf8GqWp8Wt/c50XaA4EuOU9nD9R7Hu5vbVMG2EP9NASLDSUWiUbKtPZ/w+IxsY8BbvQ71BS1RHli6ZGSEK9EIv+Np18saesqdZ/vKTD3iGTPtlVip5+kAdcUCErs+n5P6/9L/Y+ZBjnjlOQ8x+o1m2VBFroRExniYGlTifSX9nPfHxV4yWBv8ts3KkpurE68vU1bXGlwAoI0jCTkhOE2I+fpuPMMg4X7HFBusHG80U/kiBbuo4HbjbuaHCrcjd9/YJCTq742beAxhE+R0ijnDFMlpooiVuFZESf7hFNJOYltx3Y2baP+PkDk1Zu0qOUDBuACGISilhSyXD5fQSCbo+4pV0PrAs51IIEdX+gLh3McbFeUmHGUWEnPLGUv7i2TMgK4nl59+hZpe3JyJn/3TaHE/vnnH/fulGwTB6tfu1pS+p7yrkKLPcmOEaCe1A9zzL3C+N5L3YWPqVvsDlUIbftrzEctL6cAUhh/pULLdxugw2066R6ik1k44RpM9OR4LfvILIO1J39splo9z6qyCydNVIFRMZp8MXK0XrpO88bUg3DrwUorpS6+4aoAx19l3HtnqesPN2MsgnWESw6GCytOl6kT8eeE2Nu2YZf/KnpxRe4WuB4fOTMwnpa7Vfg9wRRN+DPCHyWvDSBOMDm2U8BeT4EFDEf2bKDEXnnqFjkjSS64vHzyq7qfmpTLv/H2pwpa0v+onmT+CEAHZV+SumgcrGZrdcepS/TQ+oZUFldck26Bz4G7r29FkbcHazt9ecPSiSQAAUa3U7fkiSLT7o3UOvzxR3Wif3ugkg47wBOcsW2DWjDq/kOwavpVVgj/JYHAC3M0/DcxrSXvmxigbYl78937TZzpphmq3G+zR2JbFi1reBxxpfZ4PhAUw70/1SW2/pytiVMmUz4Zp27SFcF7hDXfIfkd695qlo2AVWIXXjVKpr3/ZZbdvf92L+zUUu4c+ops2rzNvzOOtZWr1ss7730p7U5zBKvj6Mc7JQ0jgFWEVK6niqqrWkfTjCsLsEKLy7V8iQIqLtWJFgvkg5GmLd+4uqYOMst2qkzSJcXVyqIe2JEtdfI/XQSr8Qe16rA+sOCYcGENwapEocF84Rae6/NX/fW83MfZ/vBRw3toj4FKhPW+xCEmRmcRiPZ4NEtIjAHBUHTTSjNVsItVIfJSAOt/IhWWncTKtv94l1hf04YEPxv4/OGNA455CixgOLJvo0CBA+XlJ2+Wi64e5Zu8s+8JNAauuW6XXniSPPjY2wnf/phnZngKLOFRTHEHTPhM/gg1p25R68BJA4V1duUrpgAjvH0oDNyHTog35UWOOsH0kcpvcrGA9nMPWIhOodClWyAF/kb/jpmE3SwVKBIYQmB9DxVzIrYWTFAwn6hCJ14VqzBOVnlxf8DmiXHzTHxI+CZnLphQXgUGe5RyKIkmHhnqXPd+0ipI1A4mpDvIAQFH9Ck8yfYRQIm99MTNWT1x33xNO1/9qkR/iznzFstXi5Yn2o13fipHgDd/YOBWnMqLfdAoDVErGlg5wiQ7SCfRVtfohmMCezNOd5qv0yi/Gp6jqEd1HXLd5QuM+3KhKjQsBaohU4gTlyZ5WCAG4RsEMNLvE1N80nmZpbOM6xOXaawCxP/1W2M9y7RfOtsQHfcsqZZYEaWMKqCxwXP1pUGBJ8ipt5il+5u8PCw3EsrDSayxvlB9odRx0YYSW7fNcdyzwByDkc2rKLEXx94kF1/7iLw94/Ose5RyZYrLgFs6S99B4xO+99vueVFmvHZHwv14HaRoBJyM8SAKccfx5k1SrE3k3bhC5H51eZ10gybc9tccKAV1dH3cQN6XzTY3BultqgUUI8ANkJCWGb1gMZOfZqsZO+8B6qeL9D7hK4Qh/ke1uHAtIiAeqbN1TBuzHcs3fIcWpRjLebg+ccvaumKcC7LxqzdUAavionBlMPQn7QDTUKHZCSRhv1t45mQIKElncrazT9hKgqBEPQvMOUi6/s8//7r2ZM+mUWI9pX3bRtlz0447vbbHaVLzSPVzJyhUtZ78bs7be4J9eafHMQJ7dxuY+WcvG8UEkALKKATAwJdvmnWKQ4LWwwK46xuRYeomI8ZkhdgKrsL+1UQGHqMowW4iV7yk7XvZFqlfgjTEKrDKiytiMVrlhfJFoVnBinj6AgWb6N8x51qWC3uc2B/KmPNiEWfScrTnAenvv0CRnWopYhG6x+11HcfNvxpm+mB9kiOGuF2nZq/5JpejaGnnnvjWiQ1SHDSUnN436BHPAnMNSzj4eLpIbl23FNNmfk1upcAhlli2wcoZ3zHDrpDTz79XEq3W3P+el+SUE+ruP+VGYvoryKPGEOji1kNx7dwSeBMFi4q01gkdF5t9469U29AiHa5v1wXVtXVgToyIMh8TrvJbDSiLNWq50D9v++c9aGJBoRJdA6+c2Bb5UlaIh9VsbQpAAiiocaJRuMSAiBEtna1gFHW5ffWWsSSDMexbS4gK06GqI9vrJbJEccIpybjirsWCAaL//kP+XiH2xVULHZZT+K34jcgZA7gSitKJcziX2F4islJfNimLE0rI/arfIejRBK8ctM+s3rk3TJl7lEM2iFVil1w3WiZN1z/SLJLmSi11R69zZPCI1xO66xW/rJOeA56VZx/WSdOT1IwApTyY3HgLZ5IE7h0qAM+ESOFJp0zMielAwIurjlgLMPpq6kHgjfvpC52tjQvJktrCSpGoAmNyhk4Jiwg2ja3rTa4UtcUAkpBzZgUAAawelpvQ7rdL3Gy4Dfl0HWvg8AvUWkSZO2XLOrN1ULXUKjCqWJM2gMVHLOvupSJHn6wsHO8bpOPCyeY+cNlaty17jmpl2O8fOUPHYrnIuB6BZV3MWf5vBy+hf2cMa7hVx7RXhbkz9EnnqdK1tcxcrfR1yBPnCOze85dzM2A9XxZRH6DExj9+o3Q8o3HAM2TDRt8bO8jJJ9RJ+FZfeXOuvDjx44T78TpwjQDlSe5XBQJ/3wtX6Nvz5YbuKZTycp2eaxMmh9ljNCm4gUHorVpoIN7uhsC9bTKvjSu524Tbxhqp01bJe/Vtnlph1L+q0VoLRNYyxSB9xL6dFL4/Xi2TnxXirywVCBbWJc8Y5UXO01qddGcM1+Uyc5xvCkSOUqUBWpJE5HrtjLsT6imnoLiQZMWNTG+5v7EEbaoC7k8KYf6xWqTWKYb3MQggwtcJJMoVaopcpmMAcIVEZwAroSSUQg/V3rkflCZVA0LFvWjbQi2zMNRh+Z39eev6e+3SN8kQ8rdNvAxxPNN245JDiXW/frS8+c78TLu9kPdzgL4oPPvI9XJSx4GyfGXOG2vI1uEP3DTgOaHuVpPjdMLyJPERwDKh9EYo9gViWhWPMe6qV3v63YXuKxdSiwerzJ1DRJ4Tbq1G54tcoJMubra5z/ljThxnYrYWhLtf9zaWUbPupmIxCikY5BuFDEgCNyBxI5QayMdb9VojdcLfst7Es4D+Y0HZe6Yi9C0fiJSrquwgx+o5qhyxKj+doDEwVWJV9TnOfUBrbb3ot3KoYAyUPZnJv4A0Ot1nSrJAN7VaxwzrDyVm5yyqVk9S5YQVBvEwiE7auIX4JNYbY0Xs65+97haB27iB4xFqk1F1mmrZoaTsoeouHhnqqG9/XBbY/sx2sGVraFN2795/wg5mJh5EiT0/5gbp3E7fmLNIDjmopEx9sb8kWvNqx87d0qn7CFm05JcsevoMvVVykcZfEVp5nawKC1QhDO9AzG2syz4OcRmQbX3nqmLYpKCNX3PHX2iLgsD1hmsRxveLn7A9GDclE3E0gscEKwslcljD4MqLfrBOvtHJ/udPNdH4NaOsbj9CiXn1/wyKBgAFIAMsGVyYluYKKxB2DhQSQkI2Qsxu5gizTr5VSx0zC/8n7vRGXz8y0bSK/RtrEoQg7kFKo8BaQo2vSnVU+XfR555sqjYXKubo+18DroGVBJ8EZUoAAA8VSURBVLddMPlYx5p8M3dqQ7C27LMEw6GOB9sPz+HINuGVF8qz+3PmbyBYHzn74lJge7SAYKJCEcJME6r6wgMYSrbvCH0s1DmZsN+nxEZnnxI7vOohMnlCPylVsmhCw/jHn9ulfdf7ZfH3qxLq5z9/MhO9G5xhB4Vgfqf77ZZRFs7yJIccpblInxhLgdgTgI1IDBAgEBEUgwUaoEScBLemRfBv3GRO6DWuMHdyMWdiFQUTFNRv3/qPwL04XJX40BVqyZxi9hMHfLyz5oC9p4AJ/Tttf4+yu6uSQ+HhYsUdSpxt4CJ9ZlXgyGxVyhbMYfZE/gZ6f8v7Sr67RLkLt6ji3CHy8Fa9H1WuFfU6ToGTcWAtw+1Y4WhFIM411295ub8VgJhQAnpy1zaRSEwn/Ia4XaOVtUv1nk9THklVsO6XG3cfF43xj7H7mGM7LgW2a7f+ISQoO3cl3keCt5Dr9DXrwvyo2vrPLfpHk6Vildg5ZzfNqieoW+swmTy+n5TVPLFEZO36P+XE9gPl9ck6iXoS3wj88oX/PNxlTI5WzrzDIN7sdpdRInfq5I2A3oPHDyvIKa2vF7lQJyqnonMeX/m5SWbmbbzMoc4jkdehokJxILirAITcelAgCs8cFWmjbj/cVVaoP9a2nxIMz1Lrb6xxJ2LNrVsm8oBaL8S4zh6kca6zDSJx8XQzMaM4YKG/Xe8b6xHlRokY0H9A7f/eY66AhRkurmTvwy65n0tfMBM6Y4771S2gNCEYJgkcqwwORYA1PfXerGXW7WnDph8plu8D3Aw3lpj7Os7tg6qrRaqWYDjhZWPZbIMqvbueUfTh2nOMsT/h6kitfMdVhcYum/9Q7ZygYOlg8WQSsm/VbxvDPtWGTVt98G6UQTaKVWLEmCZOyZ6JvHHDI+WDNwdK+4uHyarfNsQ99LgTu98wWj7/+ie5746LJFt/x7gHIJETyQmylkqN1qYI5C61AO48ykzQuA0RyJTtBAkYAIFBPBjtEu2A1pNH9ExX09b9jbXSQa2aWCmUcGcCVUdIkAWajwRzeaFIqQUGAS9AB6ijbMmOmieZyRTOQAAaWHCj2hiLkNwqLBkmZgSACcoMxCI5bnA4Qn/FM0RrNZqeAr9xodpillzvHR0PlCPKsubJpu0r+rwQAROjRHAdwqJBIrMV7gFQCePCs6JYQwnPG0kAsdyvL8S8mIBG5INbkzHE3bxhuXHNOnPoIvXJ31GnoZFa7Tueb99aDCs/r1gXQ+vgTcm3Wq5Q50yS75b9GvZ2iP0t+UF/mCyWfPkOkHGPXi/ndWiWVU9BgvOHkwZJHbXIEpVHn54uZ1xwn6zboK6YPJRffo1fGaf1tmGAgL8Ppoyqx5sJ3hcL0smRIpEkH9tkVtxP43qYuJBPmR0o0lQnSysowh8+9oML2I+rL1RiL644wBKiijFaKVZW2TsGmNZYO1iHxOaw5EAcWiEeRTIvbbAkYGq/cZpRXigKACRW8RDHAqxhhQl6/gQDdihVye41sT+2gOVboRQMbeORphfrC8A5/jOhbQJsgkLf5x7VsbHjb1te8IgiLXNeINiHFYr1COLz2M6G4cS2TWTJfZDvRr22x/VFhdgW3Ipv6fh//JSJG0bbP5RdPcZpa32xiVLiUmALF6+Isvvwzb5elJx+wl8l+qPzv/ghYuPPs7B0vfuhUGLPKcrv/I7N3YcyertShTJqid2VFEDK/z5dIo3b3CbPvzI77SVYAArdft/L0rRtziSb0aOuNzdLJ0MLW7/8RTM5W+ACaDViWsg2VXRznzGuJ4AKPqSgTq41WpnjfBMvekC3+1TwWwvsR7kEE+peTY/+jdzXhbMWF+5LkmDhNERA7CG486j/BYfhGD3uYwrRiRPX37b1hvljUB1jYaDgELcVSR4arkCnO9BaNc7cKkAgq781fcTyjVsTJKYVy2aCwqzbzuF61fsmaRmEIQI9FBagFZKxx+rz4/okNoYF+d6D9mhmLFtdZV6MQrmTQ9xlzAoMhoSpM74I0V1su996R9+AMkR2a1xvxqyvI97Nxzrx7Q+CEiPJt0sn/WPPIilRvIiPaeTh+y5TFvuCCd35ug1/yrV9npKWOuHN+FBdQykWaMqenvCB1D2hl4x8fKrs2bM3xVdMUvdOih9rWRBT4o0eAlubL0V1YjuZk9f1Wi8TJ0MpIAvfVgslZ+5ASRBDQXC9havqGwnKbXrxfxObsoIlRYI18SkQhVhnCJYD+VwIsPz7Gpl1vmGSt24vCIVxhSFWgZgtk6v2QGuj8Ow+XIYoabgTExXcg3bsuEeLHNy6Vq2rGoG9k+iLNYxgbToFAIx1NfJcuBpDpUE4z0vHOm5kUgC6qpuUl40YRZ86Nnl83EzZuHlrbCeFaP32zM/li4U/hzia3t3PvDRL1m/cEvGiE7Vo4q+rN0Zslw0NUGLPjLpWLuicXUqMsb2y2ykyZ8pgqVUj5406gQGHvb7TJcOl0an95IVX54RFosZzmU0aM0Zh1VHF1bP/s1H9nUW6ToM61aRkiaKRmiXnuNOaAHmGoKzIi8LFV66ab9e+SZ8tXG8wOVirhXjZKzeadnzzpl1FY0colecv8+9PxhoQcyvwJ1JPy+YbbciZb0AMOgXr0YoTqYjCs7G0zb/ZFmaJYsU15xRiUE6yYuexmNfVerWy+F1DuzV1sLFcbR4ZicYg+wCYYFWRx2aVFb8B4A5ccj3GmeRt218mLPkNLlPXKqkVcUpMCgzrY+Aw/YNNkmDNXXrjGIH2Jy/lpxVrZcSjk6O6BeD/fQdNSJirL6qLpaGRVWIXdm6Zhqsl9xIgFOfPuE/u6X+BFC2iE2KC8t3SX+Wa3k/KYQ2ula5XPyyvTZonq9dsjqvX7Tt2y/tzFsmVt4yVIxrd4HMZJuPvvN4xVeUlrf82b/qQhNMLon4wC8rgBFsGxVI6sW8fzY9jwmU/YtGD468S2bTS7OO7Sn0Dtad0PGjDZArJvFbsRG+3SfJFLCzfbBnwgV3fuMKuGdejL/lZn+3g6v796Viz1izXKnGwueLbgwzE3TLTY/EB4b+zpnmpIAnZCgjIB08yVFA8Q6SyKPa8VC95CWp1tTKv/GjinwlcL+d1KnwPQJCfeP49eWDMFB9yMHzr2I7+uHyNtGx3p9x567nS9dwT0k6+yiRzxc2Pa0Bfg5tRCvyCXa4YKY/ef7lULF86yrMytxmoxKdHXaM17g7IOuolUKy3Xne2dNF4Xh8txTJ5urp8EhTYWN6atsD3oatqhx0iDesd7mP0OKJaBV9ydfFihaVYsUK+6gWgcjf/sV2wtH746XeZu+B7Wbh4ZVJfcho1OEL69ewoZ7VpmODTxXE6LsKfPjEnYslAZOsssWHh4U5WdnsZwAUwPnz+it1jlhVrGZciE3KyBVefBYVAG/XtdP8VrAID1YdSgP8Qse2xqjapUrCyzx2pVkyf/ymacYFh7cDScioY2z6ZS+vGpM9qjQN73r7JbLsVNIwgCK5aqlwjgClAZVoaLrM3/d+8CDU816Q3kBeYBNmnwJYs+03gAdyhb45bFeK+Sd2E32ri58JvV8jHn34vqUw8ppT8LXeM85WVb9H4aGlQt5ocfWRlKV26mJQqUUQnisK+SePgco43qxgefumPq2Xrtl2+Z9iybafP4vtJFedULT8f71vxtPe/lBlNvpbTWteXZsfXkOpVy0vlimV9aQFMqgAO4r3fGB4taU1RYk8+dLUioA+QCa+rayjLpEqlcr7K1Likh6s1PXXmF0kDZ/A3Eu/fSSLDyG/RpnU9ufGKM+SUVqpE8kpI2rUKDCuq0jGBk/dKnSxBIpJ75BbcRAA63AIEG0oqi/JzH09km4KTJ6jFh0ASPOUuQwHFNmwbVoDUfzPVbNnYHhaNVQr5C6o7Ti0YEnBBIJKgjCIByNL2NkMzZRWg7TOZS+J0MGLwYgDJbhGd/2wiuXXrul2h5IAh9rlYnzncAG/cxMIcS7WgtGDCb9DJoB8TJf913e8BCg332f1V1W0STQzIdX7aNiF4HdT3/LiuR+zhZ3UTplPu6n2e3HZTx3ReMinX4s/hmt5PyfjX5uTq7+ijKsuXs/Q/QxYI7sAHHpsiAIUA6GSTAFTpdn4ruUbro8HjmOfCpD7gcDOxM0Fe8bJC5S81MS5urlYbkzwbrCz9wUcqglFdRemUg6opY4UqU4toAxkJ6TACtdPw39X6OsSUC5nYx+yH6eKmmSbORMoAAvFvl4eV8kpjxCARqyrQA+YJ3HdYYFaZmNap+T6tt2HBp/fXb1HU5ChzHSzYQd8ZjsXe5f3X7jdPFUYzkdFn+S0w/9HkrGF9U/MNS9eoD9MvbkpicMQ9+ZAfBgLUKtXkXD2gl30WWMBeb+M/OwK89Y994EpfLiqAhmyVY2pW8aEsR917qbw5db689Ob/ZO7875NmlSV7XAoUyC+nqpVFLPKs0xpKkQQRlkm9P+JYuKCAnOPWerB1YPewP4SSdCsv7mPDCpPs2+Fec1eQ+U6+Q+99jSphBTbMeUxpkgaZel6mhd+FCPDECoTCY881eVfsI9bEJ51C/a6mCkSpXE9zt240KQ08A4UofeKzP/x3hLIgT2zxDP++ZK2hNEmetmhHcvNQYgB0sKS5dhxIwkRub58Cw/1VqJBq0AyV0iXVjI5TSuobbelS8Z8fz2ULZ/BYRnoelNjjI67Ul9V88uqkub44D4AbYmTZJiXVBd3jwta+D+jRmbMXyuy538mcuYvz3OOAi/lkVVptTqwnp5/cQMolSJeV0t8GZYALy7Kbp/RiSeicvDLrfqPgIpRVICcRS8WEhdDuLmNFgIhEcHGdpcoOgVUfFhE+eSnE5FBgpB3wHDBdIMTrsDJxZ2IRAaxBiYBMtM9gWsb3DTgHsAvXBbbvBr6AbmQs7XjGd5WEztrnQkyoF+9kbwSycAQg9/1ME9O/W7pKYGHB7RiJDzPex8QtCJvIsXUP932Oa1BdQFF64o2ANwLxj4CnwOIfO+/M/XAEYK4HOr92/R+ybv0Ws9T8wJ3Ko7h7916ByBqwk01CLqCAnQPz55MC+fMLVnepUkWljFr7WPwHqYV1WOWDFMV4sJQtXXw/HC3vkbwRyNsR8BRY3o6/d3VvBLwR8EbAG4E4R0CdnJ54I+CNgDcC3gh4I5B9I/B/l7/WykLGwiQAAAAASUVORK5CYI"); }

                 template#template { position: relative; display: block; background: white; color: rgb(51, 51, 51); font-size: 11px;
                         font-family: "ING Me", ING Me, INGMe, "Roboto", "Noto", helvetica, sans-serif; font-smoothing: antialiased; }

                 .clear-float:after { content: ""; display: block; clear: both; }
                 .grey-light { color: #adadad; }
                 .grey-mid { color: #767676; }
                 .grey-dark { color: #545454; }
                 .greyed_row { background-color: #f4f4f4; }
                 .font-light-bold { font-weight: 500; }
                 .font-title-main { font-size: 1.25em; }
                 .font-title { font-size: 1.15em; }
                 .font-subinfo { font-size: 0.85em; }
                 .v-spacing { padding-bottom: 3px; }
                 .capitalise { text-transform: capitalize; }
                 .h2 { display: block; font-weight: bold; font-size: 1.25em; }
                 .h3 { display: block; font-weight: bold; font-size: 1.15em; }

                 .header { }
                 .header .logo { float: left; width: 35%; }
                 .header .header-text { float: right; width: 65%; text-align: right; }
                 .footer .export-details { float: left; width: 50%; }
                 .footer .page { float: right; width: 50%; text-align: right; }

                 .heading { display: block; margin-top: 40px; }
                 .heading .heading-details { float: left; width: 50%; }

                 .section-part { display: block; margin-top: 40px; }
                 .section-part .interest-label { float: left; width: 75%; text-align: left; }
                 .section-part .interest-amount { float: right; width: 22%; text-align: right; }

                 .section-part .section-floating { float: left; width: 45%; }

                header#header { display: block; position: running(header); }
                footer#footer { display: block; position: running(footer); }
                main#content { display: block; }
                #pagenumber:before { content: counter(page); }
                #pagecount:before { content: counter(pages); }

                #footnote { display: block; margin-top: 40px; }

                @page { @top-center { content: element(header) } }
                @page { @bottom-center { content: element(footer) } }
                @page { margin: 170px 50px 100px; size: A4 portrait; }
                @media print {
                    .page-break-avoid { page-break-inside: avoid; }
                }
                .footnote > div > div { border: solid 1px #fff; }
          	</style>
     </head>
     <body>

     <template id="template">
         <div>
             <header id="header">
                 <div class="header clear-float">
                     <div class="logo" style="margin-top: 20px;"></div>

                     <div class="header-text" style="line-height: 1.75;">
                         <div class="h3">Bank Deposit Certification</div>
                         <div>
                             <div class="capitalise grey-mid">
                                 Reference No.:
                                 <template th:text="${data.metaData.referenceNumber}" />
                             </div>
                         </div>
                     </div>
                 </div>
             </header>

             <footer id="footer">
                <div class="footer clear-float">
                    <div class="export-details v-spacing grey-light font-subinfo"></div>
                    <div class="page grey-light font-subinfo">Page <span id="pagenumber"></span> of <span id="pagecount"></span></div>
                </div>
             </footer>


             <main id="content">
                 <section class="heading clear-float">
                     <div class="heading-details">
                         <div class="address grey-dark">
                             <div class="v-spacing"><template th:text="${data.date}"/></div>
                         </div>

                        <template th:if="${!data.hasSalutation}">
                            <div class="h3" style="margin-top: 40px;"><template th:text="${data.addressee.addressee}"/></div>
                            <div class="address grey-dark" style="width: 60%;">
                                <div class="v-spacing"><template th:text="${data.addressee.address}"/></div>
                                <div class="v-spacing"><template th:text="${data.addressee.addressExtra}"/></div>
                            </div>
                        </template>
                     </div>
                 </section>

                 <section class="section-part body-content clear-float">
                    <template th:if="${data.hasSalutation}">
                        <div class="address grey-dark" style="margin-bottom: 20px;">To Whom It May Concern:</div>
                    </template>
                     <div class="grey-dark">
                         <span>This is to certify that</span>
                         <span class="font-light-bold"><template th:text="${data.name}"/></span>
                         <span>has an account with</span> <span class="font-light-bold">ING Bank N.V., Manila Branch,</span>
                         <span>
                             a banking corporation duly organized and existing under and by virtue of the laws of
                             The Kingdom of The Netherlands, duly authorized to operate as a universal bank by
                             the Bangko Sentral ng Pilipinas, with the following account(s) and corresponding balance(s)
                             excluding uncleared funds and restrictions as of
                             <span class="font-light-bold"><template th:text="${data.prevDate}"/></span>:
                         </span>
                     </div>
                 </section>


                 <section class="section-part clear-float">
                     <div class="section-part-header h2">Account Details</div>

                     <div class="section-part-list" style="border-top: solid 1px rgb(255, 98, 0); padding: 0 0 10px;">
                         <table cellpadding="0" cellspacing="0" width="100%">
                             <thead>
                             <tr style="height: 12px;">
                                 <th style="text-align: left; padding: 8px 12px 8px 12px; width: 80px;">Account Type</th>
                                 <th style="text-align: left; padding: 8px 12px 8px 12px; width: 80px;">Account Opened</th>
                                 <th style="text-align: left; padding: 8px 12px 8px 12px;">Account Name</th>
                                 <th style="text-align: left; padding: 8px 12px 8px 12px; width: 120px;">Account Number</th>
                                 <th style="text-align: right; padding: 8px 25px 8px 12px; width: 140px;">Balance</th>
                             </tr>
                             </thead>
                             <tbody>
                             <template th:each="byCurrency, iterStat : ${data.accountsByCurrency}">
                             <template th:each="account, iterStat : ${byCurrency.accounts}">
                                 <tr style="vertical-align: text-top;" class="page-break-avoid">
                                     <td style="padding: 16px 12px;" class="page-break" th:class="${iterStat.even} ? '''' : ''greyed_row''">
                                         <span class="capitalise"><template th:text="${account.accountType}"/></span>
                                     </td>
                                     <td style="padding: 16px 12px;" class="page-break" th:class="${iterStat.even} ? '''' : ''greyed_row''">
                                         <template th:text="${account.dateOpened}"/>
                                     </td>
                                     <td style="padding: 16px 12px; text-align: left;" class="page-break" th:class="${iterStat.even} ? '''' : ''greyed_row''">
                                         <template th:text="${account.accountName}"/>
                                     </td>
                                     <td style="padding: 16px 12px; text-align: left;" class="page-break" th:class="${iterStat.even} ? '''' : ''greyed_row''">
                                         <template th:text="${account.accountNumber}"/>
                                     </td>
                                     <td style="padding: 16px 25px 16px 12px; text-align: right;" class="page-break" th:class="${iterStat.even} ? '''' : ''greyed_row''">
                                         <template th:text="${account.currency}"/> <template th:text="${account.prevDayAvailableBal}"/>
                                     </td>
                                 </tr>
                             </template>
                             <tr style="vertical-align: text-top;" class="page-break-avoid">
                                <td style="padding: 16px 12px;" class="page-break"></td>
                                <td style="padding: 16px 12px; page-break: avoid;" class="page-break"></td>
                                <td style="padding: 16px 12px; text-align: left;" class="page-break"></td>
                                <td style="padding: 16px 12px; text-align: left;" class="page-break font-title">Total Balance:</td>
                                <td style="padding: 16px 25px 16px 12px; text-align: right;" class="page-break font-title">
                                    <template th:text="${byCurrency.accountCurrency}"/> <template th:text="${byCurrency.accountTotalBal}"/>
                                </td>
                             </tr>
                             </template>
                             </tbody>
                         </table>
                     </div>
                 </section>


                 <section class="page-break-avoid">
                     <section class="section-part body-content clear-float">
                         <div class="grey-dark">
                             <span>This certificate is issued upon the request of the above-named Account Holder</span>
                             <template th:if="${!data.otherPurpose}">
                                <span> for</span>
                                <span class="font-light-bold"><template th:text="${data.purpose}"/></span>
                                <span>purposes</span>
                             </template>
                             <span>.</span>
                         </div>
                         <div class="grey-dark" style="margin-top: 20px;">
                             <span>Should you require further confirmation of the authenticity of this certification, please feel
                             free to contact us at askus@asia.ing.com</span>
                         </div>
                     </section>

                     <section class="section-part body-content clear-float">
                         <div class="section-floating">
                             <div class="font-light-bold">Glenn G. Lagcao</div>
                             <div class="font-subinfo grey-dark">Head of Client Services Delivery</div>
                         </div>
                         <div class="section-floating">
                             <div class="font-light-bold">Diana Rose U. Cue</div>
                             <div class="font-subinfo grey-dark">Retail Business Implementation Lead</div>
                         </div>
                     </section>
                 </section>
             </main>

            <section id="footnote" class="page-break-avoid">
                <div class="font-subinfo grey-light">
                    <div>ING Office Address: 22F Arthaland Century Pacific Tower, 5th ave. cor. 30th Street, Bonifacio Global City, 1634 Taguig City</div>
                    <div>www.ing.com.ph</div>
                    <div style="margin-top: 20px;">
                        Member: PDIC. Maximum Deposit Insurance for Each Depositor P500,000. ING Bank N.V. Manila Branch is supervised by
                        the Bangko Sentral ng Pilipinas. You can contact the Bangko Sentral ng Pilipinas through the following: Financial
                        Consumer Protection Department, Central Supervisory Support Subsector, Supervision and Examination Sector with
                        address: 5th floor Multi-Storey Building, BSP Complex, Ermita 1800 Manila.<br/>
                        Consumer Assistance Direct Line: 708-7087 and Facsimile: 708-7088. Email Address: consumeraffairs@bsp.gov.ph
                    </div>
                </div>
            </section>
         </div>
     </template>

     </body>
     </html>');